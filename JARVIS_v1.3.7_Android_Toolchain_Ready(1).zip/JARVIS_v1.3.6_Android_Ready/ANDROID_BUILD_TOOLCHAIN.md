# JARVIS Android build toolchain

This repository contains the JARVIS app source and build automation. It does **not** vendor the Android SDK or a preinstalled Gradle distribution: these are machine-level build tools, not application source files. The GitHub Actions workflow installs the Android SDK platform-tools, Android API 35 platform, and build-tools 35.0.0 on its runner. Capacitor then generates the native `android/` project and its Gradle Wrapper; the workflow builds the debug APK with `android/gradlew`.

## Build on GitHub Actions

1. Upload/push this project to a GitHub repository you control.
2. Open **Actions** and select **Build JARVIS Android APK**.
3. Select **Run workflow** (or push to `main`/`master`).
4. When the run succeeds, open it and download the `JARVIS-v1.3.6-debug-apk` artifact.

## Build locally

Install Node.js 20+, JDK 21, Android Studio / Android SDK command-line tools, and ensure `ANDROID_HOME` or `ANDROID_SDK_ROOT` points to the SDK. The script installs API 35 platform/build tools when `sdkmanager` is available, then builds the web assets, generates/syncs the Capacitor Android project, and invokes its Gradle Wrapper.

A debug APK is for testing and is not a Play Store release. This workflow has been configured but must be run in GitHub Actions to produce and verify an APK.
