# JARVIS AI Assistant — v1.3.6 Android-ready source

> v1.3.6 prepares the existing JARVIS assistant for a Capacitor Android build, including bundled web assets, native speech recognition, a configurable HTTPS backend, and narrowly scoped Android WebView CORS support. Existing agent, memory, session, task, vision, and approval features are retained.

**Mobile setup:** Read [`MOBILE_SECURITY.md`](MOBILE_SECURITY.md) first. For an Android APK source build, follow [`docs/BUILD_ANDROID.md`](docs/BUILD_ANDROID.md). This source archive does not contain a compiled APK; the Android SDK and Gradle are required to create one.

# JARVIS AI Assistant (free local starter)

A hybrid assistant project with:
- Chat UI
- Optional browser speech-to-text and text-to-speech
- Local AI through Ollama (no paid API key required)
- Backend proxy so the browser does not call the model directly
- Optional server-side cloud AI provider (OpenAI-compatible API)
- Installable PWA and Capacitor Android shell configuration

## Requirements
- Python 3.10+
- Ollama installed and running: https://ollama.com/
- A model downloaded in Ollama. Example: `ollama pull gemma4:e2b`

> Model availability, memory use, and speed depend on your device. Local AI is not guaranteed to run well on every phone/computer.

## Run locally
1. Install Python dependencies:
   ```bash
   python -m venv .venv
   ```
   Windows:
   ```powershell
   .venv\Scripts\Activate.ps1
   ```
   macOS/Linux:
   ```bash
   source .venv/bin/activate
   ```
2. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
3. Make sure Ollama is running and the model is installed:
   ```bash
   ollama pull gemma4:e2b
   ```
4. Start JARVIS:
   ```bash
   uvicorn app:app --reload
   ```
5. Open http://127.0.0.1:8000

If you use a different model, set `OLLAMA_MODEL` before running:
- macOS/Linux: `export OLLAMA_MODEL=your-model-name`
- PowerShell: `$env:OLLAMA_MODEL="your-model-name"`

## Push this starter to GitHub
Create a new empty repository on GitHub, then run these commands inside this folder:
```bash
git init
git add .
git commit -m "Add JARVIS local AI starter"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```
Replace the example repository URL with your own.

## Security notes
- This starter uses a local Ollama endpoint and has no API keys.
- Do not put API keys in frontend JavaScript or commit `.env` files.
- The server should remain bound to localhost by default. For phone access, use a private HTTPS tunnel/VPN and set `JARVIS_ACCESS_TOKEN` first; see `MOBILE_SECURITY.md`.
- Do not expose the Ollama port or this app publicly without adding authentication and rate limits.
- Browser voice recognition support varies by browser and may require an internet connection.

## Agent endpoints
- `GET /api/agents` — list available agents.
- `POST /api/chat` — route time, calculator, and explicit memory commands locally; other prompts go to Ollama.
- `GET /api/memory` — list saved memories.
- `POST /api/memory` with `{"content":"..."}` — explicitly save a memory.
- `DELETE /api/memory/{id}` — delete a saved memory.

Examples: `what time is it`, `calculate (12 + 8) * 2`, `remember that my physics chapter is electricity`, `show my memories`.

Memory is stored locally in `data/memory.sqlite3` (or the directory set by `JARVIS_DATA_DIR`). The calculator uses a restricted arithmetic parser and does not execute Python code.

## Run tests
```bash
python -m unittest discover -s tests -v
python -m compileall -q app.py jarvis tests
```

## Current scope and limitations
This is a tested foundation, not a fully autonomous desktop/phone controller. It does not yet include Browser Use, LangGraph, Mem0, OmniParser, Android automation, arbitrary shell execution, or external account actions. Those integrations require separate dependencies, platform setup, and explicit per-action permissions. General conversational responses require Ollama to be installed and running.


## Optional open-source integrations (v0.3)

The original `awesome-opensource-ai-main.zip` is a catalogue of project links, not the source trees of those projects. This release adds integration adapters rather than copying third-party repositories into the app:

- **LangGraph**: `jarvis/orchestration.py` builds a small state graph around the existing specialist router when LangGraph is installed. Without it, the built-in router is used.
- **Mem0**: `jarvis/integrations/mem0_adapter.py` adds optional semantic indexing using Mem0 OSS + local Ollama + local Qdrant. SQLite remains the source of truth. Enable with `JARVIS_ENABLE_MEM0=true`; install `requirements-mem0.txt`. The configured Ollama model must support the Mem0 LLM interface, and the embedding model (default `nomic-embed-text`) must be pulled separately.
- **Browser Use**: `jarvis/integrations/browser_use_adapter.py` is disabled by default and only supports explicitly approved read-only research. It rejects obvious account/transaction tasks. Webpage content is untrusted; do not use it for logins, purchases, submissions, downloads, or account changes. Enable only after installing `requirements-browser.txt` and Playwright browser binaries.

Install optional integrations separately:

```bash
pip install -r requirements-langgraph.txt
pip install -r requirements-mem0.txt
pip install -r requirements-browser.txt
playwright install chromium
```

Copy `.env.example` to `.env` and set options deliberately. Do not put API keys in source files. Browser Use and Mem0 are not required for the default app. The browser adapter currently exposes a Python integration point; it is not an unrestricted browser-control endpoint in the web UI.

## Integration verification

Run `python -m unittest discover -s tests -v` and `python -m compileall -q app.py jarvis tests`. Optional external packages were not installed as part of the default test run, so LangGraph, Mem0, Browser Use, Ollama, and Playwright runtime connectivity must be verified separately on the target machine.


## Architecture integration (v0.4)

The additional `claude-code-from-source-main.zip` was an educational architecture book and Astro documentation site, not runnable Claude Code source. The book explicitly says it contains no Claude Code source code. Its 18 Markdown chapters are preserved in `docs/claude-code-from-source/book/` for reference; the unrelated website renderer is not part of the JARVIS runtime.

JARVIS now includes an original centralized tool registry inspired by general patterns in that guide: validated JSON-object arguments, uniform dispatch, fail-closed approval requirements, bounded output, and conservative concurrency metadata. See `docs/ARCHITECTURE_MERGE_v0.4.md`.

New endpoints:
- `GET /api/tools` — list registered tools.
- `POST /api/tools/time.now/run` — read-only local time.
- `POST /api/tools/calculator.evaluate/run` — safe arithmetic.
- `POST /api/tools/memory.search/run` — local memory search.
- `POST /api/tools/memory.save/run` — requires `approved: true`.

The approval flag is not authentication. Keep the server local; do not expose it publicly without a proper authenticated approval flow.


## Optional REA reverse-engineering integration

JARVIS includes an optional REA discovery adapter. REA is a separate Node.js
MCP server for authorized reverse-engineering and application analysis. See
[`jarvis/integrations/REA_INTEGRATION.md`](jarvis/integrations/REA_INTEGRATION.md)
and [`jarvis/integrations/rea-mcp.json`](jarvis/integrations/rea-mcp.json).

Check its status at `GET /api/integrations/rea`. This version does not yet
connect JARVIS to MCP or execute REA tools; it only reports runtime readiness
and provides the external MCP launch configuration. No package is installed
automatically.


## REA integration (v0.5)

The supplied REA project is a separate Node.js/MCP reverse-engineering server.
JARVIS now includes an optional readiness adapter, MCP launch configuration,
and `GET /api/integrations/rea`. This is not yet a live MCP client: JARVIS does
not install or invoke REA automatically. Read
`jarvis/integrations/REA_INTEGRATION.md` and `docs/ARCHITECTURE_MERGE_v0.5.md`
before enabling it. Only inspect software and systems you are authorized to
analyze.


## Claude Code architecture study — applied patterns (v0.6)

The supplied educational repository is preserved in `docs/claude-code-from-source/` (18 chapters plus its README). JARVIS applies selected transferable ideas in original Python code: an async-generator workflow runner, a centralized fail-closed tool registry, preflight permission checks, bounded batches, and concurrency only for tools explicitly marked read-only and safe. See `docs/ARCHITECTURE_MERGE_v0.6.md` for the source-to-implementation map and limitations.

New endpoints:
- `POST /api/tools/batch/run` — execute up to 12 tools; only all-read-only, explicitly concurrency-safe batches run in parallel.
- `POST /api/agent/execute` — run a caller-supplied plan of up to 8 steps through an observable async-generator workflow. It is not autonomous LLM planning.

Run the full test suite with `python -m unittest discover -s tests -v`.

## JARVIS v0.7 — local-model planning and guarded workspace tools

The chat UI now calls `POST /api/agent/ask`. The local Ollama model returns a JSON task proposal; JARVIS validates every tool name and argument container against the registry before execution. Plans are limited to four tool calls per request. The model proposes actions, but the registry and permission layer enforce what can run.

New capabilities:
- `llm-planner`: bounded planning through Ollama's JSON response mode.
- `workspace.list`: list files inside the dedicated `workspace/` directory.
- `workspace.read`: read UTF-8 text files inside that directory (200 KB maximum).
- `workspace.write`: create/replace UTF-8 text files inside that directory (100 KB maximum); the UI shows the exact proposed tool steps and requires a separate approval click.
- Existing time, safe calculator, local memory, and optional integration endpoints remain available.

The workspace path can be changed with `JARVIS_WORKSPACE_DIR`. Workspace path traversal is rejected. There is intentionally no arbitrary shell, Python execution, unrestricted filesystem, phone control, login, purchase, or account-action tool. The approval boolean is a local development safeguard, not an authentication system; keep Uvicorn bound to localhost and do not expose this app publicly without authentication, CSRF protection, rate limits, and a stronger approval/session design.

The planner requires a running Ollama server and a model capable of following JSON output instructions. Some small models may produce malformed plans or poor task plans; JARVIS rejects malformed or unknown tool proposals rather than guessing. REA, Browser Use, LangGraph, and Mem0 remain optional integrations and are not represented as fully connected just because their adapters/configuration exist.

### v0.7 endpoints
- `POST /api/agent/ask` — ask the local model to answer or propose a bounded tool plan.
- `POST /api/agent/execute` — execute a reviewed plan; approval-required steps need `approved: true`.
- `GET /api/tools` — list tools and permission levels.
- `GET /api/health` — model connectivity and tool count.

Run checks:
```bash
python -m unittest discover -s tests -v
python -m compileall -q app.py jarvis tests
```


## v0.8 — sessions and streaming

- Local SQLite conversation sessions with create/list/get/delete endpoints.
- `/api/chat` and `/api/agent/ask` accept an optional `session_id` and save user/assistant turns.
- `/api/chat/stream` streams Ollama tokens as Server-Sent Events.
- The web UI starts a session automatically and its New chat control starts a fresh session.
- Prior sessions are available through the session API; a history sidebar is a future UI improvement.

## Review of the additional archives

See `docs/SOURCE_REVIEW_AND_V0.8.md`. The Claude Code resources catalogue is retained as documentation with its MIT license. The PikoClaw implementation was not copied because its own README says its feature and design specifications derive directly from leaked Claude Code source. The uploaded Anthropic leaked-source archive is excluded entirely; no leaked proprietary source is used or redistributed.


### v0.8 API additions
- `POST /api/sessions` — create a conversation.
- `GET /api/sessions` — list recent conversations.
- `GET /api/sessions/{id}` — restore a conversation and its messages.
- `DELETE /api/sessions/{id}` — delete a conversation.
- `POST /api/chat/stream` — stream local Ollama chat tokens as SSE.
- `/api/agent/ask` and `/api/chat` accept optional `session_id` values.

The web interface restores the most recent conversation on startup, provides a conversation-history selector, and supports starting a new conversation. Session data is local SQLite data; keep the service bound to localhost.
\n\n## v0.9 integrations\n\n- Optional AUTOMATIC1111 Stable Diffusion WebUI image generation (loopback only; explicit approval; saves to `workspace/generated/`). Enable with `JARVIS_ENABLE_STABLE_DIFFUSION=true`.\n- OhMyGame hand-off: `ohmygame.create_brief` creates an approved game brief for manual use in the separate OhMyGame app. No automatic publishing or private MCP connection.\n- See `docs/INTEGRATIONS_V0.9.md` for setup, provenance, and permission boundaries.\n
## JARVIS v1.0 — multi-role task orchestration

The UI now includes an Autonomous task workspace backed by persistent SQLite task records (`data/tasks.sqlite3`). Create a goal, ask the local Ollama planner for a bounded plan, review its tool calls, and follow execution progress. Read-only plans may run immediately. Any tool marked `approval` is held in `awaiting_approval` until the user presses Approve. Tasks can be listed, inspected, cancelled before execution, and retried after an interrupted run.

Task endpoints:
- `GET /api/tasks/roles` — describe the Planner, Researcher, Coder, Reviewer, and Executor responsibilities.
- `POST /api/tasks` with `{"goal":"..."}` — create a task.
- `GET /api/tasks` and `GET /api/tasks/{task_id}` — inspect task history and details.
- `POST /api/tasks/{task_id}/run` — plan, review, and execute eligible read-only calls.
- `POST /api/tasks/{task_id}/approve` — explicitly approve the exact persisted plan.
- `POST /api/tasks/{task_id}/cancel` — cancel queued or approval-pending tasks.
- `PATCH /api/tasks/{task_id}` — edit a queued/failed task goal with `expected_revision`; stale revisions return HTTP 409.
- `GET /api/tasks/{task_id}/events` and `POST /api/tasks/{task_id}/events` — inspect or append task history notes.

Important implementation detail: these are coordinated workflow roles, not five separately hosted LLMs. The local planner is the model-backed decision stage; researcher/coder responsibilities are constrained to registered tools and the isolated workspace; the reviewer validates proposed tool names, argument shapes, plan size, and high-impact tool names; the executor delegates to the fail-closed registry. No unrestricted shell, arbitrary Python execution, phone control, login, purchases, or external account actions are enabled. The task system is a local development foundation, not a production-grade autonomous computer operator. Keep the server bound to localhost; the approval flag is not authentication.

## Developer review and registry audit (v1.3.3)

JARVIS includes a read-only local source checker at `POST /api/code-review` and as the `code.review_source` tool. It scans supplied source text for selected risky patterns without executing or uploading it. The web UI includes a source-review panel. This is a first-pass static check, not a complete security audit.

The `GET /api/security/audit` endpoint inventories JARVIS's registered agents and tools and flags selected permission/schema risks. It does not connect to external MCP servers. The tool registry audit is also available in the web UI.

Tasks now carry a monotonically increasing revision and an append-only event timeline. Existing task databases are migrated in place. See [`docs/INTEGRATION_MERGE_V1.3.3.md`](docs/INTEGRATION_MERGE_V1.3.3.md) for the repository review, provenance, endpoints, and security boundaries.

## Screen understanding (v1.1)

JARVIS can analyze a screenshot that you explicitly select in the web UI. Install a local vision model with `ollama pull llava:7b`, then set `JARVIS_VISION_MODEL=llava:7b` in `.env`. The feature accepts PNG/JPEG/WebP files up to 8 MB and sends them only to the configured local Ollama endpoint. It provides explanations and manual suggestions; it does **not** capture the screen or control the mouse/keyboard. See `docs/SCREEN_UNDERSTANDING_V1.1.md`.

## WLED local lighting integration (v1.2)

Optional WLED control is available through the local JSON API. Set `JARVIS_ENABLE_WLED=true` and `JARVIS_WLED_URL=http://<private-device-ip>` in `.env`. `wled.status` is read-only; `wled.set_state` requires explicit approval for power, brightness, transition, and RGB segment-color changes. The adapter accepts only localhost/private IPv4 targets and blocks public hosts. See `docs/WLED_INTEGRATION_V1.2.md`.


## Agent brain hardening (v1.3.2)

JARVIS now validates registered tool argument contracts before execution. See [`docs/AGENT_BRAIN_V1.3.2.md`](docs/AGENT_BRAIN_V1.3.2.md) for the planner, reviewer, executor, and security boundaries. The implementation is original JARVIS code; no leaked Anthropic source code is included.


## Local models, AI research, and defensive scanning (v1.3.4)

JARVIS already uses Ollama for local planning, chat, and vision. Version 1.3.6 includes the local model panel and API, plus additional input and link validation:
- `GET /api/local-ai/status` and `GET /api/local-ai/models` — list installed local models.
- `POST /api/local-ai/chat` — test an installed model without downloading it.

The local model manager accepts loopback HTTP only (`localhost`, `127.0.0.1`, or another loopback address). It does not expose a remote Ollama endpoint or use environment proxies.

The AI Research Library uses the public Papers with Code catalogue:
- `POST /api/research/papers` with `query` and optional `limit` (1–10).
- Searches use the official HTTPS catalogue host and keyword mode; results include available abstracts, paper URLs, arXiv identifiers, and associated GitHub repositories.
- This is a lightweight API client, not a copy of the Papers with Code web application or its PostgreSQL/vector database stack.

The Project Security Scan is a bounded, read-only static review of selected source files. It does not run application code, send test traffic, exploit vulnerabilities, execute shell commands, or modify files. It is not a penetration test and does not replace a professional security review.

Repository inspiration and provenance:
- Ollama (`ollama/ollama`, MIT): local model runtime and REST API concepts.
- Papers with Code (`huggingface/paperswithcode`, Apache-2.0): paper catalogue and search concepts.
- Strix (`usestrix/strix`, Apache-2.0): defensive security-review workflow concepts only. Strix's active pentesting/exploitation engine and attack tooling were not integrated.

No source files were copied from these repositories. The JARVIS adapters and UI are original implementations. See `docs/INTEGRATION_MERGE_V1.3.4.md` for scope and limitations.


## v1.3.5 reliability fixes

- Hardened research catalogue response parsing so malformed or unexpected JSON shapes return an empty result set instead of crashing the route.
- Validate research links as HTTPS URLs and require exact `github.com` host matching for code links.
- Reject research API configuration containing credentials, query strings, fragments, or non-standard ports.
- Tolerate malformed optional Ollama model-detail metadata.
- Updated the recorded v1.3.4 test count and added regression coverage for these cases.


## Android APK preparation (v1.3.6)

- Updated the speech-recognition plugin to the Capacitor 7-compatible 7.0.1 release.
- Configured Capacitor to package the Vite production bundle and use relative asset paths.
- Added secure HTTPS backend URL configuration and exact-origin CORS support for Android WebView.
- Added `scripts/build-android.sh` to build and copy a debug APK when the Android SDK and Gradle are installed.
- Validation in this environment: 93 tests passed, 16 subtests passed, Python compilation and JavaScript syntax checks passed. Android APK compilation was not possible here because the Android SDK/Gradle toolchain was absent and npm registry DNS access was unavailable.
