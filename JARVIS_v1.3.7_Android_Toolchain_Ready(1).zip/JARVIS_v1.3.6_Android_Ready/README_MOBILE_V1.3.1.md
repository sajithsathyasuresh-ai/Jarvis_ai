# JARVIS v1.3.6 — Android client and backend

The Android app is a Capacitor client for the JARVIS FastAPI brain. It includes tap-to-talk speech input, conversation history, local AI/research/security panels, and an HTTPS backend URL setting.

## Build

See [`docs/BUILD_ANDROID.md`](docs/BUILD_ANDROID.md). On Linux/macOS, after installing Android Studio and the Android SDK, run `npm install` and `npm run android:build:debug`. The script creates the Capacitor Android project, synchronizes plugins, builds a debug APK, and copies it into `artifacts/`.

## Backend

Run FastAPI on a host reachable from the phone and expose it through private HTTPS/VPN. Enter the backend origin in the app's JARVIS backend URL field and tap Connect. Keep `JARVIS_ACCESS_TOKEN` and model-provider keys on the backend only. Do not expose the Ollama port directly to the public internet.

## Voice

Tap-to-talk uses the Capacitor community speech-recognition plugin. It does not listen continuously or capture audio from other apps.
