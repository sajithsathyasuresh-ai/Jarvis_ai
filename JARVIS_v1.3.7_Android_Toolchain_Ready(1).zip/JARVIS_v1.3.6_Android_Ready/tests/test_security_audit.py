import unittest
from jarvis.security_audit import audit_registry


class SecurityAuditTests(unittest.TestCase):
    def test_reports_open_schema_and_read_only_high_impact_name(self):
        report = audit_registry([
            {"name": "device.unlock", "description": "Unlock device", "permission": "read_only",
             "concurrency_safe": True, "parameters": {"type": "object", "properties": {}, "additionalProperties": True}},
            {"name": "notes.read", "description": "Read notes", "permission": "read_only",
             "concurrency_safe": True, "parameters": {"type": "object", "properties": {"q": {"type": "string", "maxLength": 50}}, "additionalProperties": False}},
        ], [{"name": "planner"}])
        rules = {finding["rule"] for finding in report["findings"]}
        self.assertIn("risky_name_read_only", rules)
        self.assertIn("missing_argument_contract", rules)
        self.assertEqual(report["tool_count"], 2)
        self.assertEqual(report["agent_count"], 1)
        self.assertEqual(report["scope"], "registered_local_tools_only")


if __name__ == "__main__":
    unittest.main()
