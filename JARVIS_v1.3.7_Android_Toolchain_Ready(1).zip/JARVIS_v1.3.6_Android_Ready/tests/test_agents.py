import tempfile
import unittest
from pathlib import Path
from jarvis.memory import MemoryStore
from jarvis.agents import AgentRouter, safe_calculate

class AgentTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.memory = MemoryStore(str(Path(self.tmp.name) / "memory.db"))
        self.router = AgentRouter(self.memory)
    def tearDown(self): self.tmp.cleanup()
    def test_calculator(self): self.assertEqual(safe_calculate("(12 + 8) * 2"), 40)
    def test_calculator_blocks_code(self):
        with self.assertRaises(ValueError): safe_calculate("__import__('os').system('id')")
    def test_time_agent(self): self.assertIn("It is", self.router.dispatch("what time is it")["answer"])
    def test_memory_roundtrip(self):
        result = self.router.dispatch("remember that my physics chapter is electricity")
        self.assertEqual(result["agent"], "memory")
        listed = self.router.dispatch("show my memories")["answer"]
        self.assertIn("electricity", listed)
    def test_unknown_routes_to_llm(self): self.assertIsNone(self.router.dispatch("explain quantum physics"))
    def test_memory_search_fallback(self):
        self.memory.add("Physics chapter: electrostatics")
        self.assertIn("electrostatics", self.memory.search("electrostatics")[0]["content"])

if __name__ == "__main__": unittest.main()
