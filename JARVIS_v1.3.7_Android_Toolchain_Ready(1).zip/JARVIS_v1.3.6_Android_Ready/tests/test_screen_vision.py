import unittest
from unittest.mock import patch

from jarvis.screen_vision import ScreenVisionAgent, validate_image, local_ollama_url

PNG = b"\x89PNG\r\n\x1a\n" + b"fake-image-data"

class ScreenVisionTests(unittest.TestCase):
    def test_validates_png_signature(self):
        validate_image(PNG, "image/png")

    def test_rejects_mime_mismatch(self):
        with self.assertRaises(ValueError):
            validate_image(PNG, "image/jpeg")

    def test_rejects_unsupported_mime(self):
        with self.assertRaises(ValueError):
            validate_image(PNG, "image/svg+xml")

    def test_rejects_empty_or_oversized_image(self):
        with self.assertRaises(ValueError):
            validate_image(b"", "image/png")
        with self.assertRaises(ValueError):
            validate_image(b"x" * (8 * 1024 * 1024 + 1), "image/png")

    def test_ollama_endpoint_must_be_loopback(self):
        self.assertEqual(local_ollama_url("http://127.0.0.1:11434/"), "http://127.0.0.1:11434")
        with self.assertRaises(ValueError):
            local_ollama_url("http://192.168.1.10:11434")

    def test_vision_agent_rejects_invalid_image_before_network(self):
        agent = ScreenVisionAgent("http://localhost:11434")
        with patch("jarvis.screen_vision.httpx.AsyncClient") as client:
            with self.assertRaises(ValueError):
                import asyncio
                asyncio.run(agent.analyze(b"not an image", "image/png"))
            client.assert_not_called()

if __name__ == "__main__":
    unittest.main()
