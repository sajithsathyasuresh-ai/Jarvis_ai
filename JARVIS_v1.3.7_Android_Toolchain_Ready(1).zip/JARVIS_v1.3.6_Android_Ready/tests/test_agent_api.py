import unittest
from unittest.mock import patch, AsyncMock
from fastapi.testclient import TestClient
import app as jarvis_app

class AgentApiTests(unittest.TestCase):
    def setUp(self): self.client = TestClient(jarvis_app.app)

    def test_approval_plan_is_returned_without_writing(self):
        plan = {"use_tools": True, "steps": [{"name":"workspace.write", "arguments":{"path":"approval-test.txt", "content":"approved"}}], "response":"Proposed a file write."}
        with patch("app.create_plan", new=AsyncMock(return_value=plan)):
            response = self.client.post("/api/agent/ask", json={"message":"Create a file"})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["approval_required"])
        self.assertFalse((jarvis_app.WORKSPACE.root / "approval-test.txt").exists())

    def test_readonly_plan_executes(self):
        plan = {"use_tools": True, "steps": [{"name":"calculator.evaluate", "arguments":{"expression":"2+2"}}], "response":"Calculated."}
        with patch("app.create_plan", new=AsyncMock(return_value=plan)):
            response = self.client.post("/api/agent/ask", json={"message":"Calculate two plus two"})
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.json().get("approval_required", False))
        self.assertEqual(response.json()["events"][-1]["type"], "completed")

if __name__ == "__main__": unittest.main()
