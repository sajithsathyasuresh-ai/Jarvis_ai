import unittest
from unittest.mock import patch, AsyncMock
from fastapi.testclient import TestClient
import app as jarvis_app

class TaskApiTests(unittest.TestCase):
    def setUp(self): self.client=TestClient(jarvis_app.app)
    def test_create_and_get_task(self):
        created=self.client.post("/api/tasks",json={"goal":"Check project files"})
        self.assertEqual(created.status_code,200)
        tid=created.json()['task']['id']
        fetched=self.client.get(f"/api/tasks/{tid}")
        self.assertEqual(fetched.status_code,200)
        self.assertEqual(fetched.json()['task']['status'],"queued")
    def test_run_read_only_task(self):
        tid=self.client.post("/api/tasks",json={"goal":"Calculate 2+2"}).json()['task']['id']
        plan={"use_tools":True,"steps":[{"name":"calculator.evaluate","arguments":{"expression":"2+2"}}],"response":"Done"}
        with patch("jarvis.task_orchestrator.create_plan",new=AsyncMock(return_value=plan)):
            response=self.client.post(f"/api/tasks/{tid}/run")
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.json()['task']['status'],"completed")
    def test_write_task_requires_approval(self):
        tid=self.client.post("/api/tasks",json={"goal":"Create a file"}).json()['task']['id']
        plan={"use_tools":True,"steps":[{"name":"workspace.write","arguments":{"path":"v10-approval-test.txt","content":"hello"}}],"response":"Proposed"}
        with patch("jarvis.task_orchestrator.create_plan",new=AsyncMock(return_value=plan)):
            response=self.client.post(f"/api/tasks/{tid}/run")
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.json()['task']['status'],"awaiting_approval")
        self.assertFalse((jarvis_app.WORKSPACE.root/"v10-approval-test.txt").exists())
        approved=self.client.post(f"/api/tasks/{tid}/approve")
        self.assertEqual(approved.status_code,200)
        self.assertEqual(approved.json()['task']['status'],"completed")
        (jarvis_app.WORKSPACE.root/"v10-approval-test.txt").unlink(missing_ok=True)

if __name__=="__main__": unittest.main()
