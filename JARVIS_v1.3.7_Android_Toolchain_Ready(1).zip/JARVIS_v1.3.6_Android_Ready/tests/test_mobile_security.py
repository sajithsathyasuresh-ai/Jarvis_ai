import unittest
from unittest.mock import patch
from fastapi.testclient import TestClient
import app as jarvis_app

class MobileSecurityTests(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(jarvis_app.app)

    def test_protected_api_requires_bearer_token_when_configured(self):
        with patch.object(jarvis_app, "ACCESS_TOKEN", "test-token-which-is-not-real"):
            denied = self.client.get("/api/sessions")
            allowed = self.client.get("/api/sessions", headers={"Authorization": "Bearer test-token-which-is-not-real"})
        self.assertEqual(denied.status_code, 401)
        self.assertEqual(allowed.status_code, 200)

    def test_health_and_auth_check_remain_available_for_bootstrap(self):
        with patch.object(jarvis_app, "ACCESS_TOKEN", "test-token-which-is-not-real"):
            health = self.client.get("/api/health")
            auth = self.client.post("/api/auth/check", headers={"Authorization": "Bearer test-token-which-is-not-real"})
        self.assertEqual(health.status_code, 200)
        self.assertTrue(health.json()["auth_required"])
        self.assertEqual(auth.status_code, 200)

    def test_pwa_assets_and_root_scope_service_worker(self):
        self.assertEqual(self.client.get("/static/manifest.webmanifest").status_code, 200)
        worker = self.client.get("/sw.js")
        self.assertEqual(worker.status_code, 200)
        self.assertEqual(worker.headers.get("service-worker-allowed"), "/")

    def test_capacitor_origin_cors_preflight_is_allowed(self):
        response = self.client.options(
            "/api/sessions",
            headers={
                "Origin": "https://localhost",
                "Access-Control-Request-Method": "GET",
                "Access-Control-Request-Headers": "authorization",
            },
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.headers.get("access-control-allow-origin"), "https://localhost")

    def test_unlisted_origin_is_not_reflected_by_cors(self):
        response = self.client.options(
            "/api/sessions",
            headers={
                "Origin": "https://untrusted.example",
                "Access-Control-Request-Method": "GET",
                "Access-Control-Request-Headers": "authorization",
            },
        )
        self.assertNotEqual(response.headers.get("access-control-allow-origin"), "https://untrusted.example")

    def test_relative_bundle_assets_have_backend_routes(self):
        self.assertEqual(self.client.get("/manifest.webmanifest").status_code, 200)
        self.assertEqual(self.client.get("/icon.svg").status_code, 200)

if __name__ == "__main__":
    unittest.main()
