import unittest
from unittest.mock import patch
from jarvis.planner import create_plan, PlannerError

class FakeResponse:
    def raise_for_status(self): pass
    def json(self): return {"message":{"content":'{"use_tools":true,"steps":[{"name":"calculator.evaluate","arguments":{"expression":"2+2"}}],"response":"I will calculate."}'}}

class FakeClient:
    def __init__(self, *a, **kw): pass
    async def __aenter__(self): return self
    async def __aexit__(self, *a): pass
    async def post(self, *a, **kw): return FakeResponse()

class PlannerTests(unittest.TestCase):
    def test_validates_and_returns_tool_plan(self):
        import asyncio
        with patch('jarvis.planner.httpx.AsyncClient', FakeClient):
            result = asyncio.run(create_plan('calculate 2+2', ollama_url='http://local', model='test', tools=[{"name":"calculator.evaluate","permission":"read_only","description":"calculator"}]))
        self.assertEqual(result['steps'][0]['name'], 'calculator.evaluate')
    def test_unknown_tool_rejected(self):
        import asyncio
        class BadResponse(FakeResponse):
            def json(self): return {"message":{"content":'{"use_tools":true,"steps":[{"name":"shell.run","arguments":{}}],"response":""}'}}
        class BadClient(FakeClient):
            async def post(self, *a, **kw): return BadResponse()
        with patch('jarvis.planner.httpx.AsyncClient', BadClient):
            with self.assertRaises(PlannerError):
                asyncio.run(create_plan('do something', ollama_url='http://local', model='test', tools=[]))

if __name__ == "__main__": unittest.main()
