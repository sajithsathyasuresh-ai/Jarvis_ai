import tempfile
import unittest
from pathlib import Path
from jarvis.session_store import SessionStore

class SessionStoreTests(unittest.TestCase):
    def test_create_append_and_get(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = SessionStore(str(Path(tmp) / "sessions.sqlite3"))
            session = store.create()
            store.append(session["id"], "user", "Hello JARVIS")
            store.append(session["id"], "assistant", "Hello.")
            result = store.get(session["id"])
            self.assertEqual([m["role"] for m in result["messages"]], ["user", "assistant"])
            self.assertEqual(result["title"], "Hello JARVIS")

    def test_missing_session(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = SessionStore(str(Path(tmp) / "sessions.sqlite3"))
            with self.assertRaises(KeyError):
                store.append("missing", "user", "Hello")

    def test_delete(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = SessionStore(str(Path(tmp) / "sessions.sqlite3"))
            session = store.create()
            self.assertTrue(store.delete(session["id"]))
            self.assertIsNone(store.get(session["id"]))

if __name__ == "__main__":
    unittest.main()
