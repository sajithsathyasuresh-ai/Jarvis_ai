import unittest
from unittest.mock import AsyncMock, patch
from fastapi.testclient import TestClient
import app as jarvis_app


class FakeLocalOllama:
    base_url = "http://127.0.0.1:11434"

    async def models(self):
        return {"connected": True, "base_url": self.base_url, "count": 1,
                "models": [{"name": "gemma4:2b", "size": 123, "modified_at": "", "family": "gemma"}]}

    async def chat(self, model, message):
        return {"model": model, "answer": f"Local response: {message}", "done": True}


class V134ApiTests(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(jarvis_app.app)

    def test_local_model_inventory_and_chat_routes(self):
        with patch.object(jarvis_app, "OLLAMA_LOCAL", FakeLocalOllama()):
            inventory = self.client.get("/api/local-ai/models")
            self.assertEqual(inventory.status_code, 200)
            self.assertEqual(inventory.json()["models"][0]["name"], "gemma4:2b")
            chat = self.client.post("/api/local-ai/chat", json={"model": "gemma4:2b", "message": "Hello"})
            self.assertEqual(chat.status_code, 200)
            self.assertIn("Local response", chat.json()["answer"])

    def test_research_route_uses_catalog_adapter(self):
        expected = {"query": "transformers", "count": 0, "papers": [], "source": "Papers with Code public catalogue", "read_only": True}
        with patch.object(jarvis_app.RESEARCH_CATALOG, "search", new=AsyncMock(return_value=expected)) as search:
            response = self.client.post("/api/research/papers", json={"query": "transformers", "limit": 5})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["source"], "Papers with Code public catalogue")
        search.assert_awaited_once_with("transformers", 5)

    def test_research_route_rejects_too_short_query(self):
        response = self.client.post("/api/research/papers", json={"query": "x"})
        self.assertEqual(response.status_code, 422)

    def test_project_scan_route_is_static_and_read_only(self):
        response = self.client.post("/api/security/scan-project")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["mode"], "local_read_only_project_static_scan")
        self.assertIn("No network probes", response.json()["note"])


if __name__ == "__main__":
    unittest.main()
