import unittest
from jarvis.tool_system import ToolRegistry, ToolSpec

class ToolRegistryTests(unittest.TestCase):
    def setUp(self):
        self.registry = ToolRegistry()
        self.registry.register(ToolSpec("read", "safe read", permission="read_only"),
                               lambda args: args.get("value", "ok"))
        self.registry.register(ToolSpec("write", "writes a note", permission="approval"),
                               lambda args: "saved")

    def test_read_tool_needs_no_approval(self):
        self.assertEqual(self.registry.invoke("read", {"value":"yes"})["result"], "yes")

    def test_write_tool_fails_closed(self):
        with self.assertRaises(PermissionError):
            self.registry.invoke("write", {})

    def test_write_tool_with_approval(self):
        self.assertEqual(self.registry.invoke("write", {}, approved=True)["result"], "saved")

    def test_unknown_tool_rejected(self):
        with self.assertRaises(KeyError):
            self.registry.invoke("not-real", {})

    def test_duplicate_tool_rejected(self):
        with self.assertRaises(ValueError):
            self.registry.register(ToolSpec("read", "duplicate"), lambda args: "no")

if __name__ == "__main__":
    unittest.main()
