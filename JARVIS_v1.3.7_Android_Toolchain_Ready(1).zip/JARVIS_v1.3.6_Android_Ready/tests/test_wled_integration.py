import unittest
from unittest.mock import patch

from jarvis.integrations.wled import WLEDAdapter, _private_base_url


class FakeResponse:
    def __init__(self, payload):
        self._payload = payload
        self.content = b"{}"
    def raise_for_status(self):
        return None
    def json(self):
        return self._payload


class FakeClient:
    def __init__(self, *args, **kwargs):
        self.calls = []
    def __enter__(self):
        return self
    def __exit__(self, *args):
        return False
    def get(self, url):
        if url.endswith("/json/state"):
            return FakeResponse({"on": True, "bri": 128, "ps": 2, "seg": [{}, {}]})
        return FakeResponse({"name": "Desk LEDs", "ver": "0.15.0", "leds": {"count": 60}})
    def post(self, url, json):
        self.calls.append((url, json))
        return FakeResponse({"success": True})


class WLEDIntegrationTests(unittest.TestCase):
    def test_accepts_local_private_ipv4_and_localhost(self):
        self.assertEqual(_private_base_url("http://192.168.1.25/"), "http://192.168.1.25")
        self.assertEqual(_private_base_url("http://localhost:8080"), "http://localhost:8080")

    def test_rejects_public_hostnames_and_https(self):
        for url in ("https://192.168.1.25", "http://example.com", "http://8.8.8.8", "http://192.168.1.2/path"):
            with self.subTest(url=url), self.assertRaises(ValueError):
                _private_base_url(url)

    def test_status_reads_state_and_info(self):
        adapter = WLEDAdapter("http://192.168.1.25")
        with patch("jarvis.integrations.wled.httpx.Client", FakeClient):
            result = adapter.status()
        self.assertTrue(result["connected"])
        self.assertEqual(result["device"]["led_count"], 60)
        self.assertEqual(result["state"]["brightness"], 128)
        self.assertEqual(result["state"]["segment_count"], 2)

    def test_set_state_builds_supported_json_payload(self):
        adapter = WLEDAdapter("http://192.168.1.25")
        with patch("jarvis.integrations.wled.httpx.Client", FakeClient):
            result = adapter.set_state({"on": True, "brightness": 100, "transition_ms": 500, "color": "#12aBef", "segment_id": 1})
        self.assertEqual(result["sent"], {"on": True, "bri": 100, "transition": 500, "seg": [{"id": 1, "col": [[18, 171, 239]]}]})

    def test_rejects_unsupported_or_invalid_state(self):
        adapter = WLEDAdapter("http://192.168.1.25")
        for args in ({"on": 1}, {"brightness": 0}, {"color": "red"}, {"preset": 4}, {"segment_id": 1}):
            with self.subTest(args=args), self.assertRaises(ValueError):
                adapter.set_state(args)


if __name__ == "__main__":
    unittest.main()
