import unittest
from fastapi.testclient import TestClient
import app as jarvis_app


class V133ApiTests(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(jarvis_app.app)

    def test_task_event_and_revision_api(self):
        created = self.client.post("/api/tasks", json={"goal": "Document a task"})
        self.assertEqual(created.status_code, 200)
        task = created.json()["task"]
        tid = task["id"]
        self.assertEqual(task["revision"], 1)
        note = self.client.post(f"/api/tasks/{tid}/events", json={"message": "Requirement confirmed"})
        self.assertEqual(note.status_code, 200)
        events = self.client.get(f"/api/tasks/{tid}/events").json()["events"]
        self.assertEqual(events[-1]["detail"]["message"], "Requirement confirmed")
        patched = self.client.patch(f"/api/tasks/{tid}", json={"goal": "Updated task", "expected_revision": 1})
        self.assertEqual(patched.status_code, 200)
        self.assertEqual(patched.json()["task"]["revision"], 2)
        stale = self.client.patch(f"/api/tasks/{tid}", json={"goal": "Stale task", "expected_revision": 1})
        self.assertEqual(stale.status_code, 409)

    def test_code_review_endpoint_is_read_only(self):
        response = self.client.post("/api/code-review", json={"filename": "demo.py", "content": "x = eval(user_input)"})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(any(x["rule_id"] == "JRV001" for x in response.json()["findings"]))

    def test_security_audit_is_local_metadata_only(self):
        response = self.client.get("/api/security/audit")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["scope"], "registered_local_tools_only")
        self.assertGreaterEqual(response.json()["tool_count"], 1)


if __name__ == "__main__":
    unittest.main()
