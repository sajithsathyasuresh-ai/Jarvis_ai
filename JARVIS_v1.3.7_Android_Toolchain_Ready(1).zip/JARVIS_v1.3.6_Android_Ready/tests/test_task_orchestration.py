import tempfile, unittest
from unittest.mock import AsyncMock, patch
from jarvis.task_store import TaskStore
from jarvis.task_orchestrator import TaskOrchestrator
from jarvis.tool_system import ToolRegistry, ToolSpec

class TaskOrchestrationTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.store=TaskStore(self.tmp.name+"/tasks.sqlite3")
        self.registry=ToolRegistry()
        self.registry.register(ToolSpec("read.value","Read a value",permission="read_only",concurrency_safe=True),lambda a: a.get("value", "ok"))
        self.registry.register(ToolSpec("write.value","Write a value",permission="approval"),lambda a: {"saved":a.get("value")} )
        self.orch=TaskOrchestrator(self.store,self.registry,ollama_url="http://localhost:11434",model="test")
    async def asyncTearDown(self): self.tmp.cleanup()
    async def test_read_only_task_runs_to_completion(self):
        task=self.store.create("Read the value")
        plan={"use_tools":True,"steps":[{"name":"read.value","arguments":{"value":"ready"}}],"response":"Read done"}
        with patch("jarvis.task_orchestrator.create_plan",new=AsyncMock(return_value=plan)):
            result=await self.orch.plan(task['id'])
        self.assertEqual(result['status'],"completed")
        self.assertEqual(result['result']['events'][-1]['type'],"completed")
    async def test_write_waits_for_explicit_approval(self):
        task=self.store.create("Write a value")
        plan={"use_tools":True,"steps":[{"name":"write.value","arguments":{"value":"approved"}}],"response":"Write proposed"}
        with patch("jarvis.task_orchestrator.create_plan",new=AsyncMock(return_value=plan)):
            result=await self.orch.plan(task['id'])
        self.assertEqual(result['status'],"awaiting_approval")
        self.assertEqual(result['plan']['steps'][0]['name'],"write.value")
        result=await self.orch.execute(task['id'],approved=True)
        self.assertEqual(result['status'],"completed")
    def test_interrupted_task_is_marked_retryable(self):
        task=self.store.create("A task that was interrupted")
        self.store.update(task['id'],status="running")
        self.assertEqual(self.store.recover_interrupted(),1)
        recovered=self.store.get(task['id'])
        self.assertEqual(recovered['status'],"failed")
        self.assertEqual(recovered['result']['stage'],"interrupted")
    def test_reviewer_rejects_unknown_tool(self):
        with self.assertRaises(ValueError): self.orch.review([{"name":"shell.exec","arguments":{}}])
