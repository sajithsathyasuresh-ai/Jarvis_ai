import unittest
from jarvis.tool_system import ToolRegistry, ToolSpec


class ToolSchemaTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.calls = []
        self.registry = ToolRegistry()
        self.registry.register(
            ToolSpec(
                "notes.save", "Save a short note", permission="approval",
                parameters={
                    "type": "object",
                    "properties": {"content": {"type": "string", "minLength": 1, "maxLength": 20}},
                    "required": ["content"],
                    "additionalProperties": False,
                },
            ),
            lambda args: self.calls.append(args["content"]) or {"saved": True},
        )

    def test_valid_arguments_are_accepted(self):
        self.assertEqual(
            self.registry.invoke("notes.save", {"content": "hello"}, approved=True)["permission"],
            "approval",
        )

    def test_missing_required_argument_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "Missing required"):
            self.registry.invoke("notes.save", {}, approved=True)

    def test_unknown_argument_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "Unsupported argument"):
            self.registry.invoke("notes.save", {"content": "ok", "extra": "no"}, approved=True)

    def test_length_limit_is_enforced(self):
        with self.assertRaisesRegex(ValueError, "invalid length"):
            self.registry.invoke("notes.save", {"content": "x" * 21}, approved=True)

    async def test_invalid_later_call_prevents_partial_batch_execution(self):
        with self.assertRaises(ValueError):
            await self.registry.invoke_batch(
                [
                    {"name": "notes.save", "arguments": {"content": "first"}},
                    {"name": "notes.save", "arguments": {"content": "second", "unexpected": True}},
                ],
                approved=True,
            )
        self.assertEqual(self.calls, [])


if __name__ == "__main__":
    unittest.main()
