from jarvis.news import NewsStore, plain


def test_plain_text_removes_markup():
    assert plain('<b>Breaking</b> &amp; updates') == 'Breaking & updates'


def test_news_store_starts_empty(tmp_path):
    store = NewsStore(str(tmp_path / 'news.sqlite3'))
    assert store.list() == []
