import tempfile
import unittest
from pathlib import Path
from jarvis.workspace_tools import Workspace

class WorkspaceToolTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ws = Workspace(self.tmp.name)
    def tearDown(self): self.tmp.cleanup()
    def test_write_then_read(self):
        self.ws.write_file({"path":"notes/test.txt", "content":"hello"})
        self.assertEqual(self.ws.read_file({"path":"notes/test.txt"})["content"], "hello")
    def test_path_traversal_rejected(self):
        with self.assertRaises(ValueError): self.ws.read_file({"path":"../../outside.txt"})
    def test_read_size_limit(self):
        p = Path(self.tmp.name) / "large.txt"
        p.write_text("x" * 200001)
        with self.assertRaises(ValueError): self.ws.read_file({"path":"large.txt"})
    def test_list_files(self):
        self.ws.write_file({"path":"a.txt", "content":"x"})
        self.assertIn("a.txt", self.ws.list_files({}))

if __name__ == "__main__": unittest.main()
