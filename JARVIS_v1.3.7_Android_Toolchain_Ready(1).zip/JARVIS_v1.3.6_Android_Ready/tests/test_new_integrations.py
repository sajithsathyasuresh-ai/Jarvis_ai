import base64
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from jarvis.integrations.stable_diffusion import StableDiffusionWebUI, _local_base_url
from jarvis.integrations.ohmygame_adapter import create_game_brief, status as ohmygame_status


class FakeResponse:
    def raise_for_status(self):
        return None
    def json(self):
        return {"images": [base64.b64encode(b"\x89PNG\r\n\x1a\nFAKEPNG").decode()]}


class NewIntegrationTests(unittest.TestCase):
    def test_stable_diffusion_rejects_remote_endpoint(self):
        with self.assertRaises(ValueError):
            _local_base_url("http://192.168.1.20:7860")
        with self.assertRaises(ValueError):
            _local_base_url("https://127.0.0.1:7860")

    def test_stable_diffusion_accepts_loopback(self):
        self.assertEqual(_local_base_url("http://127.0.0.1:7860/"), "http://127.0.0.1:7860")

    def test_image_generation_saves_only_validated_image_to_workspace(self):
        with tempfile.TemporaryDirectory() as tmp:
            adapter = StableDiffusionWebUI("http://127.0.0.1:7860", tmp)
            with patch("jarvis.integrations.stable_diffusion.httpx.post", return_value=FakeResponse()):
                result = adapter.generate({"prompt": "A calm landscape", "steps": 5})
            self.assertTrue((Path(tmp) / result["saved"]).is_file())
            self.assertTrue(result["saved"].startswith("generated/"))

    def test_image_generation_validates_prompt_and_steps(self):
        with tempfile.TemporaryDirectory() as tmp:
            adapter = StableDiffusionWebUI("http://localhost:7860", tmp)
            with self.assertRaises(ValueError):
                adapter.generate({"prompt": ""})
            with self.assertRaises(ValueError):
                adapter.generate({"prompt": "valid", "steps": 100})

    def test_ohmygame_brief_is_written_to_workspace(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = create_game_brief({"title": "Orbit", "concept": "A small space puzzle."}, tmp)
            content = (Path(tmp) / result["saved"]).read_text()
            self.assertIn("# Orbit", content)
            self.assertIn("Do not publish", content)

    def test_ohmygame_is_handoff_not_live_connection(self):
        self.assertFalse(ohmygame_status()["connected"])


if __name__ == "__main__":
    unittest.main()
