import asyncio
import unittest
from jarvis.tool_system import ToolRegistry, ToolSpec
from jarvis.agent_loop import run_tool_plan

class AgentLoopTests(unittest.TestCase):
    def setUp(self):
        self.registry = ToolRegistry()
        self.registry.register(ToolSpec("read.one", "safe", permission="read_only", concurrency_safe=True), lambda a: a["v"])
        self.registry.register(ToolSpec("write.one", "mutating", permission="approval"), lambda a: "written")

    def test_parallel_batch_preserves_input_order(self):
        async def run():
            return await self.registry.invoke_batch([
                {"name": "read.one", "arguments": {"v": "first"}},
                {"name": "read.one", "arguments": {"v": "second"}},
            ])
        result = asyncio.run(run())
        self.assertEqual([x["result"] for x in result], ["first", "second"])

    def test_approval_preflight_prevents_partial_execution(self):
        ran = []
        registry = ToolRegistry()
        registry.register(ToolSpec("safe", "safe", permission="read_only", concurrency_safe=True), lambda a: ran.append("safe"))
        registry.register(ToolSpec("write", "write", permission="approval"), lambda a: ran.append("write"))
        async def run():
            with self.assertRaises(PermissionError):
                await registry.invoke_batch([{"name":"safe"}, {"name":"write"}], approved=False)
        asyncio.run(run())
        self.assertEqual(ran, [])

    def test_mutating_tools_cannot_be_concurrency_safe(self):
        with self.assertRaises(ValueError):
            ToolSpec("bad", "bad", permission="approval", concurrency_safe=True)
            self.registry.register(ToolSpec("bad", "bad", permission="approval", concurrency_safe=True), lambda a: None)

    def test_workflow_emits_completion(self):
        async def run():
            events = []
            async for event in run_tool_plan(self.registry, [[{"name":"read.one", "arguments":{"v":"ok"}}]]):
                events.append(event)
            return events
        events = asyncio.run(run())
        self.assertEqual(events[-1]["type"], "completed")

    def test_workflow_turn_limit(self):
        async def run():
            async for _ in run_tool_plan(self.registry, [[]] * 9):
                pass
        with self.assertRaises(ValueError):
            asyncio.run(run())

if __name__ == "__main__":
    unittest.main()
