import os
import unittest
from jarvis.orchestration import Orchestrator
from jarvis.integrations.browser_use_adapter import BrowserResearchAgent
from jarvis.integrations.rea_adapter import rea_status

class DummyRouter:
    def dispatch(self, message): return {"agent": "dummy", "answer": message}

class IntegrationTests(unittest.TestCase):
    def test_rea_status_has_mcp_configuration(self):
        old = os.environ.pop("JARVIS_ENABLE_REA", None)
        try:
            status = rea_status()
            self.assertEqual(status["connection"], "external_mcp_host_required")
            self.assertEqual(status["mcp_config"]["args"][-1], "mcp")
            self.assertFalse(status["enabled"])
        finally:
            if old is not None:
                os.environ["JARVIS_ENABLE_REA"] = old

    def test_orchestrator_fallback(self):
        result = Orchestrator(DummyRouter()).dispatch("hello")
        self.assertEqual(result["answer"], "hello")
    def test_browser_disabled_by_default(self):
        old = os.environ.pop("JARVIS_ENABLE_BROWSER", None)
        try:
            with self.assertRaises(RuntimeError):
                import asyncio
                asyncio.run(BrowserResearchAgent().research("summarize a public science article", approved=True))
        finally:
            if old is not None: os.environ["JARVIS_ENABLE_BROWSER"] = old
    def test_browser_requires_approval(self):
        os.environ["JARVIS_ENABLE_BROWSER"] = "true"
        try:
            with self.assertRaises(PermissionError):
                import asyncio
                asyncio.run(BrowserResearchAgent().research("summarize a public science article", approved=False))
        finally:
            os.environ.pop("JARVIS_ENABLE_BROWSER", None)
    def test_browser_blocks_transactional_task(self):
        os.environ["JARVIS_ENABLE_BROWSER"] = "true"
        try:
            with self.assertRaises(PermissionError):
                import asyncio
                asyncio.run(BrowserResearchAgent().research("purchase a product", approved=True))
        finally:
            os.environ.pop("JARVIS_ENABLE_BROWSER", None)

if __name__ == "__main__": unittest.main()
