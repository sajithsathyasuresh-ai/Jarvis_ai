import unittest
from fastapi.testclient import TestClient
from app import app

class SessionApiTests(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_session_crud(self):
        created = self.client.post("/api/sessions", json={"title":"Test chat"})
        self.assertEqual(created.status_code, 200)
        sid = created.json()["session"]["id"]
        self.assertEqual(self.client.get(f"/api/sessions/{sid}").status_code, 200)
        self.assertTrue(any(s["id"] == sid for s in self.client.get("/api/sessions").json()["sessions"]))
        self.assertEqual(self.client.delete(f"/api/sessions/{sid}").status_code, 200)

    def test_missing_session(self):
        self.assertEqual(self.client.get("/api/sessions/no-such-session").status_code, 404)

if __name__ == "__main__":
    unittest.main()
