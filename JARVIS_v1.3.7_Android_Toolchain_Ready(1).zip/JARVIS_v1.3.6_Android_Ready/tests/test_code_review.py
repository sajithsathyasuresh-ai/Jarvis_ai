import unittest
from jarvis.code_review import review_source


class CodeReviewTests(unittest.TestCase):
    def test_detects_common_high_risk_patterns(self):
        source = """\nimport os, subprocess\nvalue = eval(user_input)\nos.system(command)\nsubprocess.run(command, shell=True)\nrequests.get(url, verify=False)\n"""
        result = review_source(source, "sample.py")
        ids = {finding["rule_id"] for finding in result["findings"]}
        self.assertTrue({"JRV001", "JRV003", "JRV004", "JRV006"}.issubset(ids))
        self.assertEqual(result["mode"], "local_static_rules")
        self.assertEqual(result["filename"], "sample.py")

    def test_secret_placeholder_is_not_reported(self):
        result = review_source('API_KEY = "your_example_key_goes_here"')
        self.assertFalse(any(f["rule_id"] == "JRV007" for f in result["findings"]))

    def test_rejects_oversized_or_empty_source(self):
        with self.assertRaises(ValueError):
            review_source("  ")
        with self.assertRaises(ValueError):
            review_source("x" * 100001)


if __name__ == "__main__":
    unittest.main()
