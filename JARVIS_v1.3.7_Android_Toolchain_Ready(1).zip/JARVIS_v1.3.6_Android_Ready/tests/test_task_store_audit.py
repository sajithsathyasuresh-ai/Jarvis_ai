import sqlite3
import tempfile
import unittest
from pathlib import Path

from jarvis.task_store import RevisionConflict, TaskStore


class TaskStoreAuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / "tasks.sqlite3")
        self.store = TaskStore(self.path)

    def tearDown(self):
        self.temp.cleanup()

    def test_task_creation_and_updates_are_logged(self):
        task = self.store.create("Prepare a project plan")
        self.assertEqual(task["revision"], 1)
        self.store.update(task["id"], status="planning", result={"stage": "planner"})
        events = self.store.events(task["id"])
        self.assertEqual([event["event_type"] for event in events], ["created", "updated"])
        self.assertEqual(events[-1]["detail"]["to_status"], "planning")
        self.assertEqual(events[-1]["detail"]["stage"], "planner")

    def test_stale_revision_is_rejected(self):
        task = self.store.create("Initial goal")
        current = self.store.update(task["id"], goal="Updated goal", expected_revision=1, actor="user")
        self.assertEqual(current["revision"], 2)
        with self.assertRaises(RevisionConflict):
            self.store.update(task["id"], goal="Stale write", expected_revision=1, actor="user")
        self.assertEqual(self.store.get(task["id"])["goal"], "Updated goal")

    def test_notes_are_append_only_events(self):
        task = self.store.create("Track a feature")
        note = self.store.append_event(task["id"], "Reviewed the requirements")
        self.assertEqual(note["event_type"], "note")
        self.assertEqual(note["detail"]["message"], "Reviewed the requirements")
        self.assertEqual(self.store.get(task["id"])["revision"], 1)

    def test_existing_database_is_migrated(self):
        old_path = str(Path(self.temp.name) / "old.sqlite3")
        with sqlite3.connect(old_path) as db:
            db.execute("""CREATE TABLE tasks (
                id TEXT PRIMARY KEY, goal TEXT NOT NULL, status TEXT NOT NULL,
                plan TEXT NOT NULL DEFAULT '{}', result TEXT NOT NULL DEFAULT '{}',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
            db.execute("INSERT INTO tasks(id,goal,status) VALUES('old-id','Old task','queued')")
        migrated = TaskStore(old_path)
        self.assertEqual(migrated.get("old-id")["revision"], 1)
        self.assertEqual(migrated.events("old-id"), [])


if __name__ == "__main__":
    unittest.main()
