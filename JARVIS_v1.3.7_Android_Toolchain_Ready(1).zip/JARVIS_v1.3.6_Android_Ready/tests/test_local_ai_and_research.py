import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from jarvis.integrations.ollama_adapter import OllamaLocalAdapter
from jarvis.research_catalog import ResearchCatalog
from jarvis.code_review import review_project, review_source


class LocalAIAndResearchTests(unittest.TestCase):
    def test_ollama_only_accepts_loopback_http(self):
        self.assertEqual(OllamaLocalAdapter("http://127.0.0.1:11434/").base_url, "http://127.0.0.1:11434")
        self.assertEqual(OllamaLocalAdapter("http://localhost:11434").base_url, "http://localhost:11434")
        self.assertEqual(OllamaLocalAdapter("http://[::1]:11434").base_url, "http://[::1]:11434")
        for url in ("https://127.0.0.1:11434", "http://192.168.1.5:11434", "http://user:pass@localhost:11434", "http://localhost:11434/api"):
            with self.subTest(url=url), self.assertRaises(ValueError):
                OllamaLocalAdapter(url)

    def test_research_catalog_rejects_non_official_hosts(self):
        with self.assertRaises(ValueError):
            ResearchCatalog("https://example.com/api/v1")
        with self.assertRaises(ValueError):
            ResearchCatalog("http://paperswithcode.co/api/v1")

    def test_research_catalog_rejects_credentials_and_nonstandard_ports(self):
        for url in (
            "https://user:pass@paperswithcode.co/api/v1",
            "https://paperswithcode.co:444/api/v1",
            "https://paperswithcode.co/api/v1?next=https://example.com",
        ):
            with self.subTest(url=url), self.assertRaises(ValueError):
                ResearchCatalog(url)

    def test_research_catalog_external_links_are_validated(self):
        safe = ResearchCatalog._safe_https_url
        self.assertEqual(safe("https://arxiv.org/abs/1234.5678"), "https://arxiv.org/abs/1234.5678")
        self.assertEqual(safe("https://github.com.evil.example/project", host="github.com"), "")
        self.assertEqual(safe("https://user:pass@github.com/org/repo", host="github.com"), "")
        self.assertEqual(safe("http://github.com/org/repo", host="github.com"), "")

    def test_research_catalog_query_bounds(self):
        import asyncio
        catalog = ResearchCatalog()
        with self.assertRaises(ValueError):
            asyncio.run(catalog.search("x"))
        with self.assertRaises(ValueError):
            asyncio.run(catalog.search("valid query", 11))

    def test_static_rules_include_yaml_and_unsafe_temp_file(self):
        report = review_source("yaml.load(untrusted)\ntempfile.mktemp()\nhashlib.md5(data)")
        self.assertEqual(report["findings_count"], 3)
        self.assertEqual({x["rule_id"] for x in report["findings"]}, {"JRV011", "JRV012", "JRV013"})

    def test_project_scan_is_bounded_and_skips_data_directories(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.py").write_text("eval(user_input)\n", encoding="utf-8")
            (root / "data").mkdir()
            (root / "data" / "secret.py").write_text("eval(secret)\n", encoding="utf-8")
            report = review_project(tmp)
        self.assertEqual(report["files_scanned"], 1)
        self.assertEqual(report["findings_count"], 1)
        self.assertIn("app.py", report["findings"][0]["filename"])
        self.assertIn("No network probes", report["note"])


if __name__ == "__main__":
    unittest.main()
