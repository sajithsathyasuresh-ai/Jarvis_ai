import { defineConfig } from 'vite';

export default defineConfig({
  root: 'static',
  base: './',
  publicDir: '../mobile-public',
  build: { outDir: '../static-dist', emptyOutDir: true, assetsDir: 'assets' }
});
