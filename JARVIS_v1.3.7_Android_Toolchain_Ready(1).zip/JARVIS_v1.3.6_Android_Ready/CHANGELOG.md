## v1.3.6 — Android app preparation
- Updated speech recognition to the Capacitor 7-compatible 7.0.1 plugin.
- Configured a Vite-built web bundle for Capacitor with relative WebView asset paths.
- Added configurable HTTPS backend URL support in the Android client.
- Added exact-origin CORS support for the default Capacitor Android WebView origins.
- Added a reproducible debug APK build script and Android setup guide.
- Validation: 93 tests passed, 16 subtests passed; Python compilation and JavaScript syntax checks passed. APK compilation requires Android SDK/Gradle and was not available in the current environment.

## v1.3.5 — Reliability and link-validation fixes

- Hardened Papers with Code response parsing and external URL validation.
- Hardened Ollama model inventory parsing for malformed optional metadata.
- Added regression tests for credentialed/non-standard catalogue URLs and unsafe repository links.
- Validation: 90 tests passed, 16 subtests passed; 4 existing FastAPI lifecycle deprecation warnings remain.

## v1.3.4 — Local model control, research search, and defensive source scanning

- Added a bounded local Ollama adapter for installed-model discovery and test chats. It accepts loopback HTTP only, disables environment proxy use, and never downloads models.
- Added read-only Papers with Code catalogue search with fixed HTTPS host, bounded query/result sizes, and normalized paper/code links.
- Expanded local static source checks and added a bounded project scan. No exploit execution, network probing, active penetration testing, shell access, or automatic code changes were added.
- Added Local Model Manager, AI Research Library, and Project Security Scan panels to the web/mobile interface.
- Updated the web entry point to load the module script correctly.
- Validation: 84 tests passed; 13 subtests passed; JavaScript syntax and Python compilation checks passed. Existing FastAPI lifecycle deprecation warnings remain.

# Changelog

## v1.3.3 — Task audit trail, code review, and registry security audit
- Added in-place SQLite migration for task revisions and append-only task event history.
- Added optimistic concurrency checks for user task edits and a 409 response for stale revisions.
- Added task event APIs and a task history display in the web UI.
- Added an offline, read-only source review tool and web panel with bounded input and deterministic security checks.
- Added a read-only local agent/tool inventory and argument-schema audit endpoint and web panel.
- Reviewed Todo for AI, Gito, and Cross-Code Organizer as high-level architecture references; no repository source code, assets, algorithms, external services, or dependencies were copied or merged.
- Explicitly excluded leaked-source-derived implementations and constants referenced in upstream Cross-Code Organizer documentation.

## v1.3.2 — Typed tool contracts and stronger agent review
- Added a small JSON-Schema-style argument validator to the original JARVIS tool registry.
- Added required-field, type, length, numeric-range, enum, and unknown-field checks before tool handlers run.
- Added argument schemas to core workspace, memory, calculator, time, WLED, image, and project-brief tools.
- Exposed argument contracts to the planner so it can prepare more accurate tool calls.
- Strengthened task review to validate every proposed tool call against its registered contract before execution.
- Added regression tests proving invalid calls are rejected and invalid batches cannot partially execute.
- Used the linked repository only to identify general agent architecture concepts; no leaked Anthropic source code was copied or merged.


## v1.3.0 — Hybrid mobile foundation
- Added installable PWA shell, manifest, icon, and offline caching for static app assets only.
- Added Capacitor Android project configuration and APK build instructions.
- Added optional OpenAI-compatible cloud chat/planning provider; credentials remain server-side.
- Added optional bearer-token protection for API routes and a session-only mobile token entry.
- Preserved v1.2 memory, session, task, planner, approval, vision, and tool registry features.
- Added mobile deployment and security guidance. Native phone-control actions remain disabled.


## v0.8.0
- Added persistent SQLite conversation sessions.
- Added session create/list/restore/delete APIs.
- Added Ollama Server-Sent Events streaming endpoint.
- Added conversation history selector and new-chat control to the web UI.
- Added provenance review for the three newly supplied archives.
- Preserved the MIT-licensed Claude Code resources catalogue README and license as reference documentation.
- Did not incorporate Anthropic leaked source code or PikoClaw implementation code due the source provenance described in `docs/SOURCE_REVIEW_AND_V0.8.md`.
- Retained all existing JARVIS v0.7 features and approval controls.
\n## v0.9.0\n- Added optional, loopback-only AUTOMATIC1111 Stable Diffusion WebUI adapter with approval-gated image generation saved inside the JARVIS workspace.\n- Added an approval-gated OhMyGame game-brief hand-off tool and integration status endpoint.\n- Added integration provenance, security boundaries, and retained third-party license notices.\n
## v1.0.0
- Added persistent SQLite task tracking with queued, planning, approval-pending, running, completed, failed, and cancelled states.
- Added coordinated Planner, Researcher, Coder, Reviewer, and Executor workflow responsibilities.
- Added plan review before execution, automatic execution for eligible read-only calls, and explicit approval for mutating tools.
- Added task create/list/get/run/approve/cancel APIs and a task workspace UI.
- Added restart recovery that marks interrupted in-flight tasks as retryable failures.
- Added tests for task persistence, plan review, approval gating, API behavior, and interruption recovery.

## v1.1.0
- Added local-only screenshot understanding through an Ollama vision model (default `llava:7b`).
- Added image type/signature validation and an 8 MB upload limit.
- Added a screen-understanding panel for user-selected screenshots.
- Explicitly kept desktop automation disabled: no screen capture, mouse/keyboard actions, shell access, or remote endpoint access.

## v1.2
- Added optional, private-network-only WLED JSON API integration.
- Added read-only device status and approval-gated power/brightness/transition/RGB controls.
- Added integration status endpoint, configuration example, documentation, and adapter tests.
- No WLED firmware/source code is bundled; the supplied changelog is used only as project-history context.

## v1.3.1 — Android voice and background news
- Added Capacitor native speech-recognition dependency for tap-to-talk in Android builds, retaining browser speech input as PWA fallback.
- Added scheduled HTTPS RSS/Atom collection, cached headlines, and user-triggered refresh.
- News feed content is rendered as text and article links only; no fetched content is executed.
- Added Google-account storage guidance: Drive is for private encrypted backups, not for running the backend. No Google account was accessed.
- Automatic self-modifying code updates are intentionally not enabled; software updates require owner review and approval.
