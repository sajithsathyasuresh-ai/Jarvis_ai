import { SpeechRecognition } from '@capacitor-community/speech-recognition';

  const chat = document.querySelector('#chat');
  const form = document.querySelector('#form');
  const input = document.querySelector('#message');
  const send = document.querySelector('#send');
  const statusEl = document.querySelector('#status');
  let latestAnswer = '';
  let sessionId = null;
  let activeTaskId = null;
  const tokenKey = 'jarvis_access_token_v13';
  const backendKey = 'jarvis_backend_url_v136';
  const tokenInput = document.querySelector('#access-token');
  const backendInput = document.querySelector('#backend-url');
  let backendBaseUrl = localStorage.getItem(backendKey) || '';
  tokenInput.value = sessionStorage.getItem(tokenKey) || '';
  backendInput.value = backendBaseUrl;

  function normalizeBackendUrl(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    const parsed = new URL(raw);
    const isLoopback = ['localhost', '127.0.0.1', '[::1]'].includes(parsed.hostname);
    if (parsed.username || parsed.password || parsed.search || parsed.hash || (parsed.pathname !== '/' && parsed.pathname !== '')) {
      throw new Error('Enter only the backend origin, without credentials, path, query or fragment.');
    }
    if (parsed.protocol !== 'https:' && !(isLoopback && parsed.protocol === 'http:')) {
      throw new Error('Use HTTPS for remote JARVIS connections. HTTP is allowed only for localhost testing.');
    }
    return parsed.origin;
  }

  function apiUrl(path) {
    return backendBaseUrl ? `${backendBaseUrl}${path}` : path;
  }

  async function apiFetch(url, options = {}) {
    const headers = new Headers(options.headers || {});
    const token = sessionStorage.getItem(tokenKey);
    if (token) headers.set('Authorization', `Bearer ${token}`);
    return window.fetch(apiUrl(url), {...options, headers});
  }

  document.querySelector('#connect').addEventListener('click', async () => {
    try {
      backendBaseUrl = normalizeBackendUrl(backendInput.value);
      if (!backendBaseUrl && window.Capacitor?.isNativePlatform?.()) {
        throw new Error('Enter your JARVIS backend HTTPS URL before connecting.');
      }
      if (backendBaseUrl) localStorage.setItem(backendKey, backendBaseUrl);
      else localStorage.removeItem(backendKey);
      const token = tokenInput.value.trim();
      const headers = token ? {Authorization: `Bearer ${token}`} : {};
      const res = await window.fetch(apiUrl('/api/auth/check'), {method:'POST', headers});
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Authentication failed.');
      if (token) sessionStorage.setItem(tokenKey, token);
      else sessionStorage.removeItem(tokenKey);
      statusEl.textContent = '● Connected to JARVIS gateway';
      await refreshSessions();
      await checkHealth();
      await loadNews();
    } catch (err) { statusEl.textContent = `● ${err.message}`; }
  });

  let installPrompt = null;
  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault(); installPrompt = event;
    document.querySelector('#install').hidden = false;
  });
  document.querySelector('#install').addEventListener('click', async () => {
    if (!installPrompt) return;
    installPrompt.prompt(); await installPrompt.userChoice; installPrompt = null;
    document.querySelector('#install').hidden = true;
  });
  if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));

  function addMessage(text, who) {
    const el = document.createElement('div');
    el.className = `msg ${who}`;
    el.textContent = text;
    chat.appendChild(el);
    chat.scrollTop = chat.scrollHeight;
    return el;
  }

  async function refreshSessions() {
    const select = document.querySelector('#history');
    try {
      const res = await apiFetch('/api/sessions');
      const data = await res.json();
      select.replaceChildren(new Option('Conversation history', ''));
      for (const item of (data.sessions || [])) {
        select.add(new Option(item.title, item.id));
      }
      select.value = sessionId || '';
    } catch { /* History is optional when offline. */ }
  }

  async function loadSession(id) {
    if (!id) return;
    try {
      const res = await apiFetch(`/api/sessions/${encodeURIComponent(id)}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Could not load conversation.');
      sessionId = data.session.id;
      chat.replaceChildren();
      for (const message of data.session.messages || []) {
        addMessage(message.content, message.role === 'user' ? 'user' : 'assistant');
      }
      if (!chat.children.length) addMessage('Conversation restored. Continue when ready.', 'assistant');
      await refreshSessions();
    } catch (err) {
      addMessage(`History error: ${err.message}`, 'assistant');
    }
  }

  async function startSession() {
    try {
      const res = await apiFetch('/api/sessions', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({title: 'New conversation'})
      });
      const data = await res.json();
      if (res.ok) { sessionId = data.session.id; await refreshSessions(); }
    } catch { /* Chat remains usable without session persistence. */ }
  }

  async function checkHealth() {
    try {
      const res = await apiFetch('/api/health');
      const data = await res.json();
      statusEl.textContent = data.ok
        ? `● Connected · Model: ${data.model}`
        : `● Not connected · ${data.detail}`;
    } catch {
      statusEl.textContent = '● Cannot check AI connection. Is the JARVIS server running?';
    }
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const message = input.value.trim();
    if (!message || send.disabled) return;
    addMessage(message, 'user');
    input.value = '';
    send.disabled = true;
    const waiting = addMessage('Thinking…', 'assistant');
    try {
      const res = await apiFetch('/api/agent/ask', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({message, session_id: sessionId})
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Request failed.');
      latestAnswer = data.answer || '';
      waiting.textContent = (data.agent ? `[${data.agent} agent]\n` : '') + (data.answer || 'Task completed.');
      if (data.approval_required && Array.isArray(data.steps)) {
        const preview = document.createElement('pre');
        preview.textContent = JSON.stringify(data.steps, null, 2);
        waiting.appendChild(preview);
        const approve = document.createElement('button');
        approve.type = 'button';
        approve.textContent = 'Review complete — approve and execute';
        approve.addEventListener('click', async () => {
          approve.disabled = true;
          approve.textContent = 'Executing approved steps…';
          try {
            const run = await apiFetch('/api/agent/execute', {
              method: 'POST', headers: {'Content-Type':'application/json'},
              body: JSON.stringify({steps: data.steps, approved: true})
            });
            const result = await run.json();
            if (!run.ok) throw new Error(result.detail || 'Execution failed.');
            approve.textContent = 'Approved steps completed';
            const output = document.createElement('pre');
            output.textContent = JSON.stringify(result.events, null, 2);
            waiting.appendChild(output);
          } catch (err) {
            approve.disabled = false;
            approve.textContent = 'Retry approval';
            addMessage(`Execution error: ${err.message}`, 'assistant');
          }
        });
        waiting.appendChild(approve);
      }
      if (Array.isArray(data.events) && data.events.length) {
        const output = document.createElement('pre');
        output.textContent = JSON.stringify(data.events, null, 2);
        waiting.appendChild(output);
      }
    } catch (err) {
      waiting.textContent = `Error: ${err.message}`;
      await refreshSessions();
    } finally {
      send.disabled = false;
      input.focus();
      chat.scrollTop = chat.scrollHeight;
    }
  });


  document.querySelector('#analyze-screen').addEventListener('click', async () => {
    const file = document.querySelector('#screen-file').files[0];
    const button = document.querySelector('#analyze-screen');
    const output = document.querySelector('#screen-output');
    if (!file) { output.style.display='block'; output.textContent='Choose a screenshot first.'; return; }
    if (!['image/png','image/jpeg','image/webp'].includes(file.type) || file.size > 8*1024*1024) {
      output.style.display='block'; output.textContent='Choose a PNG, JPEG, or WebP image under 8 MB.'; return;
    }
    button.disabled=true; output.style.display='block'; output.textContent='Analyzing locally…';
    try {
      const res=await apiFetch('/api/vision/analyze',{method:'POST',headers:{'Content-Type':file.type},body:file});
      const data=await res.json(); if(!res.ok) throw new Error(data.detail || 'Screenshot analysis failed.');
      output.textContent=`Model: ${data.model}\n\n${data.analysis}\n\nComputer actions are manual only; JARVIS has not clicked or typed anything.`;
    } catch(err) { output.textContent=`Screen analysis error: ${err.message}`; }
    finally { button.disabled=false; }
  });

  document.querySelector('#run-code-review').addEventListener('click', async () => {
    const button = document.querySelector('#run-code-review');
    const output = document.querySelector('#code-review-output');
    const content = document.querySelector('#review-source').value;
    const filename = document.querySelector('#review-filename').value.trim() || '<input>';
    output.style.display = 'block';
    if (!content.trim()) { output.textContent = 'Paste source code first.'; return; }
    button.disabled = true; output.textContent = 'Running local static checks…';
    try {
      const res = await apiFetch('/api/code-review', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({content,filename})});
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Code review failed.');
      output.textContent = JSON.stringify(data, null, 2);
    } catch (err) { output.textContent = `Code review error: ${err.message}`; }
    finally { button.disabled = false; }
  });

  document.querySelector('#run-security-audit').addEventListener('click', async () => {
    const button = document.querySelector('#run-security-audit');
    const output = document.querySelector('#security-audit-output');
    button.disabled = true; output.style.display = 'block'; output.textContent = 'Inspecting registered tool metadata…';
    try {
      const res = await apiFetch('/api/security/audit');
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Security audit failed.');
      output.textContent = JSON.stringify(data, null, 2);
    } catch (err) { output.textContent = `Security audit error: ${err.message}`; }
    finally { button.disabled = false; }
  });

  document.querySelector('#task-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const goal = document.querySelector('#task-goal').value.trim();
    const button = document.querySelector('#task-run');
    const output = document.querySelector('#task-output');
    if (!goal || button.disabled) return;
    button.disabled = true; output.style.display = 'block'; output.textContent = 'Creating task…';
    try {
      const created = await apiFetch('/api/tasks', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({goal})});
      const createdData = await created.json();
      if (!created.ok) throw new Error(createdData.detail || 'Could not create task.');
      activeTaskId = createdData.task.id;
      output.textContent = `Task ${activeTaskId} created. Planner is preparing a reviewed plan…`;
      const run = await apiFetch(`/api/tasks/${encodeURIComponent(activeTaskId)}/run`, {method:'POST'});
      const runData = await run.json();
      if (!run.ok) throw new Error(runData.detail || 'Task planning failed.');
      renderTask(runData.task, output);
    } catch (err) { output.textContent = `Task error: ${err.message}`; }
    finally { button.disabled = false; }
  });

  async function loadTaskEvents(taskId, output) {
    try {
      const res = await apiFetch(`/api/tasks/${encodeURIComponent(taskId)}/events`);
      const data = await res.json();
      if (!res.ok) return;
      const panel = document.createElement('div');
      panel.style.marginTop = '12px';
      const heading = document.createElement('strong');
      heading.textContent = 'Append-only task history';
      panel.appendChild(heading);
      const list = document.createElement('ol');
      for (const event of data.events || []) {
        const item = document.createElement('li');
        const detail = event.detail || {};
        const label = detail.message || detail.stage || (detail.to_status ? `${detail.from_status || 'created'} → ${detail.to_status}` : (detail.changed_fields || []).join(', '));
        item.textContent = `${event.event_type} · ${event.actor}${label ? ` · ${label}` : ''}`;
        list.appendChild(item);
      }
      panel.appendChild(list);
      output.appendChild(panel);
    } catch { /* Task history is supplementary when offline. */ }
  }

  function renderTask(task, output) {
    output.replaceChildren();
    const summary = document.createElement('div');
    summary.textContent = `Task status: ${task.status} · Revision: ${task.revision}\nGoal: ${task.goal}\nRoles: ${(task.plan.roles || []).join(' → ') || 'Planner'}`;
    output.appendChild(summary);
    const details = document.createElement('pre');
    details.textContent = JSON.stringify(task.status === 'awaiting_approval' ? task.plan : task.result, null, 2);
    output.appendChild(details);
    if (task.status === 'awaiting_approval') {
      const approve = document.createElement('button'); approve.type='button'; approve.textContent='Approve proposed actions';
      approve.addEventListener('click', async () => {
        approve.disabled=true; approve.textContent='Executing…';
        try {
          const res=await apiFetch(`/api/tasks/${encodeURIComponent(task.id)}/approve`,{method:'POST'});
          const data=await res.json(); if(!res.ok) throw new Error(data.detail || 'Approval failed.');
          renderTask(data.task,output);
        } catch(err) { approve.disabled=false; approve.textContent='Retry approval'; addMessage(`Task approval error: ${err.message}`,'assistant'); }
      });
      output.appendChild(approve);
      const cancel=document.createElement('button'); cancel.type='button'; cancel.className='secondary'; cancel.textContent='Cancel task';
      cancel.addEventListener('click',async()=>{const res=await apiFetch(`/api/tasks/${encodeURIComponent(task.id)}/cancel`,{method:'POST'});const data=await res.json();if(res.ok)renderTask(data.task,output);else addMessage(data.detail || 'Could not cancel task.','assistant');});
      output.appendChild(cancel);
    }
    void loadTaskEvents(task.id, output);
  }

  document.querySelector('#history').addEventListener('change', (event) => loadSession(event.target.value));

  document.querySelector('#clear').addEventListener('click', async () => {
    chat.replaceChildren();
    latestAnswer = '';
    sessionId = null;
    await startSession();
    addMessage('New conversation started. What would you like to do?', 'assistant');
  });

  document.querySelector('#speak').addEventListener('click', () => {
    if (!latestAnswer) return;
    if (!('speechSynthesis' in window)) {
      addMessage('Text-to-speech is not supported by this browser.', 'assistant');
      return;
    }
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(new SpeechSynthesisUtterance(latestAnswer));
  });

  document.querySelector('#mic').addEventListener('click', async () => {
    // Native speech recognition is used only inside the Capacitor Android app.
    try {
      if (window.Capacitor?.isNativePlatform?.()) {
        const available = await SpeechRecognition.available();
        if (!available?.available) throw new Error('Native speech recognition is unavailable on this device.');
        let permission = await SpeechRecognition.checkPermissions();
        if (permission?.speechRecognition !== 'granted') {
          permission = await SpeechRecognition.requestPermissions();
        }
        if (permission?.speechRecognition !== 'granted') {
          throw new Error('Microphone and speech-recognition permission was not granted.');
        }
        const result = await SpeechRecognition.start({language:'en-IN', maxResults:1, prompt:'Speak to JARVIS', popup:true, partialResults:false});
        const matches = result?.matches || [];
        if (matches.length) { input.value = matches[0]; input.focus(); }
        else addMessage('No speech was recognized. Please try again.', 'assistant');
        return;
      }
      const BrowserSpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!BrowserSpeechRecognition) throw new Error('Voice input is unavailable in this browser. Use the JARVIS Android app or a supported browser.');
      const recognition = new BrowserSpeechRecognition();
      recognition.lang = 'en-IN'; recognition.interimResults = false; recognition.maxAlternatives = 1;
      recognition.onresult = (event) => { input.value = event.results[0][0].transcript; input.focus(); };
      recognition.onerror = () => addMessage('Voice input failed. Check microphone permission and try again.', 'assistant');
      recognition.start();
    } catch (err) { addMessage(err.message || 'Voice input failed.', 'assistant'); }
  });

  async function loadNews() {
    const target = document.querySelector('#news-list');
    try {
      const res = await apiFetch('/api/news');
      if (!res.ok) throw new Error('Connect to JARVIS to load news.');
      const data = await res.json(); target.replaceChildren();
      if (!data.articles?.length) { target.textContent = 'No headlines cached yet. Use Refresh news.'; return; }
      data.articles.forEach(article => {
        const card = document.createElement('article'); card.style.cssText='padding:10px 0;border-top:1px solid var(--line)';
        const link = document.createElement('a'); link.href=article.url; link.target='_blank'; link.rel='noopener noreferrer'; link.textContent=article.title; link.style.cssText='color:var(--accent);font-weight:700';
        const summary = document.createElement('p'); summary.textContent=article.summary || ''; summary.style.cssText='margin:6px 0;color:var(--muted)';
        const source = document.createElement('small'); source.textContent=article.source || 'News source';
        card.append(link, summary, source); target.append(card);
      });
    } catch (err) { target.textContent = err.message; }
  }
  document.querySelector('#news-refresh').addEventListener('click', async () => {
    const button=document.querySelector('#news-refresh'); button.disabled=true; button.textContent='Refreshing…';
    try { const res=await apiFetch('/api/news/refresh',{method:'POST'}); if(!res.ok) throw new Error('News refresh failed. Connect first.'); await loadNews(); }
    catch(err) { addMessage(err.message,'assistant'); }
    finally { button.disabled=false; button.textContent='Refresh news'; }
  });

  (async () => {
    await refreshSessions();
    const history = document.querySelector('#history');
    if (history.options.length > 1) await loadSession(history.options[1].value);
    else await startSession();
  })();
  if (backendBaseUrl || !window.Capacitor?.isNativePlatform?.()) { checkHealth(); loadNews(); }
  else statusEl.textContent = '● Enter your private JARVIS backend HTTPS URL, then tap Connect.';

  async function refreshOllamaModels() {
    const status = document.querySelector('#ollama-status');
    const select = document.querySelector('#ollama-model');
    status.textContent = 'Checking local Ollama…';
    try {
      const res = await apiFetch('/api/local-ai/models');
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Local model check failed.');
      select.replaceChildren(new Option('Choose an installed model', ''));
      for (const model of data.models || []) select.add(new Option(model.name, model.name));
      status.textContent = `${data.count} installed model(s) · ${data.base_url}`;
    } catch (err) { status.textContent = err.message; }
  }
  document.querySelector('#ollama-refresh').addEventListener('click', refreshOllamaModels);
  document.querySelector('#ollama-chat-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const output = document.querySelector('#ollama-output');
    const button = document.querySelector('#ollama-send');
    const model = document.querySelector('#ollama-model').value;
    const message = document.querySelector('#ollama-message').value.trim();
    output.style.display = 'block';
    if (!model || !message) { output.textContent = 'Choose an installed model and enter a message.'; return; }
    button.disabled = true; output.textContent = 'Waiting for local model…';
    try {
      const res = await apiFetch('/api/local-ai/chat', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model,message})});
      const data = await res.json(); if (!res.ok) throw new Error(data.detail || 'Local model request failed.');
      output.textContent = `[${data.model}]\n\n${data.answer}`;
    } catch (err) { output.textContent = err.message; }
    finally { button.disabled = false; }
  });

  document.querySelector('#research-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const target = document.querySelector('#research-results');
    const button = document.querySelector('#research-search');
    const query = document.querySelector('#research-query').value.trim();
    if (query.length < 2) { target.textContent = 'Enter at least two characters.'; return; }
    button.disabled = true; target.textContent = 'Searching the research catalogue…';
    try {
      const res = await apiFetch('/api/research/papers', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query,limit:8})});
      const data = await res.json(); if (!res.ok) throw new Error(data.detail || 'Research search failed.');
      target.replaceChildren();
      if (!data.papers?.length) { target.textContent = 'No matching papers were returned.'; return; }
      data.papers.forEach(paper => {
        const card = document.createElement('article'); card.style.cssText='padding:12px 0;border-top:1px solid var(--line)';
        const heading = document.createElement('strong'); heading.textContent = paper.title;
        const abstract = document.createElement('p'); abstract.textContent = paper.abstract || 'No abstract available.'; abstract.style.cssText='margin:6px 0;color:var(--muted)';
        card.append(heading, abstract);
        if (paper.paper_url) { const a=document.createElement('a'); a.href=paper.paper_url; a.target='_blank'; a.rel='noopener noreferrer'; a.textContent='Open paper'; a.style.color='var(--accent)'; card.append(a); }
        if (paper.code_urls?.length) { const links=document.createElement('p'); links.style.margin='6px 0'; paper.code_urls.forEach((url,i)=>{ if(i) links.append(' · '); const a=document.createElement('a'); a.href=url; a.target='_blank'; a.rel='noopener noreferrer'; a.textContent='Code repository'; a.style.color='var(--accent)'; links.append(a); }); card.append(links); }
        target.append(card);
      });
    } catch (err) { target.textContent = err.message; }
    finally { button.disabled = false; }
  });

  document.querySelector('#run-project-scan').addEventListener('click', async () => {
    const button=document.querySelector('#run-project-scan');
    const output=document.querySelector('#project-scan-output');
    output.style.display='block'; button.disabled=true; output.textContent='Scanning local source files…';
    try {
      const res=await apiFetch('/api/security/scan-project',{method:'POST'});
      const data=await res.json(); if(!res.ok) throw new Error(data.detail || 'Project scan failed.');
      output.textContent=`Files scanned: ${data.files_scanned}\nFindings: ${data.findings_count}\nSeverity: ${JSON.stringify(data.severity_counts)}\n\n${(data.findings || []).map(f=>`${f.severity.toUpperCase()} ${f.rule_id} · ${f.filename}:${f.line}\n${f.message}\nFix: ${f.recommendation}`).join('\n\n') || 'No matches from the configured static rules.'}\n\n${data.note}`;
    } catch(err) { output.textContent=err.message; }
    finally { button.disabled=false; }
  });
