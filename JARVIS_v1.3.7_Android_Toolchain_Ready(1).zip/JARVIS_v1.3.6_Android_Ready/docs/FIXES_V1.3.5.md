# JARVIS v1.3.5 fixes

This patch addresses robustness issues found during a follow-up review of v1.3.4.

## Changes

- Papers with Code API responses are now type-checked before fields are accessed. Unexpected payload shapes safely produce no paper results instead of raising an attribute error.
- External research links must be HTTPS, contain no embedded credentials, and use the default HTTPS port. Code repository links must use the exact `github.com` hostname; lookalike domains are rejected.
- Research catalogue configuration rejects embedded credentials, query strings, fragments, and non-standard ports.
- Ollama model inventory parsing tolerates malformed optional `details` metadata.
- Documentation now records the verified v1.3.4 test count accurately.

## Validation

- `python -m pytest -q`: 90 passed, 4 existing FastAPI `on_event` deprecation warnings, 16 subtests passed.
- `python -m compileall -q app.py jarvis tests`: passed.
- `node --check static/app.js`: passed.
- ZIP integrity verified after packaging.

## Remaining limitations

- Ollama requires a running local server and an installed model.
- Research search requires internet access and the public catalogue service to be available.
- The static scanner is a limited defensive aid, not a complete security audit.
- No Android APK was built.
