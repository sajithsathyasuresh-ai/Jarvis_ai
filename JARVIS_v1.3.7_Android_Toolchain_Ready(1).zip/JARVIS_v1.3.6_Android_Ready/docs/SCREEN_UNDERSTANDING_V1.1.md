# JARVIS v1.1 — Screen understanding

JARVIS v1.1 adds **user-selected screenshot analysis**, not autonomous desktop control.

## Setup

1. Install and start Ollama locally.
2. Pull a vision-capable model, for example `ollama pull llava:7b`.
3. Set `JARVIS_VISION_MODEL=llava:7b` in `.env` (or choose another Ollama vision model).
4. Start JARVIS and open its local web interface.
5. In **Screen understanding**, select a PNG, JPEG, or WebP screenshot (maximum 8 MB) and choose **Analyze screenshot**.

The screenshot is sent to the local Ollama server configured by `OLLAMA_URL`. The adapter only accepts localhost/loopback HTTP endpoints. Image bytes are checked against the declared MIME type before processing.

## Boundaries

- JARVIS does not capture the screen; the user chooses the image.
- JARVIS does not move the mouse, type, click, launch applications, or run shell commands.
- It only describes the image and suggests manual next steps.
- Text in screenshots is treated as untrusted content, not as instructions for JARVIS.
- Do not upload screenshots containing passwords, authentication codes, private messages, or other sensitive information.
- A vision model must be installed separately. If Ollama is offline or the model is missing, analysis will fail with a visible error.

This is an intentionally limited first step toward safer computer assistance. Any future desktop actions need a separate design with narrow allowlists, visible previews, per-action confirmation, and an emergency stop.
