# JARVIS v0.6 — architecture patterns adapted from the supplied Claude Code study

## Source boundary

The supplied `claude-code-from-source-main` repository describes itself as an educational book containing original pseudocode, not Claude Code's implementation. JARVIS does not copy proprietary Claude Code code. The complete 18-chapter Markdown book and its README are preserved under `docs/claude-code-from-source/` for continued reference.

## Implemented patterns

| Source-guide topic | JARVIS adaptation | Status |
|---|---|---|
| Chapter 5 — async-generator agent loop | `jarvis/agent_loop.py` emits step-started, step-completed, and terminal events | Implemented for caller-supplied plans; no autonomous LLM planning claim |
| Chapter 6 — centralized tool lifecycle and permissions | `jarvis/tool_system.py` registry, output bounds, approval preflight | Implemented |
| Chapter 7 — partition safe concurrent tools from serial tools | `ToolRegistry.invoke_batch()` runs only explicitly marked read-only tools concurrently; mixed/mutating batches run sequentially | Implemented |
| Chapter 10 — task/turn limits and coordination | Bounded workflow steps and ordered results | Basic primitive only; no multi-agent swarm |
| Chapter 11 — memory taxonomy and recall | Existing SQLite/Mem0 memory retained; taxonomy documented for future migration | Design reference; schema not silently changed |
| Chapter 12 — snapshot configuration / hooks | Existing fail-closed registry retained; immutable hook snapshot not implemented | Future work |
| Chapter 15 — MCP client and tool wrapping | REA remains an external MCP integration configuration | No live MCP client yet |

## New API

- `POST /api/tools/batch/run`: executes 1–12 calls. It preflights the entire batch before any action. A batch is concurrent only if every tool is explicitly declared both read-only and concurrency-safe. Other batches execute serially. Results preserve request order.
- `POST /api/agent/execute`: executes 1–8 caller-supplied steps through an async-generator workflow. This is a workflow runner, not an autonomous model planner.

## Safety model

The `approved` boolean is a local development gate, not identity authentication or a secure approval token. Keep the server bound to localhost. Do not expose these endpoints to a network without authentication, CSRF protections, rate limits, audit logging, and a stronger per-action approval mechanism. No arbitrary shell, file-write, account, or device-control tool is registered by this change.

## Deliberately not implemented

The source guide discusses speculative execution during model streaming, context compaction, prompt-cache optimization, fork agents, swarms, OAuth, multiple MCP transports, and terminal UI internals. JARVIS does not claim these are implemented. They require separate tested designs and runtime dependencies.
