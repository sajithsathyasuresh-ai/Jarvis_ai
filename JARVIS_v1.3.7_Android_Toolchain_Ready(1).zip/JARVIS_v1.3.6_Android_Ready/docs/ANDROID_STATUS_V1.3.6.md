# Android preparation changes — v1.3.6

- Updated `@capacitor-community/speech-recognition` from the Capacitor 6 line to 7.0.1 for the Capacitor 7 project.
- Changed the Capacitor web directory to the Vite production bundle (`static-dist`) so the native app loads bundled dependencies rather than an unbundled bare npm import.
- Switched asset paths to relative paths so the same build works from the Android WebView origin.
- Added a backend URL field. The app stores the selected HTTPS backend origin locally and directs API requests there.
- Added narrowly scoped CORS origins for Capacitor's default Android origins; remote backend connections still require HTTPS.
- Added `scripts/build-android.sh` to build and copy a local debug APK when Android SDK, Gradle, and package dependencies are available.

The APK has not been compiled in the current workspace because Android SDK/Gradle are absent and the package registry could not be reached from this environment. See `docs/BUILD_ANDROID.md` for the local build steps.
