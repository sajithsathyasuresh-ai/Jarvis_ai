# JARVIS Agent Brain — v1.3.2

## Purpose

This is an original JARVIS implementation. The linked `tanbiralam/claude-code` repository was reviewed only as a high-level architecture reference. Its README identifies the contents as leaked Anthropic source code and states that the original source belongs to Anthropic. No source files, implementation code, or proprietary text from that repository were copied into JARVIS.

## Architecture ideas applied independently

- A central registry describes each tool and its permission level.
- The planner proposes structured actions; it does not execute tools directly.
- A reviewer checks tool identity, argument shape, and permission level.
- The executor runs only validated calls through the registry.
- Read-only calls may run concurrently only when explicitly marked safe.
- Changes to workspace files, memory, devices, or generated assets remain approval-gated.
- Outputs are bounded to reduce accidental memory and response growth.

## v1.3.2 implementation

`jarvis/tool_system.py` now supports a restricted JSON-Schema-style contract on each `ToolSpec`. The supported checks are object shape, required fields, additional-property rejection, primitive types, string length, numeric bounds, and enumerated values.

`jarvis/planner.py` includes each tool's argument contract in the planning context. `jarvis/task_orchestrator.py` asks the registry to validate every proposed call before deciding whether a plan can run. `ToolRegistry.invoke_batch` preflights every call before executing any call, preventing a malformed later item from causing a partially executed batch.

## Security boundaries

- The schema validator is intentionally small and is not a complete JSON Schema implementation.
- Tool handlers must continue to validate domain-specific constraints (for example, workspace path containment and image dimensions).
- A model-generated plan is untrusted input.
- Mutating tools still require explicit approval.
- This version does not add shell execution, arbitrary code execution, automatic account access, unattended device control, or self-modifying source code.
- Keep cloud API keys and access tokens on the backend; do not place them in Android assets or frontend JavaScript.

## Verification

The regression suite includes tests for missing fields, unknown fields, wrong types, invalid lengths, and all-or-nothing batch preflight. Run:

```bash
python -m pytest -q
```
