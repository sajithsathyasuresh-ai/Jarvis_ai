# JARVIS v0.9 integration review

## AUTOMATIC1111 Stable Diffusion WebUI

The supplied archive is a Gradio-based Stable Diffusion web UI. JARVIS adds an
optional adapter for its documented local HTTP API (`/sdapi/v1/txt2img`).
Enable it explicitly with `JARVIS_ENABLE_STABLE_DIFFUSION=true` and start the
WebUI separately with its API enabled. JARVIS accepts only HTTP loopback
addresses (`localhost`, `127.0.0.1`, or another loopback IP), limits dimensions
to 256–1024, steps to 1–30, and saves one validated PNG/JPEG into
`workspace/generated/`. The `image.generate` tool is approval-required.
The WebUI is not bundled or started by JARVIS. Do not enable arbitrary Python
execution in the WebUI (`--allow-code`) for this integration.

The upstream archive is licensed under AGPL-3.0. JARVIS does not copy its
application source; its license notice is retained in `docs/third_party/`.

## OhMyGame

The supplied OhMyGame archive describes a local-first AI game creation studio,
including project workspaces, agents, media workflows, plugins, and an MCP
server. JARVIS adds an approval-required `ohmygame.create_brief` tool that
writes a game brief into the isolated JARVIS workspace for manual hand-off.
It does not copy or embed the OhMyGame application, install plugins, launch its
daemon, access its private HTTP endpoints, connect its MCP server, or publish
games. OhMyGame's own documentation describes its MCP endpoint/token as
runtime-generated and private to its local daemon; a static guessed URL would
not be a safe integration.

The supplied OhmyGame repository identifies its license as Apache-2.0. The
license notice is retained in `docs/third_party/`. The app remains a separate
installation; review its own setup and security documentation before use.

## Autonomy and permission model

JARVIS remains a local assistant with bounded planning, persistent sessions,
and a registry of explicit tools. Read-only tools may run automatically when
selected by the local planner. Image generation, writing files, saving memory,
and creating game briefs require explicit approval. It does not run arbitrary
shell commands, control the phone, access accounts, or publish content. These
limits are intentional. Localhost binding is recommended; do not expose the
development server to the public internet.
