# v0.8 source review and integration record

## Included: JARVIS original code
This release extends the prior JARVIS implementation with local conversation sessions and an Ollama streaming endpoint. These are original Python implementations built on the existing FastAPI, SQLite, and Ollama interfaces.

## Included as documentation: Claude Code resources catalogue
The uploaded `claude-code-resources-main` repository is a curated educational link catalogue, not a software runtime. Its README and MIT license are preserved under `docs/third_party/`. The catalogue includes claims and links about leaked proprietary material; those claims are repository-authored and are not independently verified by JARVIS.

## Reviewed but not incorporated: PikoClaw
The PikoClaw README identifies its design and feature specifications as derived directly from research into the Claude Code source leak. Although its repository declares Apache-2.0, this provenance makes it unsuitable as a source to copy into this project. No PikoClaw implementation code, source-derived design documents, or binary is copied into JARVIS. Its public README was reviewed only to understand the project's stated scope: Rust agent runtime, provider connectivity, tool policies, session handling, MCP, and terminal UI. JARVIS implements its own session persistence and streaming using its existing Python/FastAPI/Ollama stack.

## Excluded: Anthropic leaked source archive
`Anthropic-Leaked-Source-Code-main.zip` is explicitly presented as leaked Anthropic/Claude Code source. It is not extracted into JARVIS, copied, modified, mined for implementation details, or used as a code-generation reference. Use of leaked proprietary source could create legal and provenance problems. JARVIS development instead uses original code and ordinary public standards.

## v0.8 changes
- `jarvis/session_store.py`: SQLite conversation/session persistence.
- `POST /api/sessions`, `GET /api/sessions`, `GET /api/sessions/{id}`, `DELETE /api/sessions/{id}`.
- `POST /api/chat/stream`: Ollama token streaming using Server-Sent Events.
- `POST /api/agent/ask` and `/api/chat`: optional session persistence.
- Web UI starts a fresh conversation and sends its session ID.
- Existing permission checks and workspace boundaries remain in place.

## Limitations
Streaming uses the configured local Ollama endpoint and requires it to be running. Session data is stored locally and has no multi-user authentication; keep the service bound to localhost. The UI starts a new session on page load and can start another with New chat; prior sessions can be listed/retrieved through the API but are not yet shown in a conversation-history sidebar.
