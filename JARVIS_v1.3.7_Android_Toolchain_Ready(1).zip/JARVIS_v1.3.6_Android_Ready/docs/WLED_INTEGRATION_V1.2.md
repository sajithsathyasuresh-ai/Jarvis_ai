# WLED integration (v1.2)

JARVIS includes an optional, original Python client for the WLED JSON API. It does not include WLED firmware or copy WLED source code. The supplied changelog is treated as project-history context, not as an implementation specification. In particular, its note that WLED changed from MIT to EUPL is recorded as provenance context; no WLED code is redistributed here.

## Enable

Set these values in `.env`:

```env
JARVIS_ENABLE_WLED=true
JARVIS_WLED_URL=http://192.168.1.50
```

Replace the address with the private IPv4 address of the WLED device on your own local network. Restart JARVIS. The integration accepts localhost or a private IPv4 address only, uses HTTP without redirects, and blocks public IPs, hostnames, HTTPS, URL paths, and embedded credentials. Keep JARVIS bound to `127.0.0.1` and do not expose it to the internet.

## Tools and API

- `wled.status` is read-only. It requests `/json/state` and `/json/info` and returns basic power, brightness, preset, segment-count, device-name, firmware-version, and LED-count information.
- `wled.set_state` requires explicit approval. It supports power (`on`), brightness (`1..255`), transition duration (`0..65535` ms), and RGB color (hex string or `[r,g,b]`) for one segment (`segment_id`, `0..31`).
- `GET /api/integrations/wled` reports whether the adapter is enabled and whether the device can be reached.

The adapter deliberately does not expose firmware updates, factory reset, Wi-Fi configuration, arbitrary HTTP requests, MQTT, realtime streaming, or arbitrary effect/preset execution. Those actions are outside this integration's scope. The changelog's many historical features are not assumed to be available on every WLED firmware or hardware target.

## Safety and compatibility

Only enable this for a WLED device you own or are authorized to control. Every light-state mutation goes through the JARVIS approval-gated tool registry. A successful HTTP response confirms that WLED accepted the JSON request; it does not independently verify the physical LEDs. Firmware versions and hardware differ, so test with low brightness first and check the device's own WLED UI for the final state.
