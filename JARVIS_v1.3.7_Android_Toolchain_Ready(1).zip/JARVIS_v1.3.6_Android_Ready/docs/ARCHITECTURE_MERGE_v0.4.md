# Architecture integration notes (v0.4)

## What was merged from `claude-code-from-source-main.zip`

The supplied archive is an educational book and a website that renders it. Its README explicitly states that it contains no Claude Code source code; its code examples are original pseudocode illustrating architecture. JARVIS therefore does **not** contain Claude Code's proprietary implementation.

The book chapters have been preserved under `docs/claude-code-from-source/book/` for local reference. The web reader was not copied because it is a separate Astro documentation site, not an assistant runtime.

## Patterns implemented in JARVIS

- Central tool registry with a uniform invocation path.
- Fail-closed permissions: tools default to requiring approval; only explicitly marked read-only tools bypass it.
- Input-shape checks, bounded output, and conservative concurrency metadata.
- Existing agent routing and optional LangGraph orchestration remain intact.
- Existing SQLite memory remains the default store; Mem0 remains optional.
- Browser Use remains disabled by default and read-only/approval-gated.

The implementation in `jarvis/tool_system.py` is original Python code inspired by the general patterns described in the supplied guide. It is not copied Claude Code source.

## Tool API

- `GET /api/tools` — list registered tools and their permission level.
- `POST /api/tools/time.now/run` with `{}` — local time.
- `POST /api/tools/calculator.evaluate/run` with `{"arguments":{"expression":"(3+4)*5"}}` — arithmetic.
- `POST /api/tools/memory.search/run` with `{"arguments":{"query":"physics"}}` — search local memories.
- `POST /api/tools/memory.save/run` requires `{"arguments":{"content":"..."}, "approved":true}`.

The `approved` field is an explicit caller assertion, not an authentication system. Do not expose this API to the public internet. Before network exposure, add user authentication, CSRF protections where applicable, rate limits, and server-side approval tied to a trusted user session.

## Not implemented

This release does not reproduce Claude Code, provide unrestricted shell or filesystem access, implement a full MCP client/server, or add unrestricted computer/Android control. The book discusses those ideas, but the supplied archive contains explanations and pseudocode rather than those runnable systems.
