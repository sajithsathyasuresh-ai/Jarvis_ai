# Architecture integration notes (v0.5)

## What was added from `rea-main (1).zip`

The supplied archive is REA (Reverse Engineer Anything), version 6.10.1,
an MIT-licensed Node.js CLI and MCP server. It supports evidence-backed
inspection of applications, JavaScript/Electron projects, native binaries,
and runtime behavior when the appropriate analysis tools are available.

JARVIS does not copy the entire REA repository into its Python runtime.
REA is maintained and installed separately through its official package.
This avoids mixing a large Node.js toolchain into the Python application and
preserves REA's own release and dependency lifecycle.

## Implemented in JARVIS

- `jarvis/integrations/rea_adapter.py` checks for Node.js/npm and reports
  whether the optional integration flag is enabled.
- `jarvis/integrations/rea-mcp.json` contains the upstream MCP launch command
  for a compatible external MCP host.
- `GET /api/integrations/rea` reports runtime readiness and configuration.
- `GET /api/agents` lists REA as an optional external integration.
- `jarvis/integrations/REA_INTEGRATION.md` documents setup, limitations,
  attribution, and safe-use boundaries.

## Important limitation

This is an integration scaffold, not a live MCP connection. JARVIS v0.5
does not yet implement an MCP client and cannot call REA's tools directly.
The status flag `JARVIS_ENABLE_REA=true` is informational only. It does not
install or launch REA.

REA 6.10.1 declares Node.js `^22.23.4 || ^24.22.1 || >=26.12.1`.
Use the official upstream setup guide and review all proposed configuration
changes before approving them.

## Authorization boundary

Use reverse-engineering tools only on software, devices, and data you own or
are explicitly authorized to inspect. Do not use them to bypass DRM, license
checks, authentication, anti-cheat, or access controls. Static, read-only
analysis is the recommended starting point. Dynamic execution, process
attachment, network capture, or device interaction can affect systems and
must be separately assessed and authorized.

## Upstream

- Project: https://github.com/morluto/rea
- npm package: https://www.npmjs.com/package/rea-agents
- Upstream license: MIT

The REA source itself is not redistributed in this JARVIS archive. Review
the upstream license and third-party notices before installing or redistributing
the separate REA package.
