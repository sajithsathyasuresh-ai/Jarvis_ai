# JARVIS v1.0 task orchestration

## Workflow

1. A task is created and stored in SQLite.
2. The local Ollama planner proposes up to four registered tool calls.
3. The reviewer rejects unknown tools, malformed argument containers, oversized plans, and blocked high-impact tool names.
4. Read-only plans run through the existing tool registry. Plans containing an approval-level tool are persisted as `awaiting_approval` and do not execute.
5. The user can inspect the persisted plan and explicitly approve it. The executor then runs the same persisted plan through the registry.
6. Results and status are saved. On process restart, tasks left in `planning` or `running` are marked `failed` with an interruption note so they can be reviewed and retried.

## Role boundaries

Planner is the only model-backed planning role. Researcher and Coder are workflow responsibilities limited to registered read-only research tools and workspace file tools; they are not separate model instances. Reviewer performs deterministic validation. Executor invokes the centralized registry. This is intentionally transparent and should not be described as a full independent multi-agent swarm.

## Security boundaries

- No arbitrary shell or Python execution.
- Workspace path traversal remains blocked.
- Mutating tools require an explicit approval request.
- Approval is not authentication; bind to localhost and do not expose the development server publicly.
- A process restart does not resume a partially executed tool call. It marks the task interrupted for human review and retry.
- Ollama and optional integration connectivity must be checked on the target device; passing unit tests does not prove a local model or external app is running.
