# JARVIS integration review — v1.3.3

## Sources reviewed and selection

The following public repositories were reviewed as architecture references:

- [todo-for-ai/todo-for-ai](https://github.com/todo-for-ai/todo-for-ai) — Apache-2.0. Relevant concept: revision-aware task updates and append-only task activity. JARVIS implements these concepts in its existing SQLite task store rather than importing the remote task platform, its database, web app, or MCP package.
- [Nayjest/Gito](https://github.com/Nayjest/Gito) — MIT. Relevant concept: make code review a repeatable developer workflow. JARVIS adds a deterministic local static-review tool with a bounded input size; it does not import Gito's code, LLM dependencies, CLI, CI workflows, or provider integrations.
- [mcpware/cross-code-organizer](https://github.com/mcpware/cross-code-organizer) — MIT. Relevant concept: expose a local inventory and make tool/configuration risk findings actionable. JARVIS audits only its own registered agent and tool metadata; it does not manage external harness files or connect to external MCP servers.

No source files, copied algorithms, binaries, UI assets, package dependencies, or hosted components from these repositories were merged. JARVIS implementations in this release are original. Cross-Code Organizer's README mentions validation against leaked Claude Code source; JARVIS does not use leaked-source-derived constants, algorithms, rules, or implementation details.

## What changed in JARVIS

### Task workflow

- Existing task databases are migrated in place with a `revision` column.
- User edits can supply `expected_revision`; stale edits are rejected with HTTP 409.
- Task lifecycle changes are written to a local append-only `task_events` table.
- Notes can be appended to a task timeline; there is no update/delete API for events.
- New APIs: `PATCH /api/tasks/{task_id}`, `GET /api/tasks/{task_id}/events`, and `POST /api/tasks/{task_id}/events`.
- Task editing is restricted to queued or failed tasks. It cannot alter completed or currently running tasks.

### Local code review

- New tool: `code.review_source` (read-only and concurrency-safe).
- New endpoint: `POST /api/code-review` with `content` and optional `filename`.
- The deterministic checks look for selected risky patterns such as dynamic execution, shell-enabled subprocess calls, unsafe pickle loading, disabled TLS verification, likely hard-coded secrets, and wildcard credentialed CORS.
- Source text is limited to 100,000 characters and is neither executed nor sent to a remote model by this reviewer.
- This is a first-pass aid, not a complete SAST engine or a guarantee that code is safe.

### Local agent/tool inventory

- New endpoint: `GET /api/security/audit`.
- It reports registered tools, permission levels, concurrency flags, parameter-schema bounds, agent descriptions, and selected metadata risks.
- The audit is read-only and limited to JARVIS's in-process registry. It does not discover, connect to, enable, disable, or delete external MCP servers.

## Security and compatibility

- Existing tool approval checks remain in place.
- No shell command tool or arbitrary code execution was added.
- Task event details record progress metadata and user notes, not full task results or tool outputs.
- Existing task SQLite files are migrated on application startup; task rows are retained.
- API routes continue to use the existing optional bearer-token middleware when `JARVIS_ACCESS_TOKEN` is configured.

## Verification

Run the full project test suite with:

```bash
python -m pytest -q
```
