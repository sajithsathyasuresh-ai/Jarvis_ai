# Build JARVIS v1.3.6 for Android

This source is configured for a Capacitor Android app. It is not itself an APK. A real APK must be compiled with the Android SDK and Gradle.

## Requirements

- Node.js 20 or newer and npm
- Android Studio with an Android SDK platform and build tools installed
- JDK supported by the installed Android Gradle Plugin (use Android Studio's bundled JDK)
- Network access the first time, so npm and Gradle can resolve their dependencies

Capacitor requires Android Studio and an Android SDK for Android builds. The speech-recognition dependency is version 7.0.1 to match Capacitor 7.

## Build a debug APK (Linux/macOS)

From the project root:

```bash
export ANDROID_HOME="$HOME/Android/Sdk"  # adjust to your SDK location
npm install
npm run android:build:debug
```

The script builds the Vite web bundle, creates the Capacitor Android project if it does not exist, syncs native plugins, builds `assembleDebug`, and copies the result to:

```text
artifacts/JARVIS-v1.3.6-debug.apk
```

On Windows, open PowerShell in the project folder and run:

```powershell
$env:ANDROID_HOME = "$env:LOCALAPPDATA\Android\Sdk"  # adjust to your SDK location
powershell -ExecutionPolicy Bypass -File scripts/build-android.ps1
```

Alternatively, install dependencies and generate the native project with `npm install`, `npm run build`, and `npx cap add android`, then run `npx cap sync android`. Open the generated `android/` folder in Android Studio, sync Gradle, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Connect the app to its AI backend

The APK is the mobile client; the FastAPI JARVIS brain must run on a server reachable by the phone. Deploy the backend behind HTTPS, then enter its origin in the **JARVIS backend URL** field (for example, `https://jarvis.example.com`) and tap **Connect**. Do not put an API key or backend access token into source code or the APK.

If `JARVIS_ACCESS_TOKEN` is enabled, enter that token in the access-token field. The backend allows Capacitor's default `https://localhost` and `capacitor://localhost` origins for CORS. Additional browser origins can be added with the comma-separated `JARVIS_CORS_ORIGINS` environment variable. Do not use wildcard CORS for a private assistant.

Use HTTPS for remote connections. Plain HTTP is accepted by the app only for localhost development. Do not expose Ollama's port directly to the public internet. Ollama should run on the backend host, reachable locally by the FastAPI service.

## Release builds

The generated debug APK is suitable for local testing. A release APK must be signed with a signing key that you create and protect. Never commit a signing key or passwords to the repository.

## Build automatically with GitHub Actions

This repository includes `.github/workflows/android-apk.yml`. Push the source to a GitHub repository, then open **Actions → Build JARVIS Android APK → Run workflow**. When the workflow succeeds, open its run and download the `JARVIS-v1.3.6-debug-apk` artifact. This produces a debug APK for testing; it is not a signed release build.
