# JARVIS v0.7 architecture upgrade

## Implemented

1. **LLM planner:** `jarvis/planner.py` asks the configured local Ollama model for a constrained JSON plan. It caps plans at four tool calls and rejects malformed JSON and unknown tool names.
2. **Validated execution:** the planner can only propose tools returned by `ToolRegistry.describe()`. `ToolRegistry` remains the execution and permission boundary.
3. **Workspace tools:** `jarvis/workspace_tools.py` confines listing, reading, and writing to a dedicated workspace root. Text reads are capped at 200 KB and writes at 100 KB. Parent traversal is rejected.
4. **Approval UI:** when a plan includes an approval-required tool, `/api/agent/ask` returns the plan without executing it. The browser displays the steps and requires an explicit click before submitting the plan to `/api/agent/execute`.
5. **No arbitrary command execution:** the project deliberately does not expose a shell, dynamic Python evaluator, unrestricted filesystem access, phone control, or account automation.

## Flow

`User prompt -> Ollama JSON planner -> plan validation -> tool registry -> permission preflight -> bounded execution -> results`

Approval-required plans stop before execution and return to the UI for review. Read-only tools can be batched under the registry's concurrency policy. Tool outputs remain bounded.

## Limitations

This is a functional local tool-using assistant foundation, not a finished general-purpose autonomous computer operator. It does not yet have robust multi-turn conversation state, streaming token/tool events, a true MCP client for REA, reliable cross-tool dataflow, long-running task recovery, or Android/Desktop control. Model quality depends on the selected Ollama model and available device resources. A local approval boolean is not a security boundary against a malicious local process; do not expose the development server to the internet.
