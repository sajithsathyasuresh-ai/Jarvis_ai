# JARVIS integration review — v1.3.4

## Repositories reviewed

1. `ollama/ollama` — MIT. Relevant because JARVIS already uses Ollama for its planner, chat, and screen vision. Added a dedicated local model inventory and bounded test-chat interface using the documented local REST API shape.
2. `huggingface/paperswithcode` — Apache-2.0. Relevant for research discovery. Added a small client for the public `paperswithcode.co/api/v1/papers/search` endpoint in explicit keyword mode. Did not import the full website, frontend, PostgreSQL schema, pgvector index, scheduled ingestion jobs, or credentials.
3. `usestrix/strix` — Apache-2.0. Reviewed as an application-security project. Only defensive workflow ideas were used to expand JARVIS's local static source checks and bounded project scanner. No active pentesting, reconnaissance, exploit execution, payload generation, target scanning, shell tool, or Docker sandbox was added.

## New modules and APIs

- `jarvis/integrations/ollama_adapter.py`
  - Handles malformed optional model-detail metadata without crashing the inventory.
  - Loopback-only HTTP base URL validation.
  - No proxy inheritance (`trust_env=False`).
  - Installed model discovery capped at 100 entries.
  - Test chat limited to 4,000 input characters and an already-installed model.
  - No model download, delete, push, or pull operations.
- `jarvis/research_catalog.py`
  - Rejects malformed API payloads safely.
  - Validates HTTPS links and requires exact `github.com` hosts for repository links.
  - Fixed HTTPS host `paperswithcode.co`.
  - Query length 2–300 characters; result limit 1–10.
  - No redirects and bounded request timeout.
  - Normalizes paper metadata and only retains HTTPS paper links and GitHub repository links.
- `jarvis/code_review.py`
  - Added checks for unsafe YAML loading, insecure temporary-file naming, and legacy hash algorithms.
  - Added a bounded project scan of selected source extensions; skips data, VCS, dependency, build, and cache folders.
  - Read-only; source is never executed or uploaded by this scanner.
- `app.py`
  - `GET /api/local-ai/status`
  - `GET /api/local-ai/models`
  - `POST /api/local-ai/chat`
  - `POST /api/research/papers`
  - `POST /api/security/scan-project`
- `static/index.html` and `static/app.js`
  - Added Local Model Manager, AI Research Library, and Project Security Scan panels.

## Security boundaries

The Strix repository is an active penetration-testing tool. JARVIS does not incorporate its offensive capabilities. Its new project scan is static and defensive only. Do not interpret a clean report as proof that the application is secure.

The Papers with Code API is an external service. Search availability depends on the public service and network access. No local database or persistent research index was added.

Ollama model availability depends on a local Ollama server and models already installed there. The adapter deliberately refuses non-loopback hosts; the existing core planner configuration remains separate.

## Validation

- `python -m pytest -q`: 88 passed, 4 existing FastAPI `on_event` deprecation warnings, 13 subtests passed.
- `python -m compileall -q app.py jarvis tests`: passed.
- `node --check static/app.js`: passed.
- Confirmed all five new API routes are registered.
- No APK was built in this pass.
