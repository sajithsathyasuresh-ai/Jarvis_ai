# JARVIS v1.3 — Hybrid mobile deployment

## Architecture
- Android/PWA client: responsive web UI, browser speech input/output, installable shell.
- Local brain: Ollama + FastAPI on a trusted computer or private home server.
- Optional cloud brain: OpenAI-compatible Chat Completions endpoint configured on the backend only.
- Persistent memory, sessions, task planner and the existing v1.2 tool registry remain in place.

## Secure setup
1. Copy `.env.example` to `.env` and keep `.env` private.
2. Set `JARVIS_ACCESS_TOKEN` to a long random secret (at least 32 random bytes). The UI stores the entered token in session storage only; it is cleared when the browser session ends.
3. If using cloud AI, set `JARVIS_CLOUD_API_KEY` on the backend. Do not put it in the browser, PWA assets, Git, or Android package.
4. Keep the backend bound to `127.0.0.1` and use a private HTTPS tunnel/VPN to reach it from the phone. Do not expose raw Uvicorn or Ollama ports to the public internet.
5. Use HTTPS for microphone access on non-localhost origins. Browser speech recognition varies by browser and may use platform services.
6. Back up `data/` securely. It contains conversation and memory databases.

The access token is a simple shared bearer secret, not multi-user identity, device revocation, or a substitute for TLS. Use a private network/VPN, rotate the token if exposed, and do not share it. Health and token-check endpoints are intentionally reachable without authentication and disclose only service status/configuration flags.

## Run

```bash
python -m venv .venv
# Activate the environment, then:
pip install -r requirements.txt
cp .env.example .env
# Edit .env, then run locally:
uvicorn app:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000` on the host. For phone access, configure a private HTTPS tunnel/VPN endpoint to forward to `127.0.0.1:8000`; enter the JARVIS access token in the connection field. Install the PWA from the browser menu, or follow `android/BUILD_ANDROID.md` to generate a Capacitor APK.

## Mobile limitations
- Voice input/output depend on Android browser/WebView capabilities and permission prompts.
- The app does not silently listen in the background.
- No arbitrary SMS, calls, contacts, files, app launching, accessibility automation, or device-control capability is present.
- Android APK generation requires a local Android SDK/Gradle toolchain; this source package does not contain a prebuilt APK.

Generate a token with Python:

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

Paste the generated value into `JARVIS_ACCESS_TOKEN` in your private `.env` file. Do not paste the token into chat or commit it.
