$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Root

if (-not (Get-Command node -ErrorAction SilentlyContinue) -or -not (Get-Command npm -ErrorAction SilentlyContinue)) {
    throw 'Node.js 20+ and npm are required.'
}
$NodeMajor = [int](node -p "Number(process.versions.node.split('.')[0])")
if ($NodeMajor -lt 20) { throw "Node.js 20+ is required; found $(node --version)." }
if (-not $env:ANDROID_HOME -and -not $env:ANDROID_SDK_ROOT) {
    throw 'Android SDK not found. Install Android Studio + Android SDK, then set ANDROID_HOME or ANDROID_SDK_ROOT.'
}

npm install
if ($LASTEXITCODE -ne 0) { throw 'npm install failed.' }
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Vite web build failed.' }
if (-not (Test-Path 'android')) {
    npx cap add android
    if ($LASTEXITCODE -ne 0) { throw 'Capacitor could not create the Android project.' }
}
npx cap sync android
if ($LASTEXITCODE -ne 0) { throw 'Capacitor Android sync failed.' }
if (-not (Test-Path 'android/gradlew.bat')) { throw 'Gradle wrapper is missing. Open android/ in Android Studio and sync Gradle once.' }
Push-Location android
try {
    .\gradlew.bat --no-daemon assembleDebug
    if ($LASTEXITCODE -ne 0) { throw 'Gradle APK build failed.' }
} finally { Pop-Location }
$Apk = 'android/app/build/outputs/apk/debug/app-debug.apk'
if (-not (Test-Path $Apk)) { throw "APK not found at $Apk" }
New-Item -ItemType Directory -Force -Path 'artifacts' | Out-Null
Copy-Item $Apk 'artifacts/JARVIS-v1.3.6-debug.apk' -Force
Write-Host "APK created: $Root\artifacts\JARVIS-v1.3.6-debug.apk"
