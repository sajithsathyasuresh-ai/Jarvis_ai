#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Node.js 20+ and npm are required." >&2
  exit 1
fi
NODE_MAJOR="$(node -p 'Number(process.versions.node.split(".")[0])')"
if (( NODE_MAJOR < 20 )); then
  echo "Node.js 20+ is required; found $(node --version)." >&2
  exit 1
fi
if ! command -v java >/dev/null 2>&1; then
  echo "A supported JDK is required. Install Android Studio and its recommended JDK." >&2
  exit 1
fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "Android SDK not found. Install Android Studio + Android SDK, then set ANDROID_HOME or ANDROID_SDK_ROOT." >&2
  exit 1
fi

SDKMANAGER="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}/cmdline-tools/latest/bin/sdkmanager"
if [[ -x "$SDKMANAGER" ]]; then
  "$SDKMANAGER" "platform-tools" "platforms;android-35" "build-tools;35.0.0"
fi

npm install --no-audit --no-fund
npm run build

if [[ ! -d android ]]; then
  npx cap add android
elif [[ ! -f android/app/build.gradle && ! -f android/app/build.gradle.kts ]]; then
  echo "The android/ directory exists but is not a generated Capacitor Android project. Move it aside and retry." >&2
  exit 1
fi

npx cap sync android
if [[ -x android/gradlew ]]; then
  (cd android && ./gradlew --no-daemon assembleDebug)
elif command -v gradle >/dev/null 2>&1; then
  (cd android && gradle --no-daemon assembleDebug)
else
  echo "Gradle wrapper not found and Gradle is not installed. Install Gradle or open android/ in Android Studio to generate/sync the wrapper, then retry." >&2
  exit 1
fi

APK="android/app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -f "$APK" ]]; then
  echo "Build command completed but expected APK was not found at: $APK" >&2
  exit 1
fi
mkdir -p artifacts
cp "$APK" artifacts/JARVIS-v1.3.6-debug.apk
printf '\nAPK created: %s\n' "$ROOT/artifacts/JARVIS-v1.3.6-debug.apk"
