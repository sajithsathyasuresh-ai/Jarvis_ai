import os
import json
import hmac
import asyncio
from contextlib import suppress
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from jarvis.memory import MemoryStore
from jarvis.agents import AgentRouter
from jarvis.orchestration import Orchestrator
from jarvis.integrations.browser_use_adapter import BrowserResearchAgent
from jarvis.tool_system import ToolRegistry, ToolSpec
from jarvis.agent_loop import run_tool_plan
from jarvis.integrations.rea_adapter import rea_status
from jarvis.agents import safe_calculate, TimeAgent
from jarvis.planner import create_plan, PlannerError
from jarvis.workspace_tools import Workspace
from jarvis.session_store import SessionStore
from jarvis.task_store import TaskStore, RevisionConflict
from jarvis.task_orchestrator import TaskOrchestrator
from jarvis.integrations.stable_diffusion import StableDiffusionWebUI
from jarvis.integrations.ohmygame_adapter import status as ohmygame_status, create_game_brief
from jarvis.screen_vision import ScreenVisionAgent, validate_image, MAX_IMAGE_BYTES
from jarvis.integrations.wled import WLEDAdapter
from jarvis.news import NewsStore, news_worker
from jarvis.code_review import review_source, review_project
from jarvis.integrations.ollama_adapter import OllamaLocalAdapter
from jarvis.research_catalog import ResearchCatalog
from jarvis.security_audit import audit_registry

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "static-dist" if (BASE_DIR / "static-dist" / "index.html").exists() else BASE_DIR / "static"
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434").rstrip("/")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "gemma4:e2b")
DATA_DIR = Path(os.getenv("JARVIS_DATA_DIR", str(BASE_DIR / "data"))).resolve()
MEMORY = MemoryStore(str(DATA_DIR / "memory.sqlite3"))
SESSIONS = SessionStore(str(DATA_DIR / "sessions.sqlite3"))
ROUTER = AgentRouter(MEMORY)
ORCHESTRATOR = Orchestrator(ROUTER)
BROWSER = BrowserResearchAgent()
TOOLS = ToolRegistry()
WORKSPACE = Workspace(os.getenv("JARVIS_WORKSPACE_DIR", str(BASE_DIR / "workspace")))
TOOLS.register(ToolSpec("time.now", "Get the current local time.", permission="read_only", concurrency_safe=True,
                        parameters={"type":"object","properties":{},"additionalProperties":False}),
               lambda args: TimeAgent().run(""))
TOOLS.register(ToolSpec("calculator.evaluate", "Evaluate a basic arithmetic expression.", permission="read_only", concurrency_safe=True,
                        parameters={"type":"object","properties":{"expression":{"type":"string","minLength":1,"maxLength":120}},"required":["expression"],"additionalProperties":False}),
               lambda args: safe_calculate(args["expression"]))
TOOLS.register(ToolSpec("memory.search", "Search locally saved memories.", permission="read_only", concurrency_safe=True,
                        parameters={"type":"object","properties":{"query":{"type":"string","minLength":1,"maxLength":500},"limit":{"type":"integer","minimum":1,"maximum":20}},"required":["query"],"additionalProperties":False}),
               lambda args: MEMORY.search(args["query"], int(args.get("limit", 5))))
TOOLS.register(ToolSpec("memory.save", "Save a note to local memory.", permission="approval",
                        parameters={"type":"object","properties":{"content":{"type":"string","minLength":1,"maxLength":2000}},"required":["content"],"additionalProperties":False}),
               lambda args: {"id": MEMORY.add(args["content"])})
TOOLS.register(ToolSpec("workspace.list", "List files in the isolated JARVIS workspace.", permission="read_only", concurrency_safe=True,
                        parameters={"type":"object","properties":{"directory":{"type":"string","maxLength":300}},"additionalProperties":False}), WORKSPACE.list_files)
TOOLS.register(ToolSpec("workspace.read", "Read a UTF-8 text file inside the isolated JARVIS workspace.", permission="read_only", concurrency_safe=True,
                        parameters={"type":"object","properties":{"path":{"type":"string","minLength":1,"maxLength":300}},"required":["path"],"additionalProperties":False}), WORKSPACE.read_file)
TOOLS.register(ToolSpec("workspace.write", "Create or replace a UTF-8 text file inside the isolated JARVIS workspace; requires approval.", permission="approval",
                        parameters={"type":"object","properties":{"path":{"type":"string","minLength":1,"maxLength":300},"content":{"type":"string","maxLength":100000}},"required":["path","content"],"additionalProperties":False}), WORKSPACE.write_file)
TOOLS.register(ToolSpec("ohmygame.create_brief", "Create a game-project brief for manual hand-off to OhMyGame; requires approval.",
                        permission="approval", parameters={"type":"object","properties":{"title":{"type":"string","maxLength":100},"concept":{"type":"string","minLength":1,"maxLength":4000},"platform":{"type":"string","maxLength":40}},"required":["concept"],"additionalProperties":False}),
               lambda args: create_game_brief(args, WORKSPACE.root))
TOOLS.register(ToolSpec("code.review_source", "Run a local, read-only static security review over source text; source is never executed or uploaded.", permission="read_only", concurrency_safe=True, max_output_chars=5000,
                        parameters={"type":"object","properties":{"content":{"type":"string","minLength":1,"maxLength":100000},"filename":{"type":"string","maxLength":160}},"required":["content"],"additionalProperties":False}),
               lambda args: review_source(args["content"], args.get("filename", "<input>")))


WLED = None
if os.getenv("JARVIS_ENABLE_WLED", "false").lower() == "true":
    WLED = WLEDAdapter(os.getenv("JARVIS_WLED_URL", ""))
    TOOLS.register(ToolSpec("wled.status", "Read status and basic device information from the configured local WLED device.", permission="read_only", concurrency_safe=True,
                            parameters={"type":"object","properties":{},"additionalProperties":False}),
                   lambda args: WLED.status())
    TOOLS.register(ToolSpec("wled.set_state", "Change WLED power, brightness, transition, or one segment RGB color; requires explicit approval.", permission="approval",
                            parameters={"type":"object","properties":{"on":{"type":"boolean"},"brightness":{"type":"integer","minimum":1,"maximum":255},"transition_ms":{"type":"integer","minimum":0,"maximum":65535},"color":{"type":"string","maxLength":7},"segment_id":{"type":"integer","minimum":0,"maximum":31}},"additionalProperties":False}),
                   WLED.set_state)

SD_WEBUI = None
if os.getenv("JARVIS_ENABLE_STABLE_DIFFUSION", "false").lower() == "true":
    SD_WEBUI = StableDiffusionWebUI(
        os.getenv("STABLE_DIFFUSION_URL", "http://127.0.0.1:7860"), WORKSPACE.root
    )
    TOOLS.register(ToolSpec("image.generate", "Generate one image through a local Stable Diffusion WebUI; saves it inside the JARVIS workspace and requires approval.", permission="approval", max_output_chars=1000,
                            parameters={"type":"object","properties":{"prompt":{"type":"string","minLength":1,"maxLength":1500},"negative_prompt":{"type":"string","maxLength":1000},"width":{"type":"integer","minimum":256,"maximum":1024},"height":{"type":"integer","minimum":256,"maximum":1024},"steps":{"type":"integer","minimum":1,"maximum":30},"filename":{"type":"string","maxLength":48}},"required":["prompt"],"additionalProperties":False}),
                   SD_WEBUI.generate)

TASKS = TaskStore(str(DATA_DIR / "tasks.sqlite3"))
TASKS.recover_interrupted()
TASK_ORCHESTRATOR = TaskOrchestrator(TASKS, TOOLS, ollama_url=OLLAMA_URL, model=OLLAMA_MODEL)
VISION_MODEL = os.getenv("JARVIS_VISION_MODEL", "llava:7b")
ACCESS_TOKEN = os.getenv("JARVIS_ACCESS_TOKEN", "").strip()
CLOUD_API_KEY = os.getenv("JARVIS_CLOUD_API_KEY", "").strip()
CLOUD_BASE_URL = os.getenv("JARVIS_CLOUD_BASE_URL", "https://api.openai.com/v1").rstrip("/")
CLOUD_MODEL = os.getenv("JARVIS_CLOUD_MODEL", "gpt-4o-mini")
SCREEN_VISION = ScreenVisionAgent(OLLAMA_URL, VISION_MODEL)
NEWS = NewsStore(str(DATA_DIR / "news.sqlite3"))
try:
    OLLAMA_LOCAL = OllamaLocalAdapter(OLLAMA_URL)
except ValueError:
    OLLAMA_LOCAL = None
RESEARCH_CATALOG = ResearchCatalog()
NEWS_TASK = None

app = FastAPI(title="JARVIS Hybrid AI", version="1.3.6")

@app.on_event("startup")
async def start_background_news():
    global NEWS_TASK
    NEWS_TASK = asyncio.create_task(news_worker(NEWS))

@app.on_event("shutdown")
async def stop_background_news():
    if NEWS_TASK:
        NEWS_TASK.cancel()
        with suppress(asyncio.CancelledError):
            await NEWS_TASK

@app.middleware("http")
async def require_mobile_token(request: Request, call_next):
    """Protect every API route when a remote-access token is configured."""
    if request.url.path.startswith("/api/") and request.url.path not in {"/api/health", "/api/auth/check"} and ACCESS_TOKEN:
        supplied = request.headers.get("authorization", "")
        expected = f"Bearer {ACCESS_TOKEN}"
        if not hmac.compare_digest(supplied, expected):
            return JSONResponse(status_code=401, content={"detail": "Authentication required. Enter your JARVIS access token."})
    return await call_next(request)

# Capacitor Android WebView uses https://localhost by default. Additional origins
# must be explicitly listed by the backend owner; wildcard CORS is intentionally disabled.
_default_cors_origins = ["https://localhost", "capacitor://localhost"]
_configured_cors_origins = [item.strip().rstrip("/") for item in os.getenv("JARVIS_CORS_ORIGINS", "").split(",") if item.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=list(dict.fromkeys(_default_cors_origins + _configured_cors_origins)),
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
    max_age=600,
)

app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")
if (WEB_DIR / "assets").is_dir():
    app.mount("/assets", StaticFiles(directory=WEB_DIR / "assets"), name="built-assets")

@app.get("/manifest.webmanifest")
async def web_manifest():
    return FileResponse(WEB_DIR / "manifest.webmanifest", media_type="application/manifest+json")

@app.get("/icon.svg")
async def app_icon():
    return FileResponse(WEB_DIR / "icon.svg", media_type="image/svg+xml")

@app.get("/sw.js")
async def service_worker():
    return FileResponse(WEB_DIR / "sw.js", media_type="application/javascript",
                        headers={"Service-Worker-Allowed": "/", "Cache-Control": "no-cache"})

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    session_id: str | None = None

class MemoryRequest(BaseModel):
    content: str = Field(min_length=1, max_length=2000)

@app.get("/")
async def home():
    return FileResponse(WEB_DIR / "index.html")

@app.get("/app.js")
async def frontend_entry():
    # Development/source fallback; production Vite build uses /static/assets/*.js.
    entry = WEB_DIR / "app.js"
    if not entry.exists():
        raise HTTPException(status_code=404, detail="Frontend bundle not built. Run npm install and npm run build.")
    return FileResponse(entry, media_type="text/javascript")

@app.post("/api/auth/check")
async def auth_check(request: Request):
    if not ACCESS_TOKEN:
        return {"ok": True, "authentication_required": False}
    supplied = request.headers.get("authorization", "")
    if not hmac.compare_digest(supplied, f"Bearer {ACCESS_TOKEN}"):
        raise HTTPException(status_code=401, detail="Invalid JARVIS access token.")
    return {"ok": True, "authentication_required": True}

@app.get("/api/health")
async def health():
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            response = await client.get(f"{OLLAMA_URL}/api/tags")
            response.raise_for_status()
        return {"ok": True, "model": OLLAMA_MODEL, "ollama": True, "agents": len(ROUTER.describe()), "tools": len(TOOLS.describe()), "version": "1.3.6", "cloud_configured": bool(CLOUD_API_KEY), "auth_required": bool(ACCESS_TOKEN)}
    except (httpx.HTTPError, ValueError):
        return {"ok": False, "model": OLLAMA_MODEL, "ollama": False, "agents": len(ROUTER.describe()), "tools": len(TOOLS.describe()), "version": "1.3.6", "cloud_configured": bool(CLOUD_API_KEY), "auth_required": bool(ACCESS_TOKEN),
                "detail": "Ollama is not reachable. Local specialist tools and memory remain available."}

@app.get("/api/local-ai/status")
async def local_ai_status():
    if OLLAMA_LOCAL is None:
        return {"connected": False, "detail": "Configure OLLAMA_URL as a loopback URL such as http://127.0.0.1:11434."}
    try:
        return await OLLAMA_LOCAL.models()
    except (httpx.HTTPError, ValueError):
        return {"connected": False, "base_url": OLLAMA_LOCAL.base_url, "models": [], "detail": "Local Ollama is not reachable. Start Ollama and install a model."}

@app.get("/api/local-ai/models")
async def local_ai_models():
    if OLLAMA_LOCAL is None:
        raise HTTPException(status_code=503, detail="Local Ollama URL is not configured as a loopback address.")
    try:
        return await OLLAMA_LOCAL.models()
    except httpx.HTTPError:
        raise HTTPException(status_code=503, detail="Could not reach local Ollama.")

class LocalAIChatRequest(BaseModel):
    model: str = Field(min_length=1, max_length=120)
    message: str = Field(min_length=1, max_length=4000)

@app.post("/api/local-ai/chat")
async def local_ai_chat(payload: LocalAIChatRequest):
    if OLLAMA_LOCAL is None:
        raise HTTPException(status_code=503, detail="Local Ollama URL is not configured as a loopback address.")
    try:
        return await OLLAMA_LOCAL.chat(payload.model, payload.message)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except httpx.HTTPError:
        raise HTTPException(status_code=502, detail="Local Ollama request failed.")

class ResearchSearchRequest(BaseModel):
    query: str = Field(min_length=2, max_length=300)
    limit: int = Field(default=8, ge=1, le=10)

@app.post("/api/research/papers")
async def research_papers(payload: ResearchSearchRequest):
    try:
        return await RESEARCH_CATALOG.search(payload.query, payload.limit)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"Research catalogue returned HTTP {exc.response.status_code}.")
    except httpx.HTTPError:
        raise HTTPException(status_code=503, detail="Research catalogue is currently unreachable.")

@app.post("/api/security/scan-project")
async def scan_project_security():
    try:
        return review_project(str(BASE_DIR))
    except (OSError, ValueError) as exc:
        raise HTTPException(status_code=500, detail=f"Project scan could not complete: {exc}")

@app.get("/api/news")
async def get_news():
    # Return cached articles immediately; collection runs in a background worker.
    return {"articles": NEWS.list(30), "refresh_minutes": max(15, int(os.getenv("JARVIS_NEWS_REFRESH_MINUTES", "30")))}

@app.post("/api/news/refresh")
async def refresh_news():
    # Explicit refresh is user-triggered; feeds are HTTPS-only and size-limited.
    return {"new_articles": await NEWS.refresh(), "articles": NEWS.list(30)}

@app.get("/api/vision/status")
async def vision_status():
    return {"enabled": True, "model": VISION_MODEL, "mode": "screenshot analysis only", "computer_control": False}

@app.post("/api/vision/analyze")
async def analyze_screen(request: Request):
    mime = request.headers.get("content-type", "").split(";", 1)[0].strip().lower()
    chunks = []
    total = 0
    async for chunk in request.stream():
        total += len(chunk)
        if total > MAX_IMAGE_BYTES:
            raise HTTPException(status_code=413, detail="Image exceeds the 8 MB limit.")
        chunks.append(chunk)
    data = b"".join(chunks)
    try:
        validate_image(data, mime)
        return await SCREEN_VISION.analyze(data, mime)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"Local vision model returned HTTP {exc.response.status_code}.")
    except httpx.HTTPError:
        raise HTTPException(status_code=503, detail="Could not reach local Ollama. Check that Ollama and the vision model are running.")

@app.get("/api/tools")
async def list_tools():
    return {"tools": TOOLS.describe()}

@app.get("/api/security/audit")
async def security_audit():
    """Inspect local JARVIS agent/tool metadata without contacting MCP servers."""
    agents = ROUTER.describe() + TASK_ORCHESTRATOR.roles()
    return audit_registry(TOOLS.describe(), agents)

class CodeReviewRequest(BaseModel):
    content: str = Field(min_length=1, max_length=100000)
    filename: str = Field(default="<input>", max_length=160)

@app.post("/api/code-review")
async def code_review(payload: CodeReviewRequest):
    try:
        return review_source(payload.content, payload.filename)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

class ToolRequest(BaseModel):
    arguments: dict = Field(default_factory=dict)
    approved: bool = False

class ToolBatchRequest(BaseModel):
    calls: list[dict] = Field(min_length=1, max_length=12)
    approved: bool = False

class AgentPlanRequest(BaseModel):
    steps: list[list[dict]] = Field(min_length=1, max_length=8)
    approved: bool = False

@app.post("/api/tools/batch/run")
async def run_tool_batch(payload: ToolBatchRequest):
    try:
        results = await TOOLS.invoke_batch(payload.calls, approved=payload.approved)
        return {"results": results}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.post("/api/agent/execute")
async def execute_agent_plan(payload: AgentPlanRequest):
    """Run a bounded caller-supplied tool plan; this is not an autonomous planner."""
    events = []
    try:
        async for event in run_tool_plan(TOOLS, payload.steps, approved=payload.approved):
            events.append(event)
        return {"events": events, "autonomous_planning": False}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.post("/api/tools/{tool_name}/run")
async def run_tool(tool_name: str, payload: ToolRequest):
    try:
        return TOOLS.invoke(tool_name, payload.arguments, approved=payload.approved)
    except KeyError:
        raise HTTPException(status_code=404, detail="Unknown tool.")
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except (ValueError, TypeError, SyntaxError, ZeroDivisionError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.get("/api/integrations/rea")
async def rea_integration_status():
    return rea_status()

@app.get("/api/integrations/stable-diffusion")
async def stable_diffusion_status():
    return SD_WEBUI.status() if SD_WEBUI else {
        "enabled": False, "connected": False,
        "detail": "Set JARVIS_ENABLE_STABLE_DIFFUSION=true to enable the local WebUI adapter."
    }

@app.get("/api/integrations/ohmygame")
async def ohmygame_integration_status():
    return ohmygame_status()

@app.get("/api/integrations/wled")
async def wled_integration_status():
    if WLED is None:
        return {"enabled": False, "connected": False, "detail": "Set JARVIS_ENABLE_WLED=true and JARVIS_WLED_URL to enable the local WLED adapter."}
    try:
        return WLED.status()
    except (httpx.HTTPError, ValueError) as exc:
        return {"enabled": True, "connected": False, "detail": str(exc)[:300]}

@app.get("/api/agents")
async def agents():
    return {"agents": ROUTER.describe() + TASK_ORCHESTRATOR.roles() + [ORCHESTRATOR.describe(),
            {"name": "llm-planner", "enabled": True, "description": "Bounded local-model planner; validates all tool proposals."},
            {"name": "browser-research", "enabled": BROWSER.enabled, "description": "Approval-gated, read-only web research (optional)."},
            {"name": "rea-reverse-engineering", "enabled": rea_status()["enabled"], "description": "Optional external REA MCP server; connection is not yet implemented."},
            {"name": "stable-diffusion", "enabled": SD_WEBUI is not None, "description": "Optional local image generation; tool calls require approval."},
            {"name": "ohmygame-handoff", "enabled": True, "description": "Creates approved game-project briefs for manual hand-off; no automatic publishing or MCP connection."},
            {"name": "wled-control", "enabled": WLED is not None, "description": "Optional local WLED JSON API adapter; status is read-only and light changes require approval."}]}

class TaskCreateRequest(BaseModel):
    goal: str = Field(min_length=1, max_length=4000)

class TaskPatchRequest(BaseModel):
    expected_revision: int = Field(ge=1)
    goal: str = Field(min_length=1, max_length=4000)

class TaskEventRequest(BaseModel):
    message: str = Field(min_length=1, max_length=1000)

@app.get("/api/tasks/roles")
async def task_roles():
    return {"roles": TASK_ORCHESTRATOR.roles()}

@app.post("/api/tasks")
async def create_task(payload: TaskCreateRequest):
    try: return {"task": TASKS.create(payload.goal)}
    except ValueError as exc: raise HTTPException(status_code=400, detail=str(exc))

@app.get("/api/tasks")
async def list_tasks(limit: int = 30):
    return {"tasks": TASKS.list(limit)}

@app.get("/api/tasks/{task_id}")
async def get_task(task_id: str):
    task=TASKS.get(task_id)
    if task is None: raise HTTPException(status_code=404, detail="Task not found.")
    return {"task":task}

@app.patch("/api/tasks/{task_id}")
async def patch_task(task_id: str, payload: TaskPatchRequest):
    task = TASKS.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found.")
    if task["status"] not in {"queued", "failed"}:
        raise HTTPException(status_code=409, detail="Only queued or failed tasks can be edited.")
    try:
        return {"task": TASKS.update(task_id, goal=payload.goal,
                                     expected_revision=payload.expected_revision, actor="user")}
    except RevisionConflict as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.get("/api/tasks/{task_id}/events")
async def get_task_events(task_id: str, limit: int = 50):
    if TASKS.get(task_id) is None:
        raise HTTPException(status_code=404, detail="Task not found.")
    return {"events": TASKS.events(task_id, limit)}

@app.post("/api/tasks/{task_id}/events")
async def add_task_event(task_id: str, payload: TaskEventRequest):
    event = TASKS.append_event(task_id, payload.message, actor="user")
    if event is None:
        raise HTTPException(status_code=404, detail="Task not found.")
    return {"event": event}

@app.post("/api/tasks/{task_id}/run")
async def run_task(task_id: str):
    try: return {"task": await TASK_ORCHESTRATOR.plan(task_id)}
    except KeyError as exc: raise HTTPException(status_code=404, detail=str(exc))
    except PlannerError as exc:
        TASKS.update(task_id,status="failed",result={"error":str(exc)})
        raise HTTPException(status_code=502, detail=str(exc))
    except (ValueError, PermissionError) as exc: raise HTTPException(status_code=409, detail=str(exc))

@app.post("/api/tasks/{task_id}/approve")
async def approve_task(task_id: str):
    try: return {"task": await TASK_ORCHESTRATOR.execute(task_id,approved=True)}
    except KeyError as exc: raise HTTPException(status_code=404, detail=str(exc))
    except PermissionError as exc: raise HTTPException(status_code=403, detail=str(exc))
    except ValueError as exc: raise HTTPException(status_code=409, detail=str(exc))

@app.post("/api/tasks/{task_id}/cancel")
async def cancel_task(task_id: str):
    task=TASKS.get(task_id)
    if task is None: raise HTTPException(status_code=404, detail="Task not found.")
    if task['status'] not in {"queued","awaiting_approval"}:
        raise HTTPException(status_code=409, detail="Only queued or approval-pending tasks can be cancelled.")
    return {"task": TASKS.update(task_id,status="cancelled",result={"message":"Cancelled before execution."})}

class SessionCreateRequest(BaseModel):
    title: str = Field(default="New conversation", max_length=100)

@app.post("/api/sessions")
async def create_session(payload: SessionCreateRequest):
    return {"session": SESSIONS.create(payload.title)}

@app.get("/api/sessions")
async def list_sessions(limit: int = 30):
    return {"sessions": SESSIONS.list(limit)}

@app.get("/api/sessions/{session_id}")
async def get_session(session_id: str):
    session = SESSIONS.get(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Conversation not found.")
    return {"session": session}

@app.delete("/api/sessions/{session_id}")
async def delete_session(session_id: str):
    if not SESSIONS.delete(session_id):
        raise HTTPException(status_code=404, detail="Conversation not found.")
    return {"ok": True}

@app.get("/api/memory/search")
async def search_memories(q: str, limit: int = 5):
    if not q.strip(): raise HTTPException(status_code=400, detail="Search query is required.")
    return {"results": MEMORY.search(q, limit)}

@app.get("/api/memory")
async def memories():
    return {"memories": MEMORY.list()}

@app.post("/api/memory")
async def save_memory(payload: MemoryRequest):
    try: mid = MEMORY.add(payload.content)
    except ValueError as exc: raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True, "id": mid}

@app.delete("/api/memory/{memory_id}")
async def delete_memory(memory_id: int):
    if not MEMORY.delete(memory_id): raise HTTPException(status_code=404, detail="Memory not found.")
    return {"ok": True}

@app.post("/api/agent/ask")
async def agent_ask(payload: ChatRequest):
    """Plan with the local LLM, then run only validated registry tools.

    Approval-required plans are returned without execution. The user can review
    the exact proposed steps and submit them to /api/agent/execute with approval.
    """
    session_id = payload.session_id
    if session_id:
        try:
            SESSIONS.append(session_id, "user", payload.message.strip())
        except KeyError:
            raise HTTPException(status_code=404, detail="Conversation not found.")
    try:
        plan = await create_plan(payload.message.strip(), ollama_url=OLLAMA_URL,
                                 model=OLLAMA_MODEL, tools=TOOLS.describe(),
                                 cloud_api_key=CLOUD_API_KEY, cloud_base_url=CLOUD_BASE_URL,
                                 cloud_model=CLOUD_MODEL)
        if not plan["use_tools"]:
            # Use the normal chat route for a natural-language answer.
            answer = plan["response"] or "I can help with that. What details should I focus on?"
            if session_id: SESSIONS.append(session_id, "assistant", answer)
            return {"agent": "planner", "answer": answer, "model": (CLOUD_MODEL if CLOUD_API_KEY else OLLAMA_MODEL), "steps": [], "session_id": session_id}
        steps = [[call] for call in plan["steps"]]
        approval_needed = any(
            next(t for t in TOOLS.describe() if t["name"] == call["name"])["permission"] != "read_only"
            for call in plan["steps"]
        )
        if approval_needed:
            answer = "I prepared this plan. Review the proposed changes; nothing has been executed yet."
            if session_id: SESSIONS.append(session_id, "assistant", answer)
            return {"agent": "planner", "approval_required": True, "answer": answer,
                    "steps": steps, "model": (CLOUD_MODEL if CLOUD_API_KEY else OLLAMA_MODEL), "session_id": session_id}
        events = []
        async for event in run_tool_plan(TOOLS, steps, approved=False):
            events.append(event)
        answer = plan["response"] or "Completed the approved read-only steps."
        if session_id: SESSIONS.append(session_id, "assistant", answer)
        return {"agent": "planner", "answer": answer, "events": events, "steps": steps,
                "model": (CLOUD_MODEL if CLOUD_API_KEY else OLLAMA_MODEL), "session_id": session_id}
    except PlannerError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except (KeyError, PermissionError, ValueError, TypeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.post("/api/chat/stream")
async def chat_stream(payload: ChatRequest):
    """Stream Ollama chat tokens as Server-Sent Events (SSE)."""
    message = payload.message.strip()
    if not message:
        raise HTTPException(status_code=400, detail="Please enter a message.")
    if payload.session_id:
        try: SESSIONS.append(payload.session_id, "user", message)
        except KeyError: raise HTTPException(status_code=404, detail="Conversation not found.")

    async def generate():
        answer_parts = []
        prompt = "You are JARVIS, a helpful local AI assistant. Be clear, practical, and honest about actions.\n\n" + message
        try:
            async with httpx.AsyncClient(timeout=None) as client:
                async with client.stream("POST", f"{OLLAMA_URL}/api/chat", json={
                    "model": OLLAMA_MODEL,
                    "messages": [{"role":"user","content":prompt}],
                    "stream": True
                }) as response:
                    response.raise_for_status()
                    async for line in response.aiter_lines():
                        if not line:
                            continue
                        try: chunk = json.loads(line)
                        except json.JSONDecodeError: continue
                        token = chunk.get("message", {}).get("content", "")
                        if token:
                            answer_parts.append(token)
                            yield "data: " + json.dumps({"token":token}, ensure_ascii=False) + "\n\n"
                        if chunk.get("done"):
                            break
            final = "".join(answer_parts).strip()
            if payload.session_id and final:
                SESSIONS.append(payload.session_id, "assistant", final)
            yield "data: " + json.dumps({"done":True,"session_id":payload.session_id}) + "\n\n"
        except Exception as exc:
            yield "data: " + json.dumps({"error":f"Streaming failed: {type(exc).__name__}"}) + "\n\n"
    return StreamingResponse(generate(), media_type="text/event-stream",
                              headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})

@app.post("/api/chat")
async def chat(payload: ChatRequest):
    message = payload.message.strip()
    if not message: raise HTTPException(status_code=400, detail="Please enter a message.")
    if payload.session_id:
        try: SESSIONS.append(payload.session_id, "user", message)
        except KeyError: raise HTTPException(status_code=404, detail="Conversation not found.")
    routed = ORCHESTRATOR.dispatch(message)
    if routed:
        answer = str(routed.get("answer", routed))
        if payload.session_id: SESSIONS.append(payload.session_id, "assistant", answer)
        return {**routed, "model": "local-agent", "session_id": payload.session_id}
    prompt = (
        "You are JARVIS, a helpful, respectful personal AI assistant. "
        "Be clear and practical. Do not claim you performed actions outside this app. "
        "Ask for confirmation before consequential external actions. "
        "You may explain that local specialist tools can calculate, tell time, and save explicitly requested memories.\n\n"
        f"User: {message}"
    )
    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            if CLOUD_API_KEY:
                response = await client.post(f"{CLOUD_BASE_URL}/chat/completions",
                    headers={"Authorization": f"Bearer {CLOUD_API_KEY}"},
                    json={"model": CLOUD_MODEL, "messages": [{"role":"user", "content":prompt}], "stream":False})
                response.raise_for_status()
                data = response.json()
                answer = data.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
                model_used = CLOUD_MODEL
            else:
                response = await client.post(f"{OLLAMA_URL}/api/chat", json={
                    "model": OLLAMA_MODEL, "messages": [{"role":"user", "content":prompt}], "stream":False
                })
                response.raise_for_status()
                data = response.json()
                answer = data.get("message", {}).get("content", "").strip()
                model_used = OLLAMA_MODEL
        if not answer: raise HTTPException(status_code=502, detail="The model returned an empty response.")
        if payload.session_id: SESSIONS.append(payload.session_id, "assistant", answer)
        return {"agent":"chat", "answer":answer, "model":model_used, "session_id": payload.session_id}
    except httpx.ConnectError:
        raise HTTPException(status_code=503, detail="Cannot reach the configured AI provider. Check cloud provider settings or start Ollama and download the configured local model. Local time, calculator and memory agents still work.")
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="The model took too long to respond.")
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"Ollama returned HTTP {exc.response.status_code}. Check the model name.")
