# Private Google-account storage for JARVIS

Google Drive is suitable for a private backup of the JARVIS source and data exports. It is **not** a backend runtime: uploading Python files to Drive does not keep FastAPI, Ollama, or the news worker running.

Recommended separation:

- **Private Google Drive folder:** store a backup copy of the source ZIP and non-secret documentation. Restrict access to your account. Do not upload `.env`, API keys, access tokens, signing keys, or unencrypted conversation databases.
- **Backend runtime:** run FastAPI on a trusted computer or deploy it to a managed server/cloud service. Keep secrets in that host's secret manager or environment configuration.
- **Persistent data:** keep `data/` on a private persistent disk. Back up memory, sessions, tasks, and news databases separately; encrypt backups before putting them in Drive.
- **Android app:** contains only the client. It must never contain the cloud AI key or backend access token.

A Google Drive connection has not been authorized in this project. No account has been accessed and no files have been uploaded. If you later connect Drive, grant only the minimum file access needed and require a user-triggered backup; do not let an AI agent upload secrets or overwrite backups automatically.
