"""Local inventory and policy checks for registered JARVIS agent tools."""
from __future__ import annotations

RISKY_NAME_PARTS = ("shell", "terminal", "exec", "delete", "write", "send", "purchase", "device", "login", "account")
SENSITIVE_ARGUMENT_PARTS = ("password", "secret", "api_key", "access_token", "private_key")


def audit_registry(tool_specs: list[dict], agent_specs: list[dict] | None = None) -> dict:
    findings = []
    inventory = []
    for spec in tool_specs:
        name = str(spec.get("name", "unknown"))
        permission = spec.get("permission", "unknown")
        schema = spec.get("parameters") or {}
        properties = schema.get("properties", {}) if isinstance(schema, dict) else {}
        additional = schema.get("additionalProperties", True) if isinstance(schema, dict) else True
        inventory.append({
            "name": name,
            "description": spec.get("description", ""),
            "permission": permission,
            "concurrency_safe": bool(spec.get("concurrency_safe", False)),
            "parameter_count": len(properties) if isinstance(properties, dict) else 0,
            "schema_locked": additional is False,
            "max_output_chars": spec.get("max_output_chars"),
        })
        risky = any(part in name.lower() for part in RISKY_NAME_PARTS)
        if risky and permission == "read_only":
            findings.append({"severity": "high", "tool": name, "rule": "risky_name_read_only", "message": "Tool name suggests a mutating or high-impact action but its permission is read-only."})
        if not isinstance(schema, dict) or not schema:
            findings.append({"severity": "medium", "tool": name, "rule": "missing_argument_contract", "message": "Tool has no explicit parameter schema; add a bounded argument contract."})
        elif not properties and additional is not False:
            findings.append({"severity": "medium", "tool": name, "rule": "missing_argument_contract", "message": "Tool has no explicit argument contract; declare an empty, closed object if it accepts no arguments."})
        elif properties and additional is not False:
            findings.append({"severity": "medium", "tool": name, "rule": "open_argument_schema", "message": "Tool schema permits undeclared arguments."})
        if isinstance(properties, dict):
            for argument_name, rule in properties.items():
                if any(part in argument_name.lower() for part in SENSITIVE_ARGUMENT_PARTS):
                    findings.append({"severity": "medium", "tool": name, "rule": "secret_in_tool_arguments", "message": f"Argument '{argument_name}' may expose a credential to the planner; prefer server-side secret configuration."})
                if isinstance(rule, dict) and rule.get("type") == "string" and "maxLength" not in rule:
                    findings.append({"severity": "low", "tool": name, "rule": "unbounded_string_argument", "message": f"String argument '{argument_name}' has no maximum length."})
    findings.sort(key=lambda item: ({"critical": 0, "high": 1, "medium": 2, "low": 3}.get(item["severity"], 4), item.get("tool", ""), item["rule"]))
    return {
        "scope": "registered_local_tools_only",
        "tool_count": len(inventory),
        "agent_count": len(agent_specs or []),
        "tools": inventory,
        "agents": agent_specs or [],
        "findings_count": len(findings),
        "findings": findings,
        "limitations": [
            "This report inspects local JARVIS registry metadata only.",
            "It does not connect to external MCP servers or inspect their runtime behavior.",
            "It does not modify, enable, disable, or delete tools or configuration.",
        ],
    }
