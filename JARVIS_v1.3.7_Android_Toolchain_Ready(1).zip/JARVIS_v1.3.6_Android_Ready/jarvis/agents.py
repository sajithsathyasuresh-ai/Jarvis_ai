"""Deterministic local agents and a small, auditable task router."""
import ast
import operator
from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

_ALLOWED = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod,
    ast.USub: operator.neg, ast.UAdd: operator.pos,
}

def safe_calculate(expression: str):
    if len(expression) > 120:
        raise ValueError("Expression is too long.")
    tree = ast.parse(expression, mode="eval")
    def visit(node):
        if isinstance(node, ast.Expression): return visit(node.body)
        if isinstance(node, ast.Constant) and type(node.value) in (int, float): return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED:
            left, right = visit(node.left), visit(node.right)
            if isinstance(node.op, ast.Pow) and abs(right) > 8:
                raise ValueError("Exponent is too large.")
            result = _ALLOWED[type(node.op)](left, right)
            if abs(result) > 1e100: raise ValueError("Result is too large.")
            return result
        if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED:
            return _ALLOWED[type(node.op)](visit(node.operand))
        raise ValueError("Only basic arithmetic is allowed.")
    return visit(tree)

class TimeAgent:
    name = "time"
    def run(self, _message: str) -> str:
        try: now = datetime.now(ZoneInfo("Asia/Kolkata"))
        except ZoneInfoNotFoundError: now = datetime.now()
        return now.strftime("It is %I:%M %p on %A, %d %B %Y (%Z).")

class CalculatorAgent:
    name = "calculator"
    prefixes = ("calculate ", "what is ", "compute ")
    def run(self, message: str) -> str:
        expr = message.strip()
        low = expr.lower()
        for prefix in self.prefixes:
            if low.startswith(prefix):
                expr = expr[len(prefix):].strip(); break
        return f"Result: {safe_calculate(expr)}"

class AgentRouter:
    def __init__(self, memory):
        self.memory = memory
        self.agents = [TimeAgent(), CalculatorAgent()]
    def describe(self):
        return [
            {"name":"planner", "description":"Routes a request to a suitable local specialist."},
            {"name":"time", "description":"Reports local date and time (Asia/Kolkata)."},
            {"name":"calculator", "description":"Evaluates basic arithmetic without executing arbitrary code."},
            {"name":"memory", "description":"Saves and retrieves user-approved notes in local SQLite."},
            {"name":"chat", "description":"Uses the configured Ollama language model."},
        ]
    def dispatch(self, message: str):
        text = message.strip()
        low = text.lower()
        if low in {"time", "what time is it", "what is the time", "date", "what is today's date"}:
            return {"agent":"time", "answer":self.agents[0].run(text)}
        if low.startswith(("calculate ", "compute ")) or low.startswith("what is ") and any(c in text for c in "+-*/%()"):
            try: return {"agent":"calculator", "answer":self.agents[1].run(text)}
            except (ValueError, SyntaxError, ZeroDivisionError) as e: return {"agent":"calculator", "answer":f"I couldn't calculate that: {e}"}
        if low.startswith("remember that ") or low.startswith("save to memory: "):
            content = text.split(":",1)[1] if low.startswith("save to memory:") else text[len("remember that "):]
            try:
                mid = self.memory.add(content)
                return {"agent":"memory", "answer":f"Saved to local memory (ID {mid})."}
            except ValueError as e: return {"agent":"memory", "answer":str(e)}
        if low in {"show my memories", "list memories", "what do you remember"}:
            items = self.memory.list()
            if not items: return {"agent":"memory", "answer":"There are no saved memories yet."}
            return {"agent":"memory", "answer":"Saved memories:\n" + "\n".join(f"{x['id']}. {x['content']}" for x in items)}
        return None
