"""Local, bounded conversation-session persistence for JARVIS."""
from __future__ import annotations
import sqlite3
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any

class SessionStore:
    def __init__(self, path: str):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS sessions (
                id TEXT PRIMARY KEY, title TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
            db.execute("""CREATE TABLE IF NOT EXISTS session_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
                role TEXT NOT NULL CHECK(role IN ('user','assistant')),
                content TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")

    @contextmanager
    def _connect(self):
        db = sqlite3.connect(self.path)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        try:
            with db:
                yield db
        finally:
            db.close()

    def create(self, title: str = "New conversation") -> dict[str, Any]:
        sid = str(uuid.uuid4())
        title = (title or "New conversation").strip()[:100] or "New conversation"
        with self._connect() as db:
            db.execute("INSERT INTO sessions(id,title) VALUES (?,?)", (sid,title))
            row = db.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone()
        return dict(row)

    def list(self, limit: int = 30) -> list[dict[str, Any]]:
        with self._connect() as db:
            rows = db.execute("SELECT id,title,created_at,updated_at FROM sessions ORDER BY updated_at DESC LIMIT ?",
                              (max(1,min(int(limit),100)),)).fetchall()
            return [dict(r) for r in rows]

    def append(self, session_id: str, role: str, content: str) -> dict[str, Any]:
        if role not in {"user","assistant"}:
            raise ValueError("Role must be user or assistant.")
        if not isinstance(content,str) or not content.strip() or len(content)>12000:
            raise ValueError("Message must contain 1–12000 characters.")
        with self._connect() as db:
            exists = db.execute("SELECT id FROM sessions WHERE id=?", (session_id,)).fetchone()
            if not exists:
                raise KeyError("Conversation not found.")
            db.execute("INSERT INTO session_messages(session_id,role,content) VALUES (?,?,?)",
                       (session_id,role,content.strip()))
            if role == "user":
                count = db.execute("SELECT COUNT(*) AS n FROM session_messages WHERE session_id=?",
                                   (session_id,)).fetchone()["n"]
                if count == 1:
                    db.execute("UPDATE sessions SET title=? WHERE id=?",
                               (content.strip()[:80],session_id))
            db.execute("UPDATE sessions SET updated_at=CURRENT_TIMESTAMP WHERE id=?", (session_id,))
            row = db.execute("SELECT * FROM session_messages WHERE id=last_insert_rowid()").fetchone()
        return dict(row)

    def get(self, session_id: str, limit: int = 100) -> dict[str, Any] | None:
        with self._connect() as db:
            session = db.execute("SELECT * FROM sessions WHERE id=?", (session_id,)).fetchone()
            if not session:
                return None
            messages = db.execute("""SELECT role,content,created_at FROM session_messages
                WHERE session_id=? ORDER BY id DESC LIMIT ?""",
                (session_id,max(1,min(int(limit),200)))).fetchall()
            return {**dict(session), "messages":[dict(m) for m in reversed(messages)]}

    def delete(self, session_id: str) -> bool:
        with self._connect() as db:
            cur = db.execute("DELETE FROM sessions WHERE id=?", (session_id,))
            return cur.rowcount > 0
