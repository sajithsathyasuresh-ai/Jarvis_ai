"""A bounded, observable workflow loop for pre-planned JARVIS tool steps.

The source guide describes an async-generator agent loop. This implementation
keeps that useful shape but deliberately does not pretend to be an autonomous
LLM planner: a caller supplies each step, and the registry enforces permissions.
"""
from __future__ import annotations

from typing import Any, AsyncIterator
from jarvis.tool_system import ToolRegistry


async def run_tool_plan(
    registry: ToolRegistry,
    steps: list[list[dict[str, Any]]],
    *,
    approved: bool = False,
    max_turns: int = 8,
) -> AsyncIterator[dict[str, Any]]:
    if not isinstance(steps, list) or not 1 <= len(steps) <= max_turns:
        raise ValueError(f"A plan must contain 1 to {max_turns} steps.")
    for turn, calls in enumerate(steps, start=1):
        yield {"type": "step_started", "turn": turn, "tool_count": len(calls)}
        results = await registry.invoke_batch(calls, approved=approved)
        yield {"type": "step_completed", "turn": turn, "results": results}
    yield {"type": "completed", "turns": len(steps)}
