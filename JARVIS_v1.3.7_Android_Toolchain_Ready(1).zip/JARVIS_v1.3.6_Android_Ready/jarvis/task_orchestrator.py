"""Multi-role task workflow: planner, researcher, coder, reviewer, executor."""
from __future__ import annotations
from typing import Any
from jarvis.planner import create_plan
from jarvis.agent_loop import run_tool_plan

ROLE_DESCRIPTIONS = {
    "planner": "Breaks the user's goal into a bounded tool plan.",
    "researcher": "Collects context only through registered read-only tools.",
    "coder": "Prepares workspace file changes using workspace tools; never executes arbitrary code.",
    "reviewer": "Checks proposed tools, arguments, permissions, and plan limits before execution.",
    "executor": "Runs validated read-only actions and waits for approval for changes.",
}

class TaskOrchestrator:
    def __init__(self, store, registry, *, ollama_url: str, model: str):
        self.store, self.registry = store, registry
        self.ollama_url, self.model = ollama_url, model
    def roles(self): return [{"name":k,"description":v} for k,v in ROLE_DESCRIPTIONS.items()]
    def review(self, calls: list[dict[str, Any]]):
        if not isinstance(calls,list) or not 1 <= len(calls) <= 4:
            raise ValueError("Reviewer rejected the plan: expected 1–4 tool calls.")
        specs={x['name']:x for x in self.registry.describe()}
        for call in calls:
            if not isinstance(call,dict) or call.get('name') not in specs:
                raise ValueError("Reviewer rejected an unknown tool.")
            if not isinstance(call.get('arguments',{}),dict):
                raise ValueError("Reviewer rejected non-object tool arguments.")
            # Validate exact argument shape against the registry before any execution.
            self.registry.validate_call(call)
            # Disallow dangerous tool families even if accidentally registered later.
            if any(word in call['name'].lower() for word in ("shell", "terminal", "device", "login", "purchase", "message.send")):
                raise ValueError("Reviewer blocked a high-impact tool.")
        return {"approved":True,"checked_calls":len(calls),"note":"Tool names, argument shapes, and permission levels checked."}
    async def plan(self, task_id: str):
        task=self.store.get(task_id)
        if not task: raise KeyError("Task not found.")
        if task['status'] not in {"queued","failed"}: raise ValueError("Task is not in a plannable state.")
        self.store.update(task_id,status="planning",result={"stage":"planner"})
        plan=await create_plan(task['goal'],ollama_url=self.ollama_url,model=self.model,tools=self.registry.describe())
        calls=plan['steps'] if plan['use_tools'] else []
        review=self.review(calls) if calls else {"approved":True,"checked_calls":0,"note":"No tools required."}
        needs_approval=any(next(t for t in self.registry.describe() if t['name']==c['name'])['permission']!="read_only" for c in calls)
        record={"roles":["planner","researcher","coder","reviewer","executor"],"response":plan.get('response',''),"steps":calls,"review":review,"approval_required":needs_approval}
        status="awaiting_approval" if needs_approval else "planned"
        # 'planned' is represented as queued to keep persisted states constrained.
        self.store.update(task_id,status="awaiting_approval" if needs_approval else "running",plan=record,result={"stage":"reviewed","message":"Awaiting approval." if needs_approval else "Plan reviewed; executing read-only tools."})
        if not calls:
            self.store.update(task_id,status="completed",result={"stage":"completed","answer":plan.get('response') or "No tool execution was needed."})
        elif not needs_approval:
            await self.execute(task_id, approved=False)
        return self.store.get(task_id)
    async def execute(self, task_id: str, *, approved: bool):
        task=self.store.get(task_id)
        if not task: raise KeyError("Task not found.")
        if task['status']=="awaiting_approval" and not approved: raise PermissionError("Explicit approval is required.")
        if task['status'] not in {"awaiting_approval","running"}: raise ValueError("Task is not ready to execute.")
        calls=task['plan'].get('steps',[])
        self.store.update(task_id,status="running",result={"stage":"executor","message":"Executing validated tool plan."})
        events=[]
        async for event in run_tool_plan(self.registry,[[c] for c in calls],approved=approved): events.append(event)
        failures=[r for e in events if e.get('type')=="step_completed" for r in e.get('results',[]) if not r.get('ok')]
        final={"stage":"completed" if not failures else "failed","events":events,"review":task['plan'].get('review')}
        self.store.update(task_id,status="failed" if failures else "completed",result=final)
        return self.store.get(task_id)
