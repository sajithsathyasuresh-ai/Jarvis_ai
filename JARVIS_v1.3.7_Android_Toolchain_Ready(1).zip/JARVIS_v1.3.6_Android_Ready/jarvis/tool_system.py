"""Auditable, fail-closed tool registry for JARVIS.

Design principles adapted from the user-supplied educational architecture guide:
validated inputs, centralized execution, permission checks, bounded outputs,
and conservative concurrency defaults. This is an original Python implementation,
not Claude Code source code.
"""
import asyncio
from dataclasses import dataclass
from typing import Any, Callable

@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    permission: str = "approval"  # approval | read_only
    concurrency_safe: bool = False
    max_output_chars: int = 4000
    parameters: dict[str, Any] | None = None

class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, tuple[ToolSpec, Callable[[dict[str, Any]], Any]]] = {}

    def register(self, spec: ToolSpec, handler: Callable[[dict[str, Any]], Any]):
        if not spec.name or spec.name in self._tools:
            raise ValueError("Tool name must be non-empty and unique.")
        if spec.permission not in {"read_only", "approval"}:
            raise ValueError("Unknown permission level.")
        if spec.concurrency_safe and spec.permission != "read_only":
            raise ValueError("Only read-only tools can be concurrency-safe.")
        if not 1 <= spec.max_output_chars <= 20000:
            raise ValueError("max_output_chars must be between 1 and 20000.")
        # Fail closed: tools are never parallel-safe unless explicitly declared.
        self._tools[spec.name] = (spec, handler)

    def describe(self):
        return [
            {"name": spec.name, "description": spec.description,
             "permission": spec.permission, "concurrency_safe": spec.concurrency_safe,
             "parameters": spec.parameters or {"type": "object", "additionalProperties": True},
             "max_output_chars": spec.max_output_chars}
            for spec, _ in self._tools.values()
        ]

    @staticmethod
    def _validate_arguments(spec: ToolSpec, arguments: dict[str, Any]):
        """Validate a deliberately small JSON-Schema subset before any handler runs."""
        if not isinstance(arguments, dict):
            raise ValueError("Tool arguments must be a JSON object.")
        schema = spec.parameters
        if not schema:
            return
        if schema.get("type", "object") != "object":
            raise ValueError("Tool schema must describe an object.")
        properties = schema.get("properties", {})
        required = schema.get("required", [])
        if not isinstance(properties, dict) or not isinstance(required, list):
            raise ValueError("Tool schema is invalid.")
        missing = [key for key in required if key not in arguments]
        if missing:
            raise ValueError("Missing required argument(s): " + ", ".join(missing))
        if schema.get("additionalProperties", False) is False:
            unknown = set(arguments) - set(properties)
            if unknown:
                raise ValueError("Unsupported argument(s): " + ", ".join(sorted(unknown)))
        type_map = {"string": str, "integer": int, "number": (int, float), "boolean": bool}
        for key, value in arguments.items():
            rule = properties.get(key)
            if rule is None:
                continue
            expected = rule.get("type")
            py_type = type_map.get(expected)
            if py_type is None:
                raise ValueError(f"Unsupported schema type for '{key}'.")
            if expected in {"integer", "number"} and isinstance(value, bool):
                raise ValueError(f"Argument '{key}' has the wrong type.")
            if not isinstance(value, py_type):
                raise ValueError(f"Argument '{key}' must be {expected}.")
            if expected == "string":
                if len(value) < rule.get("minLength", 0) or len(value) > rule.get("maxLength", 100000):
                    raise ValueError(f"Argument '{key}' has an invalid length.")
            if expected in {"integer", "number"}:
                if "minimum" in rule and value < rule["minimum"]:
                    raise ValueError(f"Argument '{key}' is below its minimum.")
                if "maximum" in rule and value > rule["maximum"]:
                    raise ValueError(f"Argument '{key}' exceeds its maximum.")
            if "enum" in rule and value not in rule["enum"]:
                raise ValueError(f"Argument '{key}' is not an allowed value.")

    def validate_call(self, call: dict[str, Any]):
        if not isinstance(call, dict):
            raise ValueError("Tool call must be an object.")
        name = call.get("name")
        if name not in self._tools:
            raise KeyError("Unknown tool.")
        arguments = call.get("arguments", {})
        spec, _ = self._tools[name]
        self._validate_arguments(spec, arguments)
        return spec

    def invoke(self, name: str, arguments: dict[str, Any], approved: bool = False):
        if name not in self._tools:
            raise KeyError("Unknown tool.")
        spec, handler = self._tools[name]
        self._validate_arguments(spec, arguments)
        if spec.permission != "read_only" and not approved:
            raise PermissionError("This tool requires explicit user approval.")
        result = handler(arguments)
        rendered = str(result)
        if len(rendered) > spec.max_output_chars:
            rendered = rendered[:spec.max_output_chars] + "… [truncated]"
        return {"tool": name, "result": rendered, "permission": spec.permission}

    async def invoke_batch(self, calls: list[dict[str, Any]], approved: bool = False):
        """Execute a bounded batch: explicitly safe reads may run together; all
        other tools run sequentially. Preflight permissions prevent partial runs.
        Results retain the caller's original order.
        """
        if not isinstance(calls, list) or not 1 <= len(calls) <= 12:
            raise ValueError("A batch must contain between 1 and 12 tool calls.")
        prepared = []
        for index, call in enumerate(calls):
            if not isinstance(call, dict):
                raise ValueError("Each tool call must be an object.")
            name = call.get("name")
            arguments = call.get("arguments", {})
            if name not in self._tools:
                raise KeyError(f"Unknown tool at position {index}.")
            if not isinstance(arguments, dict):
                raise ValueError("Tool arguments must be a JSON object.")
            spec, _ = self._tools[name]
            self._validate_arguments(spec, arguments)
            if spec.permission != "read_only" and not approved:
                raise PermissionError(f"Tool '{name}' requires explicit approval; no batch calls were run.")
            prepared.append((index, name, arguments, spec))

        async def execute(item):
            index, name, arguments, spec = item
            try:
                result = await asyncio.to_thread(self.invoke, name, arguments, approved=approved)
                return index, {"ok": True, **result}
            except Exception as exc:
                return index, {"ok": False, "tool": name, "error": str(exc)[:500]}

        # A safe-read run is parallelized only when every call in the batch is
        # explicitly marked safe. Mixed or mutating batches are serialized.
        if all(item[3].permission == "read_only" and item[3].concurrency_safe for item in prepared):
            completed = await asyncio.gather(*(execute(item) for item in prepared))
        else:
            completed = []
            for item in prepared:
                completed.append(await execute(item))
        return [result for _, result in sorted(completed, key=lambda pair: pair[0])]
