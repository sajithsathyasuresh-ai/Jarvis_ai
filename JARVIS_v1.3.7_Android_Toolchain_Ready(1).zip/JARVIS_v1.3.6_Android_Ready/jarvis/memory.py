"""Small local SQLite memory store. Stores only information explicitly saved by the user."""
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import List, Dict

class MemoryStore:
    def __init__(self, path: str):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS memories (id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
        from jarvis.integrations.mem0_adapter import Mem0Adapter
        try:
            self.semantic = Mem0Adapter(str(Path(self.path).parent))
        except Exception:
            # Optional integration failures must never prevent the local app starting.
            self.semantic = None

    @contextmanager
    def _connect(self):
        db = sqlite3.connect(self.path)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    def add(self, content: str) -> int:
        content = content.strip()
        if not content or len(content) > 2000:
            raise ValueError("Memory must contain 1–2000 characters.")
        with self._connect() as db:
            cur = db.execute("INSERT INTO memories(content) VALUES (?)", (content,))
            memory_id = int(cur.lastrowid)
        # Semantic indexing is optional; SQLite remains available if Mem0 is off.
        if self.semantic is not None and self.semantic.enabled:
            try:
                self.semantic.add(content)
            except Exception:
                # Do not lose the local save if an optional vector service is unavailable.
                pass
        return memory_id

    def list(self, limit: int = 50) -> List[Dict]:
        with self._connect() as db:
            rows = db.execute("SELECT id, content, created_at FROM memories ORDER BY id DESC LIMIT ?", (max(1, min(limit, 100)),)).fetchall()
            return [dict(r) for r in rows]

    def search(self, query: str, limit: int = 5):
        if self.semantic is not None and self.semantic.enabled:
            try:
                return self.semantic.search(query, limit)
            except Exception:
                pass
        q = f"%{query.strip()}%"
        with self._connect() as db:
            rows = db.execute("SELECT id, content, created_at FROM memories WHERE content LIKE ? ORDER BY id DESC LIMIT ?", (q, max(1, min(limit, 20)))).fetchall()
            return [dict(r) for r in rows]

    def delete(self, memory_id: int) -> bool:
        with self._connect() as db:
            cur = db.execute("DELETE FROM memories WHERE id = ?", (memory_id,))
            return cur.rowcount > 0
