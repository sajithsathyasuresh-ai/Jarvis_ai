"""Optional LangGraph orchestration with a dependency-free fallback."""
from typing import TypedDict, Any

class RequestState(TypedDict, total=False):
    message: str
    result: dict[str, Any] | None

class Orchestrator:
    def __init__(self, router):
        self.router = router
        self.backend = "builtin"
        self.graph = None
        try:
            from langgraph.graph import END, START, StateGraph
            builder = StateGraph(RequestState)
            def dispatch_node(state: RequestState):
                return {"result": self.router.dispatch(state["message"])}
            builder.add_node("dispatch", dispatch_node)
            builder.add_edge(START, "dispatch")
            builder.add_edge("dispatch", END)
            self.graph = builder.compile()
            self.backend = "langgraph"
        except ImportError:
            pass

    def dispatch(self, message: str):
        if self.graph is None:
            return self.router.dispatch(message)
        return self.graph.invoke({"message": message}).get("result")

    def describe(self):
        return {"name": "orchestrator", "backend": self.backend,
                "description": "Routes requests through LangGraph when installed; otherwise uses the built-in router."}
