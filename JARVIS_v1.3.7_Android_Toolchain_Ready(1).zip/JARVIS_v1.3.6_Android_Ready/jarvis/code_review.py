"""Small, deterministic, read-only source review rules for JARVIS.

This module never executes reviewed code or transmits it to a remote service.
"""
from __future__ import annotations

import re
from typing import Any

MAX_SOURCE_CHARS = 100_000

RULES = (
    ("JRV001", "critical", re.compile(r"\beval\s*\("), "Dynamic eval() can execute data as code.", "Replace eval with a strict parser or an explicit allowlist of operations."),
    ("JRV002", "high", re.compile(r"\bexec\s*\("), "exec() executes dynamically constructed code.", "Avoid dynamic code execution; use fixed functions and validated inputs."),
    ("JRV003", "high", re.compile(r"\bos\.system\s*\("), "os.system() launches a shell command.", "Use a fixed executable with subprocess argument arrays and validated parameters."),
    ("JRV004", "high", re.compile(r"\bsubprocess\.(?:run|Popen|call|check_output)\s*\([^\n]*\bshell\s*=\s*True"), "Subprocess call enables shell interpretation.", "Use shell=False and pass arguments as a list."),
    ("JRV005", "high", re.compile(r"\bpickle\.loads?\s*\("), "Pickle can execute code when loading untrusted data.", "Use JSON or another data-only serialization format for untrusted input."),
    ("JRV006", "medium", re.compile(r"\bverify\s*=\s*False\b"), "TLS certificate verification is disabled.", "Keep certificate verification enabled; configure a trusted CA when needed."),
    ("JRV007", "high", re.compile(r"(?i)(?:api[_-]?key|client[_-]?secret|password|access[_-]?token)\s*[:=]\s*['\"][^'\"]{8,}['\"]"), "Possible hard-coded credential value.", "Load secrets from a protected environment or secret store; rotate any exposed credential."),
    ("JRV008", "high", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"), "Private-key material appears in source text.", "Remove key material from source control and rotate the affected key."),
    ("JRV009", "medium", re.compile(r"(?i)allow_origins\s*=\s*\[\s*['\"]\*['\"]\s*\].{0,120}allow_credentials\s*=\s*True"), "Wildcard CORS origin is combined with credentials.", "Use an explicit origin allowlist and review credential requirements."),
    ("JRV010", "low", re.compile(r"\bexcept\s+Exception\s*:\s*(?:pass)?\s*$"), "Broad exception handling may hide failures.", "Catch the expected exception types and log a safe diagnostic."),
    ("JRV011", "high", re.compile(r"\byaml\.load\s*\("), "yaml.load() may construct unsafe Python objects when used with untrusted input.", "Use yaml.safe_load() or a SafeLoader for untrusted YAML."),
    ("JRV012", "medium", re.compile(r"\btempfile\.mktemp\s*\("), "mktemp() can create a race between choosing and creating a temporary path.", "Use NamedTemporaryFile or another API that creates the file atomically."),
    ("JRV013", "low", re.compile(r"\bhashlib\.(?:md5|sha1)\s*\("), "Legacy hash algorithm may be unsuitable for security-sensitive integrity checks.", "Use SHA-256 or a modern keyed hash when integrity or authenticity matters."),
)


def review_source(content: str, filename: str = "<input>") -> dict[str, Any]:
    if not isinstance(content, str) or not content.strip():
        raise ValueError("Source content must be a non-empty string.")
    if len(content) > MAX_SOURCE_CHARS:
        raise ValueError(f"Source content exceeds the {MAX_SOURCE_CHARS}-character limit.")
    if not isinstance(filename, str) or len(filename) > 160:
        raise ValueError("Filename must be a string of at most 160 characters.")

    findings = []
    lines = content.splitlines()
    for line_number, line in enumerate(lines, start=1):
        for rule_id, severity, pattern, message, recommendation in RULES:
            match = pattern.search(line)
            if not match:
                continue
            # Avoid flagging obvious sample placeholders as embedded secrets.
            if rule_id == "JRV007":
                value = match.group(0).lower()
                if any(marker in value for marker in ("example", "placeholder", "your_", "change_me", "changeme", "xxxx")):
                    continue
            findings.append({
                "rule_id": rule_id,
                "severity": severity,
                "filename": filename or "<input>",
                "line": line_number,
                "message": message,
                "recommendation": recommendation,
            })

    counts = {severity: sum(1 for item in findings if item["severity"] == severity)
              for severity in ("critical", "high", "medium", "low")}
    return {
        "reviewed": True,
        "mode": "local_static_rules",
        "filename": filename or "<input>",
        "lines_scanned": len(lines),
        "findings_count": len(findings),
        "severity_counts": counts,
        "findings": findings[:100],
        "truncated": len(findings) > 100,
        "note": "This deterministic pass is a safety aid, not a complete security audit. Reviewed source was not executed or uploaded.",
    }


PROJECT_EXTENSIONS = {".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".java", ".kt", ".go", ".rs", ".php", ".rb", ".cs", ".yaml", ".yml", ".toml"}
PROJECT_SKIP_DIRS = {".git", ".venv", "venv", "node_modules", "__pycache__", ".pytest_cache", "tests", "data", "dist", "build", "android", "static-dist"}


def review_project(root: str, *, max_files: int = 100, max_total_bytes: int = 2_000_000) -> dict[str, Any]:
    """Read-only static scan of source files under a project root; never executes code."""
    from pathlib import Path

    base = Path(root).resolve(strict=True)
    if not base.is_dir():
        raise ValueError("Project root must be a directory.")
    scanned = 0
    total_bytes = 0
    findings: list[dict[str, Any]] = []
    skipped = 0
    for path in sorted(base.rglob("*")):
        if not path.is_file() or path.is_symlink() or path.suffix.lower() not in PROJECT_EXTENSIONS:
            continue
        relative = path.relative_to(base)
        if any(part in PROJECT_SKIP_DIRS for part in relative.parts) or relative.as_posix() == "jarvis/code_review.py":
            # The scanner's own regex literals naturally resemble the patterns it detects.
            continue
        if scanned >= max_files:
            skipped += 1
            continue
        try:
            size = path.stat().st_size
            if size > MAX_SOURCE_CHARS or total_bytes + size > max_total_bytes:
                skipped += 1
                continue
            content = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError):
            skipped += 1
            continue
        total_bytes += size
        scanned += 1
        report = review_source(content, str(relative))
        findings.extend(report["findings"])
    counts = {severity: sum(1 for item in findings if item["severity"] == severity)
              for severity in ("critical", "high", "medium", "low")}
    findings.sort(key=lambda item: ({"critical": 0, "high": 1, "medium": 2, "low": 3}.get(item["severity"], 4), item["filename"], item["line"]))
    return {
        "reviewed": True,
        "mode": "local_read_only_project_static_scan",
        "files_scanned": scanned,
        "bytes_scanned": total_bytes,
        "files_skipped_by_limits_or_read_errors": skipped,
        "findings_count": len(findings),
        "severity_counts": counts,
        "findings": findings[:250],
        "truncated": len(findings) > 250,
        "note": "Static defensive checks only. No network probes, exploitation, payloads, shell execution, or code modification were performed.",
    }
