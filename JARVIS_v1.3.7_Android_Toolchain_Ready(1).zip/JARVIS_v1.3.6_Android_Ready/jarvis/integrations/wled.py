"""Small, permission-gated WLED JSON API adapter.

This is an original client for WLED's documented JSON API. It does not bundle
or copy WLED firmware/source code. Targets must be explicitly configured and
must resolve syntactically to localhost or an RFC1918 IPv4 address.
"""
from __future__ import annotations

import ipaddress
import re
from urllib.parse import urlsplit

import httpx


def _private_base_url(value: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("Set JARVIS_WLED_URL to your WLED device's local HTTP URL.")
    parsed = urlsplit(value.strip())
    if parsed.scheme != "http" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("WLED URL must be plain HTTP on a local network, without embedded credentials.")
    if parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
        raise ValueError("WLED URL must contain only scheme, host, and optional port.")
    host = parsed.hostname.lower()
    if host == "localhost":
        pass
    else:
        try:
            address = ipaddress.ip_address(host)
        except ValueError as exc:
            raise ValueError("Use localhost or a private IPv4 address; hostnames and public addresses are blocked.") from exc
        if not isinstance(address, ipaddress.IPv4Address) or not address.is_private or address.is_link_local or address.is_multicast or address.is_unspecified:
            raise ValueError("WLED target must be a private IPv4 address or localhost.")
    port = f":{parsed.port}" if parsed.port else ""
    return f"http://{host}{port}"


class WLEDAdapter:
    def __init__(self, base_url: str, timeout: float = 4.0):
        self.base_url = _private_base_url(base_url)
        self.timeout = max(1.0, min(float(timeout), 10.0))

    def status(self) -> dict:
        with httpx.Client(timeout=self.timeout, follow_redirects=False) as client:
            state_response = client.get(f"{self.base_url}/json/state")
            state_response.raise_for_status()
            info_response = client.get(f"{self.base_url}/json/info")
            info_response.raise_for_status()
        state = state_response.json()
        info = info_response.json()
        if not isinstance(state, dict) or not isinstance(info, dict):
            raise ValueError("WLED returned an unexpected JSON response.")
        return {
            "enabled": True,
            "connected": True,
            "device": {
                "name": info.get("name"),
                "version": info.get("ver"),
                "led_count": info.get("leds", {}).get("count") if isinstance(info.get("leds"), dict) else None,
            },
            "state": {
                "on": state.get("on"),
                "brightness": state.get("bri"),
                "preset": state.get("ps"),
                "segment_count": len(state.get("seg", [])) if isinstance(state.get("seg"), list) else None,
            },
        }

    def set_state(self, args: dict) -> dict:
        if not isinstance(args, dict) or not args:
            raise ValueError("Provide at least one WLED state change.")
        allowed = {"on", "brightness", "transition_ms", "color", "segment_id"}
        unknown = set(args) - allowed
        if unknown:
            raise ValueError(f"Unsupported WLED fields: {', '.join(sorted(unknown))}")
        payload: dict = {}
        if "on" in args:
            if not isinstance(args["on"], bool):
                raise ValueError("on must be true or false.")
            payload["on"] = args["on"]
        if "brightness" in args:
            bri = args["brightness"]
            if isinstance(bri, bool) or not isinstance(bri, int) or not 1 <= bri <= 255:
                raise ValueError("brightness must be an integer from 1 to 255.")
            payload["bri"] = bri
        if "transition_ms" in args:
            transition = args["transition_ms"]
            if isinstance(transition, bool) or not isinstance(transition, int) or not 0 <= transition <= 65535:
                raise ValueError("transition_ms must be an integer from 0 to 65535.")
            payload["transition"] = transition
        if "color" in args:
            color = args["color"]
            if isinstance(color, str) and re.fullmatch(r"#?[0-9a-fA-F]{6}", color):
                color = color.lstrip("#")
                rgb = [int(color[i:i + 2], 16) for i in (0, 2, 4)]
            elif isinstance(color, list) and len(color) == 3 and all(isinstance(v, int) and not isinstance(v, bool) and 0 <= v <= 255 for v in color):
                rgb = color
            else:
                raise ValueError("color must be a six-digit RGB hex string or [r, g, b].")
            segment_id = args.get("segment_id", 0)
            if isinstance(segment_id, bool) or not isinstance(segment_id, int) or not 0 <= segment_id <= 31:
                raise ValueError("segment_id must be an integer from 0 to 31.")
            payload["seg"] = [{"id": segment_id, "col": [rgb]}]
        elif "segment_id" in args:
            raise ValueError("segment_id can only be used together with color.")
        with httpx.Client(timeout=self.timeout, follow_redirects=False) as client:
            response = client.post(f"{self.base_url}/json/state", json=payload)
            response.raise_for_status()
        result = response.json() if response.content else {"accepted": True}
        return {"sent": payload, "device_response": result}
