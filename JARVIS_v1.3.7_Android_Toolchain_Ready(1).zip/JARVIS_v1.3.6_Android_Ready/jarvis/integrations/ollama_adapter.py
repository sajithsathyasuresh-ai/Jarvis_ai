"""Bounded client for a local Ollama server; no model downloads or remote hosts."""
from __future__ import annotations

import ipaddress
import re
from urllib.parse import urlsplit

import httpx


class OllamaLocalAdapter:
    def __init__(self, base_url: str = "http://127.0.0.1:11434"):
        self.base_url = self._validate_base_url(base_url)

    @staticmethod
    def _validate_base_url(value: str) -> str:
        parsed = urlsplit((value or "").strip())
        if parsed.scheme != "http" or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("Ollama must use an unauthenticated HTTP loopback address.")
        if parsed.path not in ("", "/") or parsed.query or parsed.fragment:
            raise ValueError("Ollama URL must be a server root URL without a path or query.")
        host = parsed.hostname.lower()
        try:
            is_loopback = ipaddress.ip_address(host).is_loopback
        except ValueError:
            is_loopback = host == "localhost"
        if not is_loopback:
            raise ValueError("Remote Ollama hosts are not allowed by the local adapter.")
        port = f":{parsed.port}" if parsed.port else ""
        authority = f"[{host}]" if ":" in host else host
        return f"http://{authority}{port}"

    async def models(self) -> dict:
        async with httpx.AsyncClient(timeout=4.0, trust_env=False) as client:
            response = await client.get(f"{self.base_url}/api/tags")
            response.raise_for_status()
            payload = response.json()
        if not isinstance(payload, dict):
            raise ValueError("Ollama returned an invalid model inventory.")
        models = []
        for item in payload.get("models", [])[:100]:
            if not isinstance(item, dict) or not isinstance(item.get("name"), str):
                continue
            details = item.get("details")
            if not isinstance(details, dict):
                details = {}
            models.append({
                "name": item["name"][:120],
                "size": item.get("size") if isinstance(item.get("size"), int) else None,
                "modified_at": str(item.get("modified_at", ""))[:40],
                "family": str(details.get("family", ""))[:40],
            })
        return {"connected": True, "base_url": self.base_url, "models": models, "count": len(models)}

    async def chat(self, model: str, message: str) -> dict:
        if not isinstance(model, str) or not re.fullmatch(r"[A-Za-z0-9._:/-]{1,120}", model):
            raise ValueError("Invalid model name.")
        if not isinstance(message, str) or not message.strip() or len(message) > 4000:
            raise ValueError("Message must contain 1–4,000 characters.")
        inventory = await self.models()
        if model not in {item["name"] for item in inventory["models"]}:
            raise ValueError("Choose a model installed on this local Ollama server.")
        prompt = (
            "You are JARVIS, a helpful assistant. Answer clearly. Do not claim to have "
            "performed actions outside this application.\n\n" + message.strip()
        )
        async with httpx.AsyncClient(timeout=90.0, trust_env=False) as client:
            response = await client.post(
                f"{self.base_url}/api/chat",
                json={"model": model, "messages": [{"role": "user", "content": prompt}], "stream": False},
            )
            response.raise_for_status()
            payload = response.json()
        if not isinstance(payload, dict) or not isinstance(payload.get("message"), dict):
            raise ValueError("Ollama returned an invalid chat response.")
        answer = payload.get("message", {}).get("content", "")
        if not isinstance(answer, str):
            raise ValueError("Ollama returned an invalid response.")
        return {"model": model, "answer": answer[:12000], "done": bool(payload.get("done", True))}
