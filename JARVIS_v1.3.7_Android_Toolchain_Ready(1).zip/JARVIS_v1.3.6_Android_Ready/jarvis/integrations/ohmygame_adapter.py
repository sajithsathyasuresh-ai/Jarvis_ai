"""Safe hand-off adapter for the separate OhMyGame application."""
from pathlib import Path


def status() -> dict:
    return {
        "enabled": True,
        "connected": False,
        "mode": "project-brief handoff",
        "detail": (
            "OhMyGame is a separate application. JARVIS can prepare a project "
            "brief in its workspace; no daemon, private API, plugin, or MCP "
            "endpoint is launched or connected automatically."
        ),
    }


def create_game_brief(args: dict, workspace: str | Path) -> dict:
    title = args.get("title", "New game project")
    concept = args.get("concept")
    platform = args.get("platform", "Web")
    if not isinstance(title, str) or not title.strip() or len(title) > 100:
        raise ValueError("Title must contain 1–100 characters.")
    if not isinstance(concept, str) or not concept.strip() or len(concept) > 4000:
        raise ValueError("Concept must contain 1–4000 characters.")
    if not isinstance(platform, str) or len(platform) > 40:
        raise ValueError("Platform must be text up to 40 characters.")
    content = (
        f"# {title.strip()}\n\n"
        "## Game concept\n\n" + concept.strip() + "\n\n"
        f"## Target platform\n\n{platform.strip()}\n\n"
        "## Suggested first milestone\n\n"
        "- Create a minimal playable prototype.\n"
        "- Keep assets and source files inside the project folder.\n"
        "- Run the built-in playtest and review errors before adding features.\n"
        "- Do not publish or upload the project without the owner's explicit approval.\n"
    )
    root = Path(workspace).resolve()
    target = (root / "ohmygame-project-brief.md").resolve()
    if target.parent != root:
        raise ValueError("Invalid project brief destination.")
    target.write_text(content, encoding="utf-8")
    return {"saved": target.name, "bytes": len(content.encode("utf-8")),
            "handoff": "Open the brief in OhMyGame and review it before starting a project."}
