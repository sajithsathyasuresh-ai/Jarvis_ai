"""Optional local AUTOMATIC1111 Stable Diffusion WebUI API adapter.

Only loopback endpoints are accepted. Image generation is an approval-required
operation and writes validated image bytes into the isolated JARVIS workspace.
"""
from __future__ import annotations

import base64
import binascii
import ipaddress
import os
import re
from pathlib import Path
from urllib.parse import urlparse

import httpx


def _local_base_url(value: str) -> str:
    parsed = urlparse(value)
    if parsed.scheme != "http" or not parsed.hostname:
        raise ValueError("Stable Diffusion must use an HTTP loopback URL.")
    host = parsed.hostname.lower()
    if host not in {"localhost"}:
        try:
            if not ipaddress.ip_address(host).is_loopback:
                raise ValueError("Stable Diffusion endpoint must be on this device (loopback only).")
        except ValueError as exc:
            if "must be on this device" in str(exc):
                raise
            raise ValueError("Stable Diffusion endpoint must be localhost or a loopback IP.") from exc
    if parsed.username or parsed.password:
        raise ValueError("Credentials in the Stable Diffusion URL are not supported.")
    return value.rstrip("/")


class StableDiffusionWebUI:
    def __init__(self, base_url: str, workspace: str | Path, timeout: float = 180.0):
        self.base_url = _local_base_url(base_url)
        self.workspace = Path(workspace).resolve()
        self.output_dir = self.workspace / "generated"
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.timeout = max(5.0, min(float(timeout), 240.0))

    def status(self) -> dict:
        try:
            response = httpx.get(f"{self.base_url}/sdapi/v1/samplers", timeout=3.0)
            response.raise_for_status()
            samplers = response.json()
            return {"enabled": True, "connected": True, "samplers": len(samplers),
                    "endpoint": self.base_url, "mode": "local-only"}
        except (httpx.HTTPError, ValueError):
            return {"enabled": True, "connected": False, "endpoint": self.base_url,
                    "mode": "local-only", "detail": "WebUI API is not reachable."}

    def generate(self, args: dict) -> dict:
        prompt = args.get("prompt")
        negative = args.get("negative_prompt", "")
        if not isinstance(prompt, str) or not prompt.strip() or len(prompt) > 1500:
            raise ValueError("Prompt must contain 1–1500 characters.")
        if not isinstance(negative, str) or len(negative) > 1000:
            raise ValueError("Negative prompt must be text up to 1000 characters.")
        width = int(args.get("width", 512))
        height = int(args.get("height", 512))
        steps = int(args.get("steps", 20))
        if width not in range(256, 1025, 8) or height not in range(256, 1025, 8):
            raise ValueError("Width and height must be 256–1024 and divisible by 8.")
        if steps < 1 or steps > 30:
            raise ValueError("Steps must be between 1 and 30.")
        payload = {
            "prompt": prompt.strip(), "negative_prompt": negative,
            "width": width, "height": height, "steps": steps,
            "batch_size": 1, "n_iter": 1, "send_images": True,
            "save_images": False,
        }
        response = httpx.post(f"{self.base_url}/sdapi/v1/txt2img",
                              json=payload, timeout=self.timeout)
        response.raise_for_status()
        data = response.json()
        images = data.get("images")
        if not isinstance(images, list) or len(images) != 1 or not isinstance(images[0], str):
            raise ValueError("WebUI returned an unexpected image response.")
        encoded = images[0].split(",", 1)[-1]
        try:
            raw = base64.b64decode(encoded, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise ValueError("WebUI returned invalid image data.") from exc
        if not raw or len(raw) > 12 * 1024 * 1024:
            raise ValueError("Generated image is empty or exceeds the 12 MB limit.")
        if not (raw.startswith(b"\x89PNG\r\n\x1a\n") or raw.startswith(b"\xff\xd8\xff")):
            raise ValueError("Only PNG or JPEG output is accepted.")
        name = re.sub(r"[^a-zA-Z0-9_-]+", "-", str(args.get("filename", "jarvis-image")))[:48].strip("-_") or "jarvis-image"
        ext = ".png" if raw.startswith(b"\x89PNG") else ".jpg"
        path = self.output_dir / (name + ext)
        counter = 1
        while path.exists():
            path = self.output_dir / f"{name}-{counter}{ext}"
            counter += 1
        path.write_bytes(raw)
        return {"saved": str(path.relative_to(self.workspace)), "bytes": len(raw),
                "width": width, "height": height, "steps": steps}
