# REA integration (optional)

JARVIS includes a lightweight discovery/configuration adapter for **REA —
Reverse Engineer Anything** (`rea-agents`). REA is a separate Node.js MCP
server; it is not embedded into the Python process.

## What this integration currently does

- Reports whether Node.js and npm are present.
- Exposes the official REA MCP launch configuration in `rea-mcp.json`.
- Reports REA status through `GET /api/integrations/rea`.

## What it does not do yet

- It does not install REA or its dependencies.
- It does not connect JARVIS to an MCP server.
- It does not launch analysis or inspect files automatically.

To use REA, install a supported Node.js version (REA 6.10.1 specifies
Node.js `^22.23.4 || ^24.22.1 || >=26.12.1`) and use the official setup
instructions at https://github.com/morluto/rea. The upstream quick start is
`npx rea-agents setup`; review the proposed agent configuration before
approving it. For a standalone MCP host, the configuration is in
`rea-mcp.json`.

Set `JARVIS_ENABLE_REA=true` in `.env` to mark the optional integration as
enabled in JARVIS status. This flag is informational; it does not install,
launch, or connect the REA server.

## Safety and authorization

Only analyze applications, binaries, devices, accounts, and data that you own
or are explicitly authorized to inspect. Start with static, read-only analysis.
Do not run unknown binaries or attach to live processes unless you understand
the effect and have authorization. Do not use reverse engineering to bypass
DRM, licensing, authentication, anti-cheat, or access controls. Protect any
credentials, captured traffic, and personal data.

## Upstream and license

REA upstream: https://github.com/morluto/rea  
Package: https://www.npmjs.com/package/rea-agents  
The upstream project identifies itself as MIT-licensed. This JARVIS adapter
does not redistribute the REA source; it references the separately published
package. Review the upstream license and third-party notices before installing
or redistributing REA itself.
