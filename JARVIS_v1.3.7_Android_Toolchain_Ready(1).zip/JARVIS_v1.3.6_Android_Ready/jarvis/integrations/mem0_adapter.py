"""Optional Mem0 semantic-memory adapter. Disabled unless explicitly configured.

Uses Mem0 OSS with a local Ollama model and local Qdrant storage. The normal
SQLite memory store remains the source of truth and works without this package.
"""
import os
from pathlib import Path

class Mem0Adapter:
    def __init__(self, data_dir: str):
        self.enabled = False
        self.client = None
        if os.getenv("JARVIS_ENABLE_MEM0", "false").lower() not in {"1", "true", "yes"}:
            return
        try:
            from mem0 import Memory
        except ImportError as exc:
            raise RuntimeError("Mem0 is enabled but not installed. Install requirements-mem0.txt.") from exc
        ollama_url = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434").rstrip("/")
        model = os.getenv("OLLAMA_MODEL", "gemma4:e2b")
        # Mem0 OSS supports Ollama providers; keep its vector data inside JARVIS data.
        config = {
            "llm": {"provider": "ollama", "config": {"model": model, "ollama_base_url": ollama_url}},
            "embedder": {"provider": "ollama", "config": {"model": os.getenv("MEM0_EMBED_MODEL", "nomic-embed-text"), "ollama_base_url": ollama_url}},
            "vector_store": {"provider": "qdrant", "config": {"path": str(Path(data_dir) / "mem0_qdrant"), "collection_name": "jarvis_memories"}},
            "history_db_path": str(Path(data_dir) / "mem0_history.db"),
        }
        self.client = Memory.from_config(config)
        self.user_id = os.getenv("JARVIS_MEMORY_USER_ID", "local-user")
        self.enabled = True

    def add(self, content: str):
        if not self.enabled: return None
        return self.client.add(content, user_id=self.user_id)

    def search(self, query: str, limit: int = 5):
        if not self.enabled: return []
        result = self.client.search(query, filters={"user_id": self.user_id}, top_k=max(1, min(limit, 20)))
        return result.get("results", [])
