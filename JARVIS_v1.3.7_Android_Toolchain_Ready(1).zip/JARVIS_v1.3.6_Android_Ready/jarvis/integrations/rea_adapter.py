"""Optional REA (Reverse Engineer Anything) integration discovery.

This adapter checks whether Node.js/npm are available and exposes the official
REA MCP launch configuration. It does not install packages, execute analysis,
or connect to a target automatically.
"""
from __future__ import annotations

import os
import shutil
from typing import Any

REA_PACKAGE = "rea-agents"
REA_VERSION = "6.10.1"


def rea_status() -> dict[str, Any]:
    node = shutil.which("node")
    npm = shutil.which("npm")
    enabled = os.getenv("JARVIS_ENABLE_REA", "false").strip().lower() == "true"
    return {
        "name": "rea",
        "enabled": enabled,
        "installed_runtime": bool(node and npm),
        "node_path": node,
        "npm_path": npm,
        "package": REA_PACKAGE,
        "version": REA_VERSION,
        "mcp_config": {
            "command": "npx",
            "args": ["-y", f"{REA_PACKAGE}@{REA_VERSION}", "mcp"],
        },
        "connection": "external_mcp_host_required",
        "capabilities": [
            "authorized application and binary analysis",
            "static JavaScript/Electron inspection",
            "evidence-backed reverse-engineering workflows",
        ],
        "note": (
            "JARVIS reports REA availability only. It does not yet implement an "
            "MCP client, install REA, or run reverse-engineering operations."
        ),
    }
