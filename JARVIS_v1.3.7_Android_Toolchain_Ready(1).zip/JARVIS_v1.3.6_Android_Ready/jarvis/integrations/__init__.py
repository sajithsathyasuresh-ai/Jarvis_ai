"""Optional integrations for JARVIS."""
