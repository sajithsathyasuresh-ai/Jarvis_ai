"""Constrained project-workspace tools. No arbitrary shell or device access."""
from pathlib import Path

class Workspace:
    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, relative: str) -> Path:
        if not isinstance(relative, str) or not relative.strip():
            raise ValueError("A relative workspace path is required.")
        candidate = (self.root / relative).resolve()
        if candidate != self.root and self.root not in candidate.parents:
            raise ValueError("Path is outside the JARVIS workspace.")
        if candidate == self.root:
            raise ValueError("Choose a file inside the workspace.")
        return candidate

    def list_files(self, args: dict) -> list[str]:
        sub = str(args.get("directory", "."))
        folder = self.root if sub == "." else self._path(sub)
        if not folder.exists() or not folder.is_dir():
            raise ValueError("Workspace directory does not exist.")
        return [str(p.relative_to(self.root)) + ("/" if p.is_dir() else "")
                for p in sorted(folder.iterdir())][:100]

    def read_file(self, args: dict) -> dict:
        path = self._path(args.get("path", ""))
        if not path.is_file():
            raise ValueError("Workspace file not found.")
        if path.stat().st_size > 200_000:
            raise ValueError("File is larger than the 200 KB read limit.")
        return {"path": str(path.relative_to(self.root)), "content": path.read_text(encoding="utf-8")}

    def write_file(self, args: dict) -> dict:
        path = self._path(args.get("path", ""))
        content = args.get("content")
        if not isinstance(content, str) or len(content) > 100_000:
            raise ValueError("Content must be text no larger than 100 KB.")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return {"written": str(path.relative_to(self.root)), "bytes": len(content.encode("utf-8"))}
