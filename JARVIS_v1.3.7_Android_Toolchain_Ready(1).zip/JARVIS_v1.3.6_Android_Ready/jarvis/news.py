"""Small, defensive RSS/Atom news collector. Feed text is treated as untrusted data."""
from __future__ import annotations
import asyncio, html, os, re, sqlite3, time
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse
import httpx
import xml.etree.ElementTree as ET

DEFAULT_FEEDS = [
    "https://feeds.bbci.co.uk/news/world/rss.xml",
    "https://feeds.bbci.co.uk/news/technology/rss.xml",
    "https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en",
]

class _Text(HTMLParser):
    def __init__(self): super().__init__(); self.parts=[]
    def handle_data(self, data): self.parts.append(data)

def plain(value: str, limit: int = 1200) -> str:
    p=_Text()
    try: p.feed(value or "")
    except Exception: pass
    return re.sub(r"\s+", " ", html.unescape(" ".join(p.parts))).strip()[:limit]

class NewsStore:
    def __init__(self, db_path: str):
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.db_path=db_path
        with self._db() as db:
            db.execute("CREATE TABLE IF NOT EXISTS articles (url TEXT PRIMARY KEY, title TEXT NOT NULL, summary TEXT, source TEXT, published TEXT, fetched REAL NOT NULL)")

    def _db(self):
        db=sqlite3.connect(self.db_path, timeout=10)
        db.row_factory=sqlite3.Row
        return db

    async def refresh(self) -> int:
        feeds=[x.strip() for x in os.getenv("JARVIS_NEWS_FEEDS", "").split(",") if x.strip()] or DEFAULT_FEEDS
        saved=0
        headers={"User-Agent":"JARVIS-NewsReader/1.0 (+personal RSS reader)"}
        async with httpx.AsyncClient(timeout=12, follow_redirects=True, headers=headers) as client:
            for feed in feeds[:12]:
                u=urlparse(feed)
                if u.scheme != "https" or not u.hostname: continue
                try:
                    resp=await client.get(feed)
                    resp.raise_for_status()
                    if len(resp.content)>2_000_000: continue
                    root=ET.fromstring(resp.content)
                    for item in root.findall(".//item")[:30] + root.findall(".//{http://www.w3.org/2005/Atom}entry")[:30]:
                        title=plain(item.findtext("title") or item.findtext("{http://www.w3.org/2005/Atom}title") or "", 300)
                        link=item.findtext("link") or ""
                        if not link:
                            el=item.find("{http://www.w3.org/2005/Atom}link")
                            link=el.attrib.get("href", "") if el is not None else ""
                        summary=item.findtext("description") or item.findtext("{http://www.w3.org/2005/Atom}summary") or ""
                        summary=plain(summary)
                        if not title or urlparse(link).scheme not in ("http", "https"): continue
                        published=item.findtext("pubDate") or item.findtext("{http://www.w3.org/2005/Atom}updated") or ""
                        try: published=parsedate_to_datetime(published).isoformat()
                        except Exception: pass
                        with self._db() as db:
                            cur=db.execute("INSERT OR IGNORE INTO articles(url,title,summary,source,published,fetched) VALUES(?,?,?,?,?,?)", (link,title,summary,u.hostname,published,time.time()))
                            saved += cur.rowcount
                except (httpx.HTTPError, ET.ParseError, ValueError):
                    continue
        return saved

    def list(self, limit: int=30):
        with self._db() as db:
            return [dict(r) for r in db.execute("SELECT title,summary,source,published,url FROM articles ORDER BY COALESCE(published,'') DESC, fetched DESC LIMIT ?", (max(1,min(limit,50)),))]

async def news_worker(store: NewsStore):
    while True:
        try: await store.refresh()
        except Exception: pass
        await asyncio.sleep(max(15, int(os.getenv("JARVIS_NEWS_REFRESH_MINUTES", "30"))) * 60)
