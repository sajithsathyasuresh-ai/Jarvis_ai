"""Small read-only client for the public Papers with Code research catalogue."""
from __future__ import annotations

from urllib.parse import urlsplit
import httpx

BASE_URL = "https://paperswithcode.co/api/v1"


class ResearchCatalog:
    def __init__(self, base_url: str = BASE_URL):
        parsed = urlsplit(base_url)
        if (
            parsed.scheme != "https"
            or parsed.hostname != "paperswithcode.co"
            or parsed.path not in ("", "/api/v1")
            or parsed.username
            or parsed.password
            or parsed.query
            or parsed.fragment
            or parsed.port not in (None, 443)
        ):
            raise ValueError("Research catalogue host must be the official HTTPS Papers with Code API.")
        self.base_url = BASE_URL

    @staticmethod
    def _safe_https_url(value: object, *, host: str | None = None) -> str:
        if not isinstance(value, str) or len(value) > 1000:
            return ""
        parsed = urlsplit(value)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
            return ""
        if host is not None and parsed.hostname.lower() != host:
            return ""
        if parsed.port not in (None, 443):
            return ""
        return value

    async def search(self, query: str, limit: int = 8) -> dict:
        if not isinstance(query, str) or not 2 <= len(query.strip()) <= 300:
            raise ValueError("Research query must contain 2–300 characters.")
        if not isinstance(limit, int) or not 1 <= limit <= 10:
            raise ValueError("Limit must be between 1 and 10.")
        async with httpx.AsyncClient(timeout=10.0, follow_redirects=False, trust_env=False) as client:
            response = await client.get(
                f"{self.base_url}/papers/search",
                params={"q": query.strip(), "mode": "keyword", "page": 1, "page_size": limit},
                headers={"Accept": "application/json", "User-Agent": "JARVIS-Research/1.0"},
            )
            response.raise_for_status()
            payload = response.json()
        if isinstance(payload, list):
            rows = payload
        elif isinstance(payload, dict):
            rows = payload.get("results", payload.get("papers", []))
        else:
            rows = []
        if not isinstance(rows, list):
            rows = []
        papers = []
        for row in rows[:limit]:
            if not isinstance(row, dict):
                continue
            arxiv_id = str(row.get("arxiv_id") or "")[:40]
            abs_url = row.get("url_abs") or row.get("source_url")
            if not abs_url and arxiv_id and all(ch.isalnum() or ch in "./-" for ch in arxiv_id):
                abs_url = f"https://arxiv.org/abs/{arxiv_id}"
            abs_url = self._safe_https_url(abs_url)
            repos = row.get("repositories") or []
            code_urls = []
            if isinstance(repos, list):
                for repo in repos[:5]:
                    candidate = repo.get("url") or repo.get("url_abs") if isinstance(repo, dict) else repo
                    safe_repo = self._safe_https_url(candidate, host="github.com")
                    if safe_repo and safe_repo.startswith("https://github.com/"):
                        code_urls.append(safe_repo[:500])
            papers.append({
                "title": str(row.get("title") or "Untitled research paper")[:300],
                "abstract": str(row.get("abstract") or row.get("tldr") or "")[:700],
                "arxiv_id": arxiv_id,
                "published": str(row.get("published") or "")[:30],
                "paper_url": abs_url,
                "code_urls": code_urls,
                "has_official_implementation": bool(row.get("has_official_implementation", False)),
            })
        return {"query": query.strip(), "count": len(papers), "papers": papers,
                "source": "Papers with Code public catalogue", "read_only": True}
