"""Persistent, revisioned task records with append-only audit events."""
from __future__ import annotations

import json
import sqlite3
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any


class RevisionConflict(ValueError):
    """Raised when a caller tries to update a stale task revision."""


class TaskStore:
    STATUSES = {"queued", "planning", "awaiting_approval", "running", "completed", "failed", "cancelled"}

    def __init__(self, path: str):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS tasks (
                id TEXT PRIMARY KEY, goal TEXT NOT NULL, status TEXT NOT NULL,
                plan TEXT NOT NULL DEFAULT '{}', result TEXT NOT NULL DEFAULT '{}',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                revision INTEGER NOT NULL DEFAULT 1)""")
            # In-place migration for existing JARVIS v1.3.2 databases.
            columns = {row[1] for row in db.execute("PRAGMA table_info(tasks)").fetchall()}
            if "revision" not in columns:
                db.execute("ALTER TABLE tasks ADD COLUMN revision INTEGER NOT NULL DEFAULT 1")
            db.execute("""CREATE TABLE IF NOT EXISTS task_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id TEXT NOT NULL,
                event_type TEXT NOT NULL,
                actor TEXT NOT NULL,
                detail TEXT NOT NULL DEFAULT '{}',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_task_events_task_id_id ON task_events(task_id, id)")

    @contextmanager
    def _connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    @staticmethod
    def _serialize(value: dict[str, Any]) -> str:
        if not isinstance(value, dict):
            raise ValueError("Task plan and result values must be JSON objects.")
        try:
            return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
        except (TypeError, ValueError) as exc:
            raise ValueError("Task data must be JSON serializable.") from exc

    @staticmethod
    def _append_event(db, task_id: str, event_type: str, actor: str, detail: dict[str, Any]):
        if actor not in {"system", "agent", "user"}:
            raise ValueError("Unknown task event actor.")
        if not event_type or len(event_type) > 40:
            raise ValueError("Task event type must contain 1–40 characters.")
        rendered = TaskStore._serialize(detail)
        if len(rendered) > 10_000:
            raise ValueError("Task event detail exceeds the 10 KB limit.")
        db.execute(
            "INSERT INTO task_events(task_id,event_type,actor,detail) VALUES(?,?,?,?)",
            (task_id, event_type, actor, rendered),
        )

    def recover_interrupted(self):
        """Mark in-flight tasks interrupted by a restart as retryable failures."""
        with self._connect() as db:
            rows = db.execute(
                "SELECT id,status,revision FROM tasks WHERE status IN ('planning','running')"
            ).fetchall()
            for row in rows:
                db.execute(
                    "UPDATE tasks SET status='failed', result=?, revision=revision+1, "
                    "updated_at=CURRENT_TIMESTAMP WHERE id=? AND revision=?",
                    (json.dumps({"stage": "interrupted", "message": "JARVIS restarted before this task finished. Review the task and run it again."}), row["id"], row["revision"]),
                )
                self._append_event(db, row["id"], "recovered", "system", {
                    "from_status": row["status"], "to_status": "failed", "stage": "interrupted"
                })
            return len(rows)

    def create(self, goal: str) -> dict[str, Any]:
        if not isinstance(goal, str) or not goal.strip() or len(goal) > 4000:
            raise ValueError("Task goal must contain 1–4000 characters.")
        task_id = str(uuid.uuid4())
        with self._connect() as db:
            db.execute("INSERT INTO tasks(id,goal,status) VALUES(?,?,?)", (task_id, goal.strip(), "queued"))
            self._append_event(db, task_id, "created", "user", {"status": "queued"})
        return self.get(task_id)

    def update(
        self,
        task_id: str,
        *,
        status: str | None = None,
        plan: dict | None = None,
        result: dict | None = None,
        goal: str | None = None,
        expected_revision: int | None = None,
        actor: str = "system",
    ):
        if status is not None and status not in self.STATUSES:
            raise ValueError("Invalid task status.")
        if goal is not None and (not isinstance(goal, str) or not goal.strip() or len(goal) > 4000):
            raise ValueError("Task goal must contain 1–4000 characters.")
        with self._connect() as db:
            row = db.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
            if not row:
                return None
            current_revision = int(row["revision"])
            if expected_revision is not None and expected_revision != current_revision:
                raise RevisionConflict(
                    f"Task revision conflict: expected {expected_revision}, current revision is {current_revision}."
                )
            next_status = status or row["status"]
            next_goal = goal.strip() if goal is not None else row["goal"]
            next_plan = plan if plan is not None else json.loads(row["plan"])
            next_result = result if result is not None else json.loads(row["result"])
            plan_json = self._serialize(next_plan)
            result_json = self._serialize(next_result)
            changed = []
            if next_status != row["status"]: changed.append("status")
            if next_goal != row["goal"]: changed.append("goal")
            if plan_json != row["plan"]: changed.append("plan")
            if result_json != row["result"]: changed.append("result")
            if not changed:
                return self.get(task_id)
            cursor = db.execute(
                "UPDATE tasks SET goal=?,status=?,plan=?,result=?,revision=revision+1, "
                "updated_at=CURRENT_TIMESTAMP WHERE id=? AND revision=?",
                (next_goal, next_status, plan_json, result_json, task_id, current_revision),
            )
            if cursor.rowcount != 1:
                raise RevisionConflict("Task changed during update; reload it and retry.")
            detail: dict[str, Any] = {"changed_fields": changed}
            if next_status != row["status"]:
                detail.update({"from_status": row["status"], "to_status": next_status})
            stage = next_result.get("stage") if isinstance(next_result, dict) else None
            if isinstance(stage, str):
                detail["stage"] = stage[:80]
            self._append_event(db, task_id, "updated", actor, detail)
        return self.get(task_id)

    def append_event(self, task_id: str, message: str, *, actor: str = "user"):
        if not isinstance(message, str) or not message.strip() or len(message) > 1000:
            raise ValueError("Task event message must contain 1–1000 characters.")
        with self._connect() as db:
            exists = db.execute("SELECT 1 FROM tasks WHERE id=?", (task_id,)).fetchone()
            if not exists:
                return None
            self._append_event(db, task_id, "note", actor, {"message": message.strip()})
            row = db.execute("SELECT last_insert_rowid() AS id").fetchone()
            return self._event_by_id(db, int(row["id"]))

    @staticmethod
    def _event_by_id(db, event_id: int):
        row = db.execute("SELECT * FROM task_events WHERE id=?", (event_id,)).fetchone()
        if not row:
            return None
        item = dict(row)
        item["detail"] = json.loads(item["detail"])
        return item

    def events(self, task_id: str, limit: int = 50):
        with self._connect() as db:
            rows = db.execute(
                "SELECT * FROM task_events WHERE task_id=? ORDER BY id DESC LIMIT ?",
                (task_id, max(1, min(int(limit), 100))),
            ).fetchall()
            items = []
            for row in reversed(rows):
                item = dict(row)
                item["detail"] = json.loads(item["detail"])
                items.append(item)
            return items

    def get(self, task_id: str):
        with self._connect() as db:
            row = db.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
            if not row:
                return None
            data = dict(row)
            data["plan"] = json.loads(data["plan"])
            data["result"] = json.loads(data["result"])
            return data

    def list(self, limit: int = 30):
        with self._connect() as db:
            rows = db.execute(
                "SELECT id,goal,status,created_at,updated_at,revision FROM tasks "
                "ORDER BY updated_at DESC LIMIT ?",
                (max(1, min(limit, 100)),),
            ).fetchall()
            return [dict(row) for row in rows]
